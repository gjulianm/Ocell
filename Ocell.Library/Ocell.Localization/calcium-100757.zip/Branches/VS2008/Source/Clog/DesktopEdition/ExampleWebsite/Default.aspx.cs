﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;

using DanielVaughan.Logging;

namespace ExampleWebsite
{
	public partial class _Default : Page
	{
		static int logInfoCount;
		static int logExceptionCount;

		protected void Page_Load(object sender, EventArgs e)
		{
			/* Intentionally left blank. */
		}

		protected void Button_LogMessage_Click(object sender, EventArgs e)
		{
			Log.Info("Test Message resulting from button click. Clicked " + ++logInfoCount + " times.");
		}

		protected void Button_LogException_Click(object sender, EventArgs e)
		{
			Log.Error("Test exception logging resulting from button click. Clicked " + ++logExceptionCount + " times.",
				new Exception("Test exception " + logExceptionCount));
		}
	}
}
