﻿/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="//License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2007/11/27 12:44</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/

using System;
using DanielVaughan.Logging;

namespace ExampleWebsite
{
	public class SimpleLogStrategy : ILogStrategy
	{
		public LogLevel GetLogLevel(IClientInfo clientInfo)
		{
			return LogLevel.All;
		}

		public void Write(IClientLogEntry logEntry)
		{
			System.Diagnostics.Trace.WriteLine(logEntry);
			Console.WriteLine(logEntry);
		}

		public void Write(IServerLogEntry logEntry)
		{
			System.Diagnostics.Trace.WriteLine(logEntry);
			Console.WriteLine(logEntry);
		}
	}
}