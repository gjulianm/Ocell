﻿/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="//License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2007/11/27 12:44</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/

using System;
using System.Windows;
using DanielVaughan.Logging;

namespace ExampleWpfApplication
{
	/// <summary>
	/// Interaction logic for Window1.xaml
	/// </summary>
	public partial class Window1
	{
		public Window1()
		{
			InitializeComponent();

			Loaded += Window1_Loaded;
		}

		void Window1_Loaded(object sender, RoutedEventArgs e)
		{
			Log.Write += Log_Write;
			Log.Info("Window loaded.");
		}

		void Log_Write(object sender, LogEventArgs e)
		{
			listBox_Events.Items.Add(e.LogEntry);
			/* Output log entry as trace when debugging. */
			System.Diagnostics.Trace.Write(e.LogEntry.CodeLocation);
		}

		/// <summary>
		/// Handles the Click event of the button_LogDebug control.
		/// Logs a debug message.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.Windows.RoutedEventArgs"/> instance containing the event data.</param>
		private void button_LogDebug_Click(object sender, RoutedEventArgs e)
		{
			Log.Debug("Debug clicked. Message time:" + DateTime.Now.ToShortTimeString());
		}

		/// <summary>
		/// Handles the Click event of the button_LogInfo control.
		/// Logs a debug message.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.Windows.RoutedEventArgs"/> instance containing the event data.</param>
		private void button_LogInfo_Click(object sender, RoutedEventArgs e)
		{
			Log.Info("Info clicked. Message time:" + DateTime.Now.ToShortTimeString());
		}

		/// <summary>
		/// Handles the Click event of the button_LogError control.
		/// Logs an exception.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.Windows.RoutedEventArgs"/> instance containing the event data.</param>
		private void button_LogError_Click(object sender, RoutedEventArgs e)
		{
			Exception exception;
			try
			{
				throw new ApplicationException("This is a intentionally thrown test exception.");
			}
			catch (Exception ex)
			{
				exception = ex;
			}
			Log.Error("Error clicked. Message time:" + DateTime.Now.ToShortTimeString(), exception);
		}
	}
}
