﻿/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="//License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2007/11/19 20:00</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/

using System.Xml;
using System.Xml.Linq;

using DanielVaughan.Logging.Configuration;

namespace DanielVaughan.Logging
{
	/// <summary>
	/// A filter is used to allow or prevent
	/// <see cref="ILogEntry"/> instances from being
	/// logged.
	/// </summary>
	public interface IFilter
	{
		/// <summary>
		/// Determines whether the <see cref="ILogEntry"/> 
		/// should be logged. 
		/// </summary>
		/// <param name="origin">Where the call orginated. 
		/// <see cref="LogEntryOrigin"/></param>
		/// <param name="clientInfo">The caller information that this filter
		/// applies. Can be null.</param>
		/// <returns>
		/// 	<c>true</c> if the <see cref="ILogEntry"/> should
		/// be logged; otherwise, <c>false</c>.
		/// </returns>
		bool IsValid(LogEntryOrigin origin, IClientInfo clientInfo);

//		LogLevel Validate(LogEntryOrigin origin, IClientInfo clientInfo);
//
//		int Precedence { get; }

//		/// <summary>
//		/// Initializes using the specified filter element.
//		/// </summary>
//		/// <param name="filterConfiguration">The filter element.</param>
//		void Load(IFilterConfiguration filterConfiguration);

		void Load(XmlElement filterElement);
	}
}
