﻿/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="//License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2007/11/19 20:00</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/

using System;
using System.Configuration.Provider;

namespace DanielVaughan.Logging
{
	/// <summary>
	/// A collection of <see cref="ILogStrategy"/>'s.
	/// </summary>
	class LogStrategyProviderCollection : ProviderCollection
	{
		public new ILogStrategyProvider this[string name]
		{
			get
			{
				return (ILogStrategyProvider)base[name];
			}
		}

		/// <summary>
		/// Adds a provider to the collection.
		/// </summary>
		/// <param name="provider">The provider to be added.</param>
		/// <exception cref="T:System.ArgumentException">The <see cref="P:System.Configuration.Provider.ProviderBase.Name"></see> of provider is null.- or -The length of the <see cref="P:System.Configuration.Provider.ProviderBase.Name"></see> of provider is less than 1.</exception>
		/// <exception cref="T:System.ArgumentNullException">provider is null.</exception>
		/// <exception cref="T:System.NotSupportedException">The collection is read-only.</exception>
		/// <PermissionSet><IPermission class="System.Security.Permissions.SecurityPermission, mscorlib, Version=2.0.3600.0, Culture=neutral, PublicKeyToken=b77a5c561934e089" version="1" Flags="UnmanagedCode, ControlEvidence"/></PermissionSet>
		public override void Add(ProviderBase provider)
		{
			if (provider == null)
			{
				throw new ArgumentNullException("provider");
			}

			if (!(provider is ILogStrategyProvider))
			{
				throw new ArgumentException("Invalid provider type. Should have base type "
					+ typeof(ILogStrategyProvider), "provider");
			}

			base.Add(provider);
		}
	}
}
