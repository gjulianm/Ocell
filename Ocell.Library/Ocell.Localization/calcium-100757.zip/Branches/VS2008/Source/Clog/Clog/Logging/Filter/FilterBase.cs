﻿/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="//License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2007/11/19 20:00</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/

using System;
using System.Xml;

namespace DanielVaughan.Logging
{
	/// <summary>
	/// Base implementation for an <see cref="IFilter"/>.
	/// </summary>
	public abstract class FilterBase : IFilter
	{
		protected const string InvalidActionMessage = "Unknown Action. Must be Allow or Deny.";
		public string Name { get; protected set; }

		#region event Init

		event EventHandler<FilterInitEventArgs> init;

		/// <summary>
		/// Occurs when the filter is first initialised
		/// and the <see cref="FilterInitEventArgs"/> is available.
		/// </summary>
		protected event EventHandler<FilterInitEventArgs> Init
		{
			add
			{
				init += value;
			}
			remove
			{
				init -= value;
			}
		}

		void OnInit(FilterInitEventArgs e)
		{
			if (init != null)
			{
				init(this, e);
			}
		}

		#endregion

		FilterAction action = FilterAction.Default;
		protected FilterAction Action
		{
			get
			{
				return action;
			}
			set
			{
				action = value;
			}
		}

		public abstract bool IsValid(LogEntryOrigin origin, IClientInfo clientInfo);

		public void Load(XmlElement filterElement)
		{
			ArgumentValidator.AssertNotNull(filterElement, "filterElement");
			var nameAttribute = filterElement.GetAttribute("Name");
			if (nameAttribute == null)
			{
				throw new ClientLoggingException("Name attribute is missing."); /* TODO: Make localizable resource. */
			}
			Name = nameAttribute;

			var actionAttribute = filterElement.GetAttribute("Action");
			if (!string.IsNullOrEmpty(actionAttribute))
			{
				try
				{
					Action = (FilterAction)Enum.Parse(typeof(FilterAction), actionAttribute);
				}
				catch (ArgumentException ex)
				{
					throw new ClientLoggingException("Action attribute is invalid for strategy: " + Name, ex); /* TODO: Make localizable resource. */
				}
			}

			OnInit(new FilterInitEventArgs(filterElement));
		}
	}

	public class FilterInitEventArgs : EventArgs
	{
		public XmlElement ConfigurationElement { get; private set; }

		public FilterInitEventArgs(XmlElement configurationElement)
		{
			ArgumentValidator.AssertNotNull(configurationElement, "configurationElement");
			ConfigurationElement = configurationElement;
		}
	}
}
