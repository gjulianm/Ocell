﻿using System;
using System.Configuration.Install;
using System.Diagnostics;
using System.ComponentModel;


namespace DanielVaughan.Logging.Installers
{
	[RunInstaller(true)]
	public class InternalLogEventLogInstaller : Installer
	{
		public const string EventLogSource = "Clog";
		public const string EventLogLog = "Application";

		EventLogInstaller eventLogInstaller = new EventLogInstaller();

		public InternalLogEventLogInstaller() 
		{
			eventLogInstaller.Source = EventLogSource;
			eventLogInstaller.Log = EventLogLog;
			Installers.Add(eventLogInstaller);   
		}

	}
}
