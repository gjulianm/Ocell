﻿using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Logging")]
[assembly: AssemblyDescription("Client Server logging.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("DanielVaughan")]
[assembly: AssemblyProduct("Clog")]
[assembly: AssemblyCopyright("Copyright © Daniel Vaughan 2007")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

[assembly: CLSCompliant(true)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("fb024432-bd52-4656-9583-e3bb0ac8f818")]

// f32f1bf552288cd5
[assembly: InternalsVisibleTo("DanielVaughan.Logging.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100bb5ac02a16983883207886153ffd32dcc614843010dd451eefae15b2055e3fba025dbea644c48a0b89a11a216b45a0c187bf8a7a1f62261d1cb5e23c7dbfde5c4c2c035a628fcdc6e70f040565a738c08848c4c345fe27d064bba9d4ab5ed0177d0c6a03a84d335edd818c712616d1c7cd4cefe4bf29c6ff697b5ab030541e9c")]