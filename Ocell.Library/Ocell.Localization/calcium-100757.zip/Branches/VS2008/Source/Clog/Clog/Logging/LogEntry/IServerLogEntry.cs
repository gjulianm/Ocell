﻿/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="//License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2007/11/19 20:00</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/

using System;

namespace DanielVaughan.Logging
{
	/// <summary>
	/// Represents regular log entries that are not from a e.g. web client,
	/// and that are made within the application.
	/// <seealso cref="IClientLogEntry"/>
	/// </summary>
	public interface IServerLogEntry : ILogEntry
	{
		/// <summary>
		/// Gets or sets the exception that is to be logged.
		/// May be null.
		/// </summary>
		/// <value>The exception that occured.</value>
		Exception Exception
		{
			get;
			set;
		}

		/// <summary>
		/// Gets or sets the app domain that the log request was made.
		/// </summary>
		/// <value>The app domain.</value>
		string AppDomain
		{
			get; 
			set;
		}

		/// <summary>
		/// Gets or sets string representation of the current thread's principal identity.
		/// </summary>
		/// <value>The string representation of the current thread's principal identity.</value>
		string Identity
		{
			get; 
			set;
		}
	}
}
