﻿/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="//License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2007/11/19 20:00</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/

using System.Web;

namespace DanielVaughan.Logging.Filters
{
	/// <summary>
	/// The base implementation for filters that require
	/// an HttpRequest to be able to evaluate correctly.
	/// </summary>
	abstract class HttpRequestFilterBase : FilterBase
	{
		/// <summary>
		/// Gets the HTTP request.
		/// </summary>
		/// <value>The HTTP request.</value>
		static protected HttpRequest HttpRequest
		{
			get
			{
				if (HttpContext.Current != null && HttpContext.Current.Request != null)
				{
					return HttpContext.Current.Request;
				}
				return null;
			}
		}
	}
}
