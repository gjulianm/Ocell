﻿/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="//License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2007/11/19 20:00</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/

namespace DanielVaughan.Logging
{
	/// <summary>
	/// Log strategy providers must implement this interface.
	/// </summary>
	public interface ILogStrategyProvider
	{
		/// <summary>
		/// Gets the log strategy.
		/// </summary>
		/// <value>The log strategy.</value>
		ILogStrategy LogStrategy
		{
			get;
		}
	}
}
