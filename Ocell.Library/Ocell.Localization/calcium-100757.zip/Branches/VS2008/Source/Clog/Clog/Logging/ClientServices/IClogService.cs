﻿/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="//License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2007/11/27 12:44</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/

using System.ServiceModel;

using DanielVaughan.Logging.LogEntries;

namespace DanielVaughan.Logging
{
	/// <summary>
	/// Provides Clog logging services
	/// to remote clients.
	/// </summary>
	[ServiceContract(Namespace = OrganizationalConstants.ServiceContractNamespace)]
	public interface IClogService
	{
		/// <summary>
		/// Gets the configuration information
		/// for the log with specified logName.
		/// </summary>
		/// <param name="clientInfo">Information regarding
		/// the client from logging calls may be made.</param>
		/// <returns>The log configuration information.</returns>
		[OperationContract]
		[ServiceKnownType(typeof(ClientInfo))]
		[ServiceKnownType(typeof(ServerLogEntry))]
		ClientConfigurationData GetConfiguration(IClientInfo clientInfo);

		/// <summary>
		/// Writes the entry to the log 
		/// using the active <see cref="ILogStrategy"/>.
		/// Does not use One Way OperationContract, 
		/// which is incompatible with Silverlight.
		/// </summary>
		/// <param name="entryData">The entry data to be written.</param>
		[OperationContract]//(IsOneWay = true)]
		[ServiceKnownType(typeof(LogEntryData))]
		void WriteEntrySilverlight(ILogEntry entryData);

		/// <summary>
		/// Writes the entry to the log 
		/// using the active <see cref="ILogStrategy"/>.
		/// </summary>
		/// <param name="entryData">The entry data to be written.</param>
		[OperationContract(IsOneWay = true)]
		[ServiceKnownType(typeof(LogEntryData))]
		[ServiceKnownType(typeof(ServerLogEntry))]
		void WriteEntry(ILogEntry entryData);
	}
}
