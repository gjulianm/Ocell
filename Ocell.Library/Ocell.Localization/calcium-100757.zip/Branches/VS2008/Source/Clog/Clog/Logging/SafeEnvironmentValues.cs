﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;
using System.Text;

namespace DanielVaughan.Logging
{
	static class SafeEnvironmentValues
	{
		static bool lowTrust;

		public static string UserName
		{
			get
			{
				if (!lowTrust)
				{
					try
					{
						return Environment.UserName;
					}
					catch (SecurityException)
					{
						lowTrust = true;
					}
				}
				return string.Empty;
			}
		}

		public static string MachineName
		{
			get
			{
				if (!lowTrust)
				{
					try
					{
						return Environment.MachineName;
					}
					catch (SecurityException)
					{
						lowTrust = true;
					}
				}
				return string.Empty;
			}
		}
	}
}
