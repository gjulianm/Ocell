﻿/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="//License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2007/11/19 20:00</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/

namespace DanielVaughan.Logging
{
	/// <summary>
	/// A log entry originating from a remote location
	/// such as from a web client, arriving via a web service.
	/// </summary>
	public interface IClientLogEntry : ILogEntry
	{
		/// <summary>
		/// Gets the exception memento.
		/// May be null.
		/// </summary>
		/// <value>The exception memento.</value>
		IExceptionMemento ExceptionMemento { get; }
	}
}
