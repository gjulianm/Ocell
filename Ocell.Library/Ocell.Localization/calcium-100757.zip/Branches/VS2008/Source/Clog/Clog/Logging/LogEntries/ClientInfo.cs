﻿#region File and License Information
/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="//License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2008-12-20 18:05:17Z</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/
#endregion

using System;
using System.ComponentModel;
using System.Runtime.Serialization;

namespace DanielVaughan.Logging
{
	/* TODO: [DV] Comment. */
	[DataContract(Namespace = OrganizationalConstants.DataContractNamespace), Serializable]
	public class ClientInfo : IClientInfo, IExtensibleDataObject
	{
		/// <summary>
		/// Gets or sets the name of the log that the log entry
		/// is to be written under. <seealso cref="ILogEntry"/>
		/// </summary>
		/// <value>The name of the log.</value>
		[DataMember]
		public string LogName { get; set; }

		[DataMember]
		public string UserName { get; set; }

		[DataMember]
		public string MachineName { get; set; }

		/// <summary>
		/// Gets or sets the URL from where the log request was made.
		/// </summary>
		/// <value>The URL of the log request.</value>
		[DataMember]
		public string Url { get; set; }

		[DataMember]
		public string IPAddress { get; set; }

		public ClientInfo(IClientInfo info)
		{
			ArgumentValidator.AssertNotNull(info, "info");
			LogName = info.LogName;
			MachineName = info.MachineName;
			Url = info.Url;
			UserName = info.UserName;
			IPAddress = info.IPAddress;
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="ClientInfo"/> class.
		/// </summary>
		public ClientInfo()
		{
			/* Intentionally left blank. */
		}

		public override string ToString()
		{
			string result = string.Format("Log Name: {0}, Username: {1}, Machine Name: {2}, URL: {3}, IP Address: {4}",
			                              LogName, UserName, MachineName, Url, IPAddress);
			return result;
		}

		/// <summary>
		/// Gets or sets the structure that contains extra data.
		/// </summary>
		/// <value></value>
		/// <returns>An <see cref="T:System.Runtime.Serialization.ExtensionDataObject"/> 
		/// that contains data that is not recognized as belonging to the data contract.</returns>
		[EditorBrowsable(EditorBrowsableState.Never)]
		public ExtensionDataObject ExtensionData { get; set; }
	}
}
