﻿/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="//License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2007/11/19 20:00</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/

namespace DanielVaughan.Logging
{
	/// <summary>
	/// This defines the contract for handling logging events.
	/// To create a custom strategy, implement this interface
	/// and define a provider for the strategy
	/// in the application configuration.
	/// </summary>
	public interface ILogStrategy 
	{
		/// <summary>
		/// Gets the log level for the log with the specified name.
		/// </summary>
		/// <param name="clientInfo">Information regarding the caller. 
		/// May be null, in which case the lowest (least restrictive) level is returned.</param>
		/// <returns>The threshold log level.</returns>
		LogLevel GetLogLevel(IClientInfo clientInfo);

		/// <summary>
		/// Logs the specified client log entry.
		/// <seealso cref="IServerLogEntry"/>
		/// </summary>
		/// <param name="logEntry">The log entry.</param>
		void Write(IClientLogEntry logEntry);

		/// <summary>
		/// Logs the specified server log entry. 
		/// <seealso cref="IServerLogEntry"/>
		/// </summary>
		/// <param name="logEntry">The log entry.</param>
		void Write(IServerLogEntry logEntry);
	}
}
