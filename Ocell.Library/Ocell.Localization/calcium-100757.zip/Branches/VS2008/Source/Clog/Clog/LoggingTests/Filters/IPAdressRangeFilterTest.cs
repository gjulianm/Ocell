﻿/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="//License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2007/11/19 20:00</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/

using System.Xml;

using DanielVaughan.Logging.Filters;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using DanielVaughan.Logging;
using DanielVaughan.Logging.Configuration;
using System.Net;

namespace DanielVaughan.Logging.Tests
{
    
    
    /// <summary>
    ///This is a test class for IPAdressRangeFilterTest and is intended
    ///to contain all IPAdressRangeFilterTest Unit Tests
    ///</summary>
	[TestClass()]
	public class IPAdressRangeFilterTest
	{
		private TestContext testContextInstance;

		/// <summary>
		///Gets or sets the test context which provides
		///information about and functionality for the current test run.
		///</summary>
		public TestContext TestContext
		{
			get
			{
				return testContextInstance;
			}
			set
			{
				testContextInstance = value;
			}
		}

		#region Additional test attributes
		// 
		//You can use the following additional attributes as you write your tests:
		//
		//Use ClassInitialize to run code before running the first test in the class
		//[ClassInitialize()]
		//public static void MyClassInitialize(TestContext testContext)
		//{
		//}
		//
		//Use ClassCleanup to run code after all tests in a class have run
		//[ClassCleanup()]
		//public static void MyClassCleanup()
		//{
		//}
		//
		//Use TestInitialize to run code before running each test
		//[TestInitialize()]
		//public void MyTestInitialize()
		//{
		//}
		//
		//Use TestCleanup to run code after each test has run
		//[TestCleanup()]
		//public void MyTestCleanup()
		//{
		//}
		//
		#endregion


//		/// <summary>
//		///A test for ToUInt
//		///</summary>
//		[TestMethod()]
//		[DeploymentItem("DanielVaughan.Logging.dll")]
//		public void ToUIntTest()
//		{
//			IPAddress ipAddress = IPAddress.Parse("127.0.0.1");
//			uint expected = 0; 
//			uint actual;
//			actual = IPAdressRangeFilter_Accessor.ToUInt(ipAddress);
//			Assert.AreEqual(expected, actual);
//			Assert.Inconclusive("Verify the correctness of this test method.");
//		}

		/// <summary>
		///A test for ToUInt
		///</summary>
		[TestMethod()]
		[DeploymentItem("DanielVaughan.Logging.dll")]
		public void IsWithinRange()
		{
			IPAddress beginAddress = IPAddress.Parse("127.0.0.1");
			IPAddress endAddress = IPAddress.Parse("127.0.0.10");
			uint begin = IPAddressRangeFilter_Accessor.ToUInt(beginAddress);
			uint end = IPAddressRangeFilter_Accessor.ToUInt(endAddress);
			bool actual = IPAddressRangeFilter_Accessor.IsWithinRange(begin, "127.0.0.5", end);
			Assert.IsTrue(actual);
			actual = IPAddressRangeFilter_Accessor.IsWithinRange(begin, "255.0.0.21", end);
			Assert.IsFalse(actual);
		}

		/// <summary>
		///A test for IsValid
		///</summary>
		[TestMethod()]
		public void IsValidTest()
		{
			var target = new IPAddressRangeFilter();

			var doc = new XmlDocument();
			doc.LoadXml(@"<Filter Name=""IPAddressRange"" Begin=""127.0.0.0"" End=""127.0.0.10""/>");
			target.Load((XmlElement)doc.FirstChild);

			var clientInfo = new ClientInfo {IPAddress = "127.0.0.0"};
			bool actual = target.IsValid(LogEntryOrigin.Local, clientInfo);
			Assert.AreEqual(true, actual);

			clientInfo = new ClientInfo { IPAddress = "127.0.0.10" };
			actual = target.IsValid(LogEntryOrigin.Local, clientInfo);
			Assert.AreEqual(true, actual);

			clientInfo = new ClientInfo { IPAddress = "127.0.0.5" };
			actual = target.IsValid(LogEntryOrigin.Local, clientInfo);
			Assert.AreEqual(true, actual);

			target = new IPAddressRangeFilter();
			doc = new XmlDocument();
			doc.LoadXml(@"<Filter Name=""IPAddressRange"" Begin=""127.0.0.10"" End=""127.0.0.10""/>");
			target.Load((XmlElement)doc.FirstChild);

			clientInfo = new ClientInfo {IPAddress = "127.0.0.99"};
			actual = target.IsValid(LogEntryOrigin.Remote, clientInfo);
			Assert.AreEqual(false, actual);

			clientInfo = new ClientInfo { IPAddress = "127.0.0.0" };
			actual = target.IsValid(LogEntryOrigin.Remote, clientInfo);
			Assert.AreEqual(false, actual);

			clientInfo = new ClientInfo { IPAddress = "127.0.0.f" };
			actual = target.IsValid(LogEntryOrigin.Remote, clientInfo);
			Assert.AreEqual(false, actual);
		}

		/// <summary>
		///A test for Init
		///</summary>
		[TestMethod()]
		public void LoadTest()
		{
			var target = new IPAddressRangeFilter();
			var doc = new XmlDocument();
			doc.LoadXml(@"<Filter Name=""IPAddressRange"" Begin=""127.0.0.0"" End=""127.0.0.10""/>");
			target.Load((XmlElement)doc.FirstChild);
		}
	}
}
