﻿using System.Xml;

using DanielVaughan.Logging.Filters;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using DanielVaughan.Logging;
using DanielVaughan.Logging.Configuration;

namespace DanielVaughan.Logging.Tests
{
    /// <summary>
    ///This is a test class for TimeRangeFilterTest and is intended
    ///to contain all TimeRangeFilterTest Unit Tests
    ///</summary>
	[TestClass()]
	public class TimeRangeFilterTest
	{
		private TestContext testContextInstance;

		/// <summary>
		///Gets or sets the test context which provides
		///information about and functionality for the current test run.
		///</summary>
		public TestContext TestContext
		{
			get
			{
				return testContextInstance;
			}
			set
			{
				testContextInstance = value;
			}
		}

		#region Additional test attributes
		// 
		//You can use the following additional attributes as you write your tests:
		//
		//Use ClassInitialize to run code before running the first test in the class
		//[ClassInitialize()]
		//public static void MyClassInitialize(TestContext testContext)
		//{
		//}
		//
		//Use ClassCleanup to run code after all tests in a class have run
		//[ClassCleanup()]
		//public static void MyClassCleanup()
		//{
		//}
		//
		//Use TestInitialize to run code before running each test
		//[TestInitialize()]
		//public void MyTestInitialize()
		//{
		//}
		//
		//Use TestCleanup to run code after each test has run
		//[TestCleanup()]
		//public void MyTestCleanup()
		//{
		//}
		//
		#endregion


		/// <summary>
		///A test for IsValid
		///</summary>
		[TestMethod]
		public void IsValidTest()
		{
			TimeRangeFilter target = new TimeRangeFilter();
			
			var doc = new XmlDocument();
			doc.LoadXml(@"<Filter Name=""BusinessHours"" Begin=""04:00:00"" End=""04:00:01"" />");
			target.Load((XmlElement)doc.FirstChild);

			ClientInfo info = new ClientInfo();
			
			/* Doesn't matter what the LogEntryOrigin is. */
			bool actual = target.IsValid(LogEntryOrigin.Remote, info);
			Assert.AreEqual(false, actual, "Current time should not be within this range.");

			doc = new XmlDocument();
			doc.LoadXml(@"<Filter Name=""BusinessHours"" Begin=""00:00:00"" End=""23:59:59"" />");
			target.Load((XmlElement)doc.FirstChild);

			/* Doesn't matter what the LogEntryOrigin is. */
			actual = target.IsValid(LogEntryOrigin.Remote, info); 
			Assert.AreEqual(true, actual, "Current time should be within this range.");
		}
	}
}
