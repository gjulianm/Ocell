﻿/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="//License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2007/11/27 12:44</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/

namespace DanielVaughan.Logging
{
	/// <summary>
	/// Specifies the action to be taken
	/// if a filter is deemed to be invalid or valid.
	/// <seealso cref="IFilter"/>
	/// </summary>
	public enum FilterAction
	{
		/// <summary>
		/// The default action.
		/// The filter will take what ever 
		/// action it regards as appropriate.
		/// </summary>
		Default,
		/// <summary>
		/// The filter may choose to reject
		/// the logging request.
		/// </summary>
		Deny,
		/// <summary>
		/// The filter may choose to accept 
		/// the logging request.
		/// </summary>
		Allow
	}
}
