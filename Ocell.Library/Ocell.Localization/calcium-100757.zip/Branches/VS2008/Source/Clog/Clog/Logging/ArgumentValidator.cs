﻿#region File and License Information
/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="//License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2009-10-10 19:38:37Z</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/
#endregion

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using DanielVaughan.Logging.Resources;

namespace DanielVaughan.Logging
{
	/// <summary>
	/// Utility class for validating method parameters.
	/// </summary>
	public static class ArgumentValidator
	{
		/// <summary>
		/// Ensures the specified value is not null.
		/// </summary>
		/// <typeparam name="T">The type of the value.</typeparam>
		/// <param name="value">The value to test.</param>
		/// <param name="parameterName">Name of the parameter.</param>
		/// <returns>The specified value.</returns>
		/// <exception cref="ArgumentNullException">Occurs if the specified value 
		/// is <code>null</code>.</exception>
		/// <example>
		/// public UIElementAdapter(UIElement uiElement)
		/// {
		/// 	this.uiElement = ArgumentValidator.AssertNotNull(uiElement, "uiElement");	
		/// }
		/// </example>
		public static T AssertNotNull<T>(T value, string parameterName) where T : class
		{
			if (value == null)
			{
				throw new ArgumentNullException(parameterName);
			}

			return value;
		}

		/// <summary>
		/// Ensures the specified value is not <code>null</code> or empty (a zero length string).
		/// </summary>
		/// <param name="value">The value to test.</param>
		/// <param name="parameterName">Name of the parameter.</param>
		/// <returns>The specified value.</returns>
		/// <exception cref="ArgumentNullException">Occurs if the specified value 
		/// is <code>null</code> or empty (a zero length string).</exception>
		/// <example>
		/// public DoSomething(string message)
		/// {
		/// 	this.message = ArgumentValidator.AssertNotNullOrEmpty(message, "message");	
		/// }
		/// </example>
		public static string AssertNotNullOrEmpty(string value, string parameterName)
		{
			if (value == null)
			{
				throw new ArgumentNullException(parameterName);
			}

			if (string.IsNullOrEmpty(value))
			{
				throw new ArgumentException(StringResources.ArgumentValidation_ArgumentEmpty, parameterName);
			}

			return value;
		}
	}
}
