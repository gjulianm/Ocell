﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DanielVaughan.Logging.Tests.Mocks
{
	class MockLogStrategy : ILogStrategy
	{
		LogLevel logLevel = LogLevel.All;

		public LogLevel LogLevel
		{
			get
			{
				return logLevel;
			}
			set
			{
				logLevel = value;
			}
		}

		#region Implementation of ILogStrategy

		public LogLevel GetLogLevel(IClientInfo clientInfo)
		{
			return logLevel;
		}

		public IClientLogEntry LogEntry { get; set; }

		public void Write(IClientLogEntry logEntry)
		{
			LogEntry = logEntry;
		}

		public IServerLogEntry ServerLogEntry { get; set; }

		public void Write(IServerLogEntry logEntry)
		{
			ServerLogEntry = logEntry;
		}

		#endregion
	}
}
