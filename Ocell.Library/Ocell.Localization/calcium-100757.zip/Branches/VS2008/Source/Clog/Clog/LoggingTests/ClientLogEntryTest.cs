﻿/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="//License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2007/11/19 20:00</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/

using DanielVaughan.Logging.LogEntries;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using DanielVaughan.Logging;

namespace DanielVaughan.Logging.Tests
{
    /// <summary>
    ///This is a test class for ClientLogEntryTest and is intended
    ///to contain all ClientLogEntryTest Unit Tests
    ///</summary>
	[TestClass()]
	public class ClientLogEntryTest
	{
        TestContext testContextInstance;

		/// <summary>
		///Gets or sets the test context which provides
		///information about and functionality for the current test run.
		///</summary>
		public TestContext TestContext
		{
			get
			{
				return testContextInstance;
			}
			set
			{
				testContextInstance = value;
			}
		}

		#region Additional test attributes
		// 
		//You can use the following additional attributes as you write your tests:
		//
		//Use ClassInitialize to run code before running the first test in the class
		//[ClassInitialize()]
		//public static void MyClassInitialize(TestContext testContext)
		//{
		//}
		//
		//Use ClassCleanup to run code after all tests in a class have run
		//[ClassCleanup()]
		//public static void MyClassCleanup()
		//{
		//}
		//
		//Use TestInitialize to run code before running each test
		//[TestInitialize()]
		//public void MyTestInitialize()
		//{
		//}
		//
		//Use TestCleanup to run code after each test has run
		//[TestCleanup()]
		//public void MyTestCleanup()
		//{
		//}
		//
		#endregion


//		/// <summary>
//		///A test for IpAddress
//		///</summary>
//		[TestMethod()]
//		public void IpAddressTest()
//		{
//			LogEntryData logEntryData = null; 
//			ClientLogEntry target = new ClientLogEntry(logEntryData); 
//			string expected = string.Empty; 
//			string actual;
//			target.IpAddress = expected;
//			actual = target.IpAddress;
//			Assert.AreEqual(expected, actual);
//			Assert.Inconclusive("Verify the correctness of this test method.");
//		}

//		/// <summary>
//		///A test for ExceptionMemento
//		///</summary>
//		[TestMethod()]
//		public void ExceptionMementoTest()
//		{
//			LogEntryData logEntryData = new LogEntryData() { Message = "Test Message" };
//			ClientLogEntry target = new ClientLogEntry(logEntryData);
//			IExceptionMemento expected = null; 
//			IExceptionMemento actual;
//			target.ExceptionMemento = expected;
//			actual = target.ExceptionMemento;
//			Assert.AreEqual(expected, actual);
//			Assert.Inconclusive("Verify the correctness of this test method.");
//		}

		/// <summary>
		///A test for ClientLogEntry Constructor
		///</summary>
		[TestMethod()]
		public void ClientLogEntryConstructorTest()
		{
			LogEntryData logEntryData = new LogEntryData() { Message = "Test Message" };
			ClientLogEntry target = new ClientLogEntry(logEntryData);
			Assert.AreEqual(logEntryData.Message, target.Message);
		}
	}
}
