﻿#region File and License Information
/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="//License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2009-04-09 21:16:12Z</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
	<Contributions>
		<Contribution><Date>2009-04-09</Date><Name>Michael Gerfen</Name>
						<Description>Provided file.</Description></Contribution>
	</Contributions>
</File>
*/
#endregion

using System.ServiceModel;

namespace DanielVaughan.Logging.Configuration
{
	public class ClogBasicHttpBinding : BasicHttpBinding
	{
		public ClogBasicHttpBinding()
		{
			MaxBufferSize = 2147483647;
			MaxReceivedMessageSize = 2147483647;
			Security.Mode = BasicHttpSecurityMode.None;
		}
	}
}
