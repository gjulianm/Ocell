﻿/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="//License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2007/11/19 20:00</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/

using System.Collections.Specialized;
using System.Xml;

using DanielVaughan.Logging.Filters;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using DanielVaughan.Logging;
using DanielVaughan.Logging.Configuration;

namespace DanielVaughan.Logging.Tests
{
    /// <summary>
    ///This is a test class for RoleMembershipFilterTest and is intended
    ///to contain all RoleMembershipFilterTest Unit Tests
    ///</summary>
	[TestClass()]
	public class RoleMembershipFilterTest
	{
		private TestContext testContextInstance;

		/// <summary>
		///Gets or sets the test context which provides
		///information about and functionality for the current test run.
		///</summary>
		public TestContext TestContext
		{
			get
			{
				return testContextInstance;
			}
			set
			{
				testContextInstance = value;
			}
		}

		#region Additional test attributes
		// 
		//You can use the following additional attributes as you write your tests:
		//
		//Use ClassInitialize to run code before running the first test in the class
		//[ClassInitialize()]
		//public static void MyClassInitialize(TestContext testContext)
		//{
		//}
		//
		//Use ClassCleanup to run code after all tests in a class have run
		//[ClassCleanup()]
		//public static void MyClassCleanup()
		//{
		//}
		//
		//Use TestInitialize to run code before running each test
		//[TestInitialize()]
		//public void MyTestInitialize()
		//{
		//}
		//
		//Use TestCleanup to run code after each test has run
		//[TestCleanup()]
		//public void MyTestCleanup()
		//{
		//}
		//
		#endregion


		/// <summary>
		///A test for IsValid
		///</summary>
		[TestMethod()]
		public void IsValidTest()
		{
			var target = new RoleMembershipFilter(); 
			var origin = new LogEntryOrigin(); 
			var clientInfo = new ClientInfo {UserName = "Daniel"};

			bool actual = target.IsValid(origin, clientInfo);
			Assert.AreEqual(true, actual);
		}

		/// <summary>
		///A test for Init
		///</summary>
		[TestMethod()]
		public void LoadTest()
		{
			var target = new RoleMembershipFilter();

			var doc = new XmlDocument();
			doc.LoadXml(@"<Filter Name=""RoleMembership"" Roles=""Developer, Administrator"" />");
			target.Load((XmlElement)doc.FirstChild);
		}
	}
}
