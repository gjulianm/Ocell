﻿/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="//License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2007/11/19 20:00</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/

using System;
using System.Runtime.Serialization;

namespace DanielVaughan.Logging.LogEntries
{
	[DataContract(Namespace = OrganizationalConstants.DataContractNamespace), Serializable]
	sealed class ClientLogEntry : LogEntryBase, IClientLogEntry
	{
		[DataMember]
		public new IExceptionMemento ExceptionMemento
		{
			get
			{
				return base.ExceptionMemento;
			}
			set
			{
				base.ExceptionMemento = (ExceptionMemento)value;
			}
		}

		public ClientLogEntry(LogEntryData logEntryData) : base(logEntryData)
		{
			ExceptionMemento = logEntryData.ExceptionMemento;
		}

		public override string ToString()
		{
			string result = string.Format("{0}, Exception: {1}", base.ToString(), ExceptionMemento);
			return result;
		}
	}
}
