﻿#region File and License Information
/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="//License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2009-04-10 11:57:19Z</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/
#endregion

using System;
using System.Collections.Generic;

namespace DanielVaughan.Logging
{
	public static partial class Log
	{
		#region Enabled properties (Short-circuiting)

		/// <summary>
		/// Gets a value indicating whether debug is enabled. If <code>true</code>
		/// calls to Debug will be attempted, otherwise they will be ignored.
		/// </summary>
		/// <value><c>true</c> if debug is enabled; otherwise, <c>false</c>.</value>
		public static bool DebugEnabled
		{
			get
			{
				return IsLevelEnabled(LogLevel.Debug);
			}
		}

		/// <summary>
		/// Gets a value indicating whether info is enabled. If <code>true</code>
		/// calls to Info will be attempted, otherwise they will be ignored.
		/// </summary>
		/// <value><c>true</c> if info is enabled; otherwise, <c>false</c>.</value>
		public static bool InfoEnabled
		{
			get
			{
				return IsLevelEnabled(LogLevel.Info);
			}
		}

		/// <summary>
		/// Gets a value indicating whether warn is enabled. If <code>true</code>
		/// calls to Warn will be attempted, otherwise they will be ignored.
		/// </summary>
		/// <value><c>true</c> if warn is enabled; otherwise, <c>false</c>.</value>
		public static bool WarnEnabled
		{
			get
			{
				return IsLevelEnabled(LogLevel.Warn);
			}
		}

		/// <summary>
		/// Gets a value indicating whether error is enabled. If <code>true</code>
		/// calls to Error will be attempted, otherwise they will be ignored.
		/// </summary>
		/// <value><c>true</c> if error is enabled; otherwise, <c>false</c>.</value>
		public static bool ErrorEnabled
		{
			get
			{
				return IsLevelEnabled(LogLevel.Error);
			}
		}

		/// <summary>
		/// Gets a value indicating whether fatal is enabled. If <code>true</code>
		/// calls to Fatal will be attempted, otherwise they will be ignored.
		/// </summary>
		/// <value><c>true</c> if fatal is enabled; otherwise, <c>false</c>.</value>
		public static bool FatalEnabled
		{
			get
			{
				return IsLevelEnabled(LogLevel.Fatal);
			}
		}

		#endregion

		#region Logging Overloads
		/// <summary>
		/// Writes a log entry at the <see cref="LogLevel.Debug"/> 
		/// level to the active <see cref="ILogStrategy"/>.
		/// </summary>
		/// <param name="message">The message to write.</param>
		public static void Debug(string message)
		{
			WriteLogEntry(LogLevel.Debug, message, null, null);
		}

		/// <summary>
		/// Writes a log entry at the <see cref="LogLevel.Debug"/> 
		/// level to the active <see cref="ILogStrategy"/>.
		/// </summary>
		/// <param name="message">The message to write.</param>
		/// <param name="properties">Custom properties 
		/// to add additional logging information.</param>
		public static void Debug(string message, IDictionary<string, object> properties)
		{
			WriteLogEntry(LogLevel.Debug, message, null, properties);
		}

		/// <summary>
		/// Writes a log entry at the <see cref="LogLevel.Debug"/> 
		/// level to the active <see cref="ILogStrategy"/>.
		/// </summary>
		/// <param name="message">The message to write.</param>
		/// <param name="exception">The exception that this message 
		/// is regarding.</param>
		public static void Debug(string message, Exception exception)
		{
			WriteLogEntry(LogLevel.Debug, message, exception, null);
		}

		/// <summary>
		/// Writes a log entry at the <see cref="LogLevel.Debug"/> 
		/// level to the active <see cref="ILogStrategy"/>.
		/// </summary>
		/// <param name="message">The message to write.</param>
		/// <param name="exception">The exception that this message 
		/// is regarding.</param>
		/// <param name="properties">Custom properties 
		/// to add additional logging information.</param>
		public static void Debug(string message, Exception exception, IDictionary<string, object> properties)
		{
			WriteLogEntry(LogLevel.Debug, message, exception, properties);
		}

		/// <summary>
		/// Writes a log entry at the <see cref="LogLevel.Debug"/> 
		/// level to the active <see cref="ILogStrategy"/>.
		/// </summary>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		public static void DebugFormat(string message, params object[] args)
		{
			string formattedMessage = String.Format(message, args);
			WriteLogEntry(LogLevel.Debug, formattedMessage, null, null);
		}

		/// <summary>
		/// Writes a log entry at the <see cref="LogLevel.Debug"/> 
		/// level to the active <see cref="ILogStrategy"/>.
		/// </summary>
		/// <param name="provider">The provider which provides culture-specific formatting information.</param>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		public static void DebugFormat(IFormatProvider provider, string message, params object[] args)
		{
			string formattedMessage = String.Format(provider, message, args);
			WriteLogEntry(LogLevel.Debug, formattedMessage, null, null);
		}

		/// <summary>
		/// Writes a log entry at the <see cref="LogLevel.Debug"/> 
		/// level to the active <see cref="ILogStrategy"/>.
		/// </summary>
		/// <param name="exception">The exception that this message
		/// is regarding.</param>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		public static void DebugFormat(Exception exception, string message, params object[] args)
		{
			string formattedMessage = String.Format(message, args);
			WriteLogEntry(LogLevel.Debug, formattedMessage, exception, null);
		}

		/// <summary>
		/// Writes a log entry at the <see cref="LogLevel.Debug"/> 
		/// level to the active <see cref="ILogStrategy"/>.
		/// </summary>
		/// <param name="provider">The provider which provides culture-specific formatting information.</param>
		/// <param name="exception">The exception that this message is regarding.</param>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		public static void DebugFormat(Exception exception, IFormatProvider provider, 
			string message, params object[] args)
		{
			string formattedMessage = String.Format(provider, message, args);
			WriteLogEntry(LogLevel.Debug, formattedMessage, exception, null);
		}

		/// <summary>
		/// Writes a log entry at the <see cref="LogLevel.Debug"/> 
		/// level to the active <see cref="ILogStrategy"/>.
		/// </summary>
		/// <param name="exception">The exception that this message is regarding.</param>
		/// <param name="properties">Custom properties to add additional logging information.</param>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		public static void DebugFormat(Exception exception, IDictionary<string, object> properties, 
			string message, params object[] args)
		{
			string formattedMessage = String.Format(message, args);
			WriteLogEntry(LogLevel.Debug, formattedMessage, exception, properties);
		}

		/// <summary>
		/// Writes a log entry at the <see cref="LogLevel.Debug"/> 
		/// level to the active <see cref="ILogStrategy"/>.
		/// </summary>
		/// <param name="provider">The provider which provides culture-specific formatting information.</param>
		/// <param name="exception">The exception that this message is regarding.</param>
		/// <param name="properties">Custom properties to add additional logging information.</param>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		public static void DebugFormat(Exception exception, IDictionary<string, object> properties, 
			IFormatProvider provider, string message, params object[] args)
		{
			string formattedMessage = String.Format(provider, message, args);
			WriteLogEntry(LogLevel.Debug, formattedMessage, exception, properties);
		}

		/// <summary>
		/// Writes a log entry at the <see cref="LogLevel.Info"/> 
		/// level to the active <see cref="ILogStrategy"/>.
		/// </summary>
		/// <param name="message">The message to write.</param>
		public static void Info(string message)
		{
			WriteLogEntry(LogLevel.Info, message, null, null);
		}

		/// <summary>
		/// Writes a log entry at the <see cref="LogLevel.Info"/> 
		/// level to the active <see cref="ILogStrategy"/>.
		/// </summary>
		/// <param name="properties">Custom properties
		/// to add additional logging information.</param>
		/// <param name="message">The message to write.</param>
		public static void Info(string message, IDictionary<string, object> properties)
		{
			WriteLogEntry(LogLevel.Info, message, null, properties);
		}

		/// <summary>
		/// Writes a log entry at the <see cref="LogLevel.Info"/> 
		/// level to the active <see cref="ILogStrategy"/>.
		/// </summary>
		/// <param name="exception">The exception that this message  is regarding.</param>
		/// <param name="message">The message to write.</param>
		public static void Info(string message, Exception exception)
		{
			WriteLogEntry(LogLevel.Info, message, exception, null);
		}

		/// <summary>
		/// Writes a log entry at the <see cref="LogLevel.Info"/> 
		/// level to the active <see cref="ILogStrategy"/>.
		/// </summary>
		/// <param name="exception">The exception that this message  is regarding.</param>
		/// <param name="properties">Custom properties  to add additional logging information.</param>
		/// <param name="message">The message to write.</param>
		public static void Info(string message, Exception exception, IDictionary<string, object> properties)
		{
			WriteLogEntry(LogLevel.Info, message, exception, properties);
		}

		/// <summary>
		/// Writes a log entry at the <see cref="LogLevel.Info"/> 
		/// level to the active <see cref="ILogStrategy"/>.
		/// </summary>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		public static void InfoFormat(string message, params object[] args)
		{
			string formattedMessage = String.Format(message, args);
			WriteLogEntry(LogLevel.Info, formattedMessage, null, null);
		}

		/// <summary>
		/// Writes a log entry at the <see cref="LogLevel.Info"/> 
		/// level to the active <see cref="ILogStrategy"/>.
		/// </summary>
		/// <param name="provider">The provider which provides culture-specific formatting information.</param>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		public static void InfoFormat(IFormatProvider provider, string message, params object[] args)
		{
			string formattedMessage = String.Format(provider, message, args);
			WriteLogEntry(LogLevel.Info, formattedMessage, null, null);
		}

		/// <summary>
		/// Writes a log entry at the <see cref="LogLevel.Info"/> 
		/// level to the active <see cref="ILogStrategy"/>.
		/// </summary>
		/// <param name="exception">The exception that this message  is regarding.</param>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		public static void InfoFormat(Exception exception, string message, params object[] args)
		{
			string formattedMessage = String.Format(message, args);
			WriteLogEntry(LogLevel.Info, formattedMessage, exception, null);
		}

		/// <summary>
		/// Writes a log entry at the <see cref="LogLevel.Info"/> 
		/// level to the active <see cref="ILogStrategy"/>.
		/// </summary>
		/// <param name="provider">The provider which provides culture-specific formatting information.</param>
		/// <param name="exception">The exception that this message  is regarding.</param>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		public static void InfoFormat(Exception exception, IFormatProvider provider, string message, params object[] args)
		{
			string formattedMessage = String.Format(provider, message, args);
			WriteLogEntry(LogLevel.Info, formattedMessage, exception, null);
		}

		/// <summary>
		/// Writes a log entry at the <see cref="LogLevel.Info"/> 
		/// level to the active <see cref="ILogStrategy"/>.
		/// </summary>
		/// <param name="exception">The exception that this message  is regarding.</param>
		/// <param name="properties">Custom properties  to add additional logging information.</param>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		public static void InfoFormat(Exception exception, IDictionary<string, object> properties, 
			string message, params object[] args)
		{
			string formattedMessage = String.Format(message, args);
			WriteLogEntry(LogLevel.Info, formattedMessage, exception, properties);
		}

		/// <summary>
		/// Writes a log entry at the <see cref="LogLevel.Info"/> 
		/// level to the active <see cref="ILogStrategy"/>.
		/// </summary>
		/// <param name="provider">The provider which provides culture-specific formatting information.</param>
		/// <param name="exception">The exception that this message  is regarding.</param>
		/// <param name="properties">Custom properties  to add additional logging information.</param>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		public static void InfoFormat(Exception exception, IDictionary<string, object> properties, 
			IFormatProvider provider, string message, params object[] args)
		{
			string formattedMessage = String.Format(provider, message, args);
			WriteLogEntry(LogLevel.Info, formattedMessage, exception, properties);
		}

		/// <summary>
		/// Writes a log entry at the <see cref="LogLevel.Warn"/> 
		/// level to the active <see cref="ILogStrategy"/>.
		/// </summary>
		/// <param name="message">The message to write.</param>
		public static void Warn(string message)
		{
			WriteLogEntry(LogLevel.Warn, message, null, null);
		}

		/// <summary>
		/// Writes a log entry at the <see cref="LogLevel.Warn"/> 
		/// level to the active <see cref="ILogStrategy"/>.
		/// </summary>
		/// <param name="properties">Custom properties  to add additional logging information.</param>
		/// <param name="message">The message to write.</param>
		public static void Warn(string message, IDictionary<string, object> properties)
		{
			WriteLogEntry(LogLevel.Warn, message, null, properties);
		}

		/// <summary>
		/// Writes a log entry at the <see cref="LogLevel.Warn"/> 
		/// level to the active <see cref="ILogStrategy"/>.
		/// </summary>
		/// <param name="exception">The exception that this message  is regarding.</param>
		/// <param name="message">The message to write.</param>
		public static void Warn(string message, Exception exception)
		{
			WriteLogEntry(LogLevel.Warn, message, exception, null);
		}

		/// <summary>
		/// Writes a log entry at the <see cref="LogLevel.Warn"/> 
		/// level to the active <see cref="ILogStrategy"/>.
		/// </summary>
		/// <param name="exception">The exception that this message  is regarding.</param>
		/// <param name="properties">Custom properties  to add additional logging information.</param>
		/// <param name="message">The message to write.</param>
		public static void Warn(string message, Exception exception, IDictionary<string, object> properties)
		{
			WriteLogEntry(LogLevel.Warn, message, exception, properties);
		}

		/// <summary>
		/// Writes a log entry at the <see cref="LogLevel.Warn"/> 
		/// level to the active <see cref="ILogStrategy"/>.
		/// </summary>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		public static void WarnFormat(string message, params object[] args)
		{
			string formattedMessage = String.Format(message, args);
			WriteLogEntry(LogLevel.Warn, formattedMessage, null, null);
		}

		/// <summary>
		/// Writes a log entry at the <see cref="LogLevel.Warn"/> 
		/// level to the active <see cref="ILogStrategy"/>.
		/// </summary>
		/// <param name="provider">The provider which provides culture-specific formatting information.</param>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		public static void WarnFormat(IFormatProvider provider, string message, params object[] args)
		{
			string formattedMessage = String.Format(provider, message, args);
			WriteLogEntry(LogLevel.Warn, formattedMessage, null, null);
		}

		/// <summary>
		/// Writes a log entry at the <see cref="LogLevel.Warn"/> 
		/// level to the active <see cref="ILogStrategy"/>.
		/// </summary>
		/// <param name="exception">The exception that this message  is regarding.</param>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		public static void WarnFormat(Exception exception, string message, params object[] args)
		{
			string formattedMessage = String.Format(message, args);
			WriteLogEntry(LogLevel.Warn, formattedMessage, exception, null);
		}

		/// <summary>
		/// Writes a log entry at the <see cref="LogLevel.Warn"/> 
		/// level to the active <see cref="ILogStrategy"/>.
		/// </summary>
		/// <param name="provider">The provider which provides culture-specific formatting information.</param>
		/// <param name="exception">The exception that this message  is regarding.</param>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		public static void WarnFormat(Exception exception, IFormatProvider provider, string message, params object[] args)
		{
			string formattedMessage = String.Format(provider, message, args);
			WriteLogEntry(LogLevel.Warn, formattedMessage, exception, null);
		}

		/// <summary>
		/// Writes a log entry at the <see cref="LogLevel.Warn"/> 
		/// level to the active <see cref="ILogStrategy"/>.
		/// </summary>
		/// <param name="exception">The exception that this message  is regarding.</param>
		/// <param name="properties">Custom properties  to add additional logging information.</param>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		public static void WarnFormat(Exception exception, IDictionary<string, object> properties, 
			string message, params object[] args)
		{
			string formattedMessage = String.Format(message, args);
			WriteLogEntry(LogLevel.Warn, formattedMessage, exception, properties);
		}

		/// <summary>
		/// Writes a log entry at the <see cref="LogLevel.Warn"/> 
		/// level to the active <see cref="ILogStrategy"/>.
		/// </summary>
		/// <param name="provider">The provider which provides culture-specific formatting information.</param>
		/// <param name="exception">The exception that this message  is regarding.</param>
		/// <param name="properties">Custom properties  to add additional logging information.</param>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		public static void WarnFormat(Exception exception, IDictionary<string, object> properties, 
			IFormatProvider provider, string message, params object[] args)
		{
			string formattedMessage = String.Format(provider, message, args);
			WriteLogEntry(LogLevel.Warn, formattedMessage, exception, properties);
		}

		/// <summary>
		/// Writes a log entry at the <see cref="LogLevel.Error"/> 
		/// level to the active <see cref="ILogStrategy"/>.
		/// </summary>
		/// <param name="message">The message to write.</param>
		public static void Error(string message)
		{
			WriteLogEntry(LogLevel.Error, message, null, null);
		}

		/// <summary>
		/// Writes a log entry at the <see cref="LogLevel.Error"/> 
		/// level to the active <see cref="ILogStrategy"/>.
		/// </summary>
		/// <param name="properties">Custom properties  to add additional logging information.</param>
		/// <param name="message">The message to write.</param>
		public static void Error(string message, IDictionary<string, object> properties)
		{
			WriteLogEntry(LogLevel.Error, message, null, properties);
		}

		/// <summary>
		/// Writes a log entry at the <see cref="LogLevel.Error"/> 
		/// level to the active <see cref="ILogStrategy"/>.
		/// </summary>
		/// <param name="exception">The exception that this message  is regarding.</param>
		/// <param name="message">The message to write.</param>
		public static void Error(string message, Exception exception)
		{
			WriteLogEntry(LogLevel.Error, message, exception, null);
		}

		/// <summary>
		/// Writes a log entry at the <see cref="LogLevel.Error"/> 
		/// level to the active <see cref="ILogStrategy"/>.
		/// </summary>
		/// <param name="exception">The exception that this message  is regarding.</param>
		/// <param name="properties">Custom properties  to add additional logging information.</param>
		/// <param name="message">The message to write.</param>
		public static void Error(string message, Exception exception, IDictionary<string, object> properties)
		{
			WriteLogEntry(LogLevel.Error, message, exception, properties);
		}

		/// <summary>
		/// Writes a log entry at the <see cref="LogLevel.Error"/> 
		/// level to the active <see cref="ILogStrategy"/>.
		/// </summary>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		public static void ErrorFormat(string message, params object[] args)
		{
			string formattedMessage = String.Format(message, args);
			WriteLogEntry(LogLevel.Error, formattedMessage, null, null);
		}

		/// <summary>
		/// Writes a log entry at the <see cref="LogLevel.Error"/> 
		/// level to the active <see cref="ILogStrategy"/>.
		/// </summary>
		/// <param name="provider">The provider which provides culture-specific formatting information.</param>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		public static void ErrorFormat(IFormatProvider provider, string message, params object[] args)
		{
			string formattedMessage = String.Format(provider, message, args);
			WriteLogEntry(LogLevel.Error, formattedMessage, null, null);
		}

		/// <summary>
		/// Writes a log entry at the <see cref="LogLevel.Error"/> 
		/// level to the active <see cref="ILogStrategy"/>.
		/// </summary>
		/// <param name="exception">The exception that this message  is regarding.</param>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		public static void ErrorFormat(Exception exception, string message, params object[] args)
		{
			string formattedMessage = String.Format(message, args);
			WriteLogEntry(LogLevel.Error, formattedMessage, exception, null);
		}

		/// <summary>
		/// Writes a log entry at the <see cref="LogLevel.Error"/> 
		/// level to the active <see cref="ILogStrategy"/>.
		/// </summary>
		/// <param name="provider">The provider which provides culture-specific formatting information.</param>
		/// <param name="exception">The exception that this message  is regarding.</param>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		public static void ErrorFormat(Exception exception, IFormatProvider provider, string message, params object[] args)
		{
			string formattedMessage = String.Format(provider, message, args);
			WriteLogEntry(LogLevel.Error, formattedMessage, exception, null);
		}

		/// <summary>
		/// Writes a log entry at the <see cref="LogLevel.Error"/> 
		/// level to the active <see cref="ILogStrategy"/>.
		/// </summary>
		/// <param name="exception">The exception that this message  is regarding.</param>
		/// <param name="properties">Custom properties  to add additional logging information.</param>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		public static void ErrorFormat(Exception exception, IDictionary<string, object> properties, 
			string message, params object[] args)
		{
			string formattedMessage = String.Format(message, args);
			WriteLogEntry(LogLevel.Error, formattedMessage, exception, properties);
		}

		/// <summary>
		/// Writes a log entry at the <see cref="LogLevel.Error"/> 
		/// level to the active <see cref="ILogStrategy"/>.
		/// </summary>
		/// <param name="provider">The provider which provides culture-specific formatting information.</param>
		/// <param name="exception">The exception that this message  is regarding.</param>
		/// <param name="properties">Custom properties  to add additional logging information.</param>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		public static void ErrorFormat(Exception exception, IDictionary<string, object> properties, 
			IFormatProvider provider, string message, params object[] args)
		{
			string formattedMessage = String.Format(provider, message, args);
			WriteLogEntry(LogLevel.Error, formattedMessage, exception, properties);
		}

		/// <summary>
		/// Writes a log entry at the <see cref="LogLevel.Fatal"/> 
		/// level to the active <see cref="ILogStrategy"/>.
		/// </summary>
		/// <param name="message">The message to write.</param>
		public static void Fatal(string message)
		{
			WriteLogEntry(LogLevel.Fatal, message, null, null);
		}

		/// <summary>
		/// Writes a log entry at the <see cref="LogLevel.Fatal"/> 
		/// level to the active <see cref="ILogStrategy"/>.
		/// </summary>
		/// <param name="properties">Custom properties  to add additional logging information.</param>
		/// <param name="message">The message to write.</param>
		public static void Fatal(string message, IDictionary<string, object> properties)
		{
			WriteLogEntry(LogLevel.Fatal, message, null, properties);
		}

		/// <summary>
		/// Writes a log entry at the <see cref="LogLevel.Fatal"/> 
		/// level to the active <see cref="ILogStrategy"/>.
		/// </summary>
		/// <param name="exception">The exception that this message  is regarding.</param>
		/// <param name="message">The message to write.</param>
		public static void Fatal(string message, Exception exception)
		{
			WriteLogEntry(LogLevel.Fatal, message, exception, null);
		}

		/// <summary>
		/// Writes a log entry at the <see cref="LogLevel.Fatal"/> 
		/// level to the active <see cref="ILogStrategy"/>.
		/// </summary>
		/// <param name="exception">The exception that this message  is regarding.</param>
		/// <param name="properties">Custom properties  to add additional logging information.</param>
		/// <param name="message">The message to write.</param>
		public static void Fatal(string message, Exception exception, IDictionary<string, object> properties)
		{
			WriteLogEntry(LogLevel.Fatal, message, exception, properties);
		}

		/// <summary>
		/// Writes a log entry at the <see cref="LogLevel.Fatal"/> 
		/// level to the active <see cref="ILogStrategy"/>.
		/// </summary>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		public static void FatalFormat(string message, params object[] args)
		{
			string formattedMessage = String.Format(message, args);
			WriteLogEntry(LogLevel.Fatal, formattedMessage, null, null);
		}

		/// <summary>
		/// Writes a log entry at the <see cref="LogLevel.Fatal"/> 
		/// level to the active <see cref="ILogStrategy"/>.
		/// </summary>
		/// <param name="provider">The provider which provides culture-specific formatting information.</param>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		public static void FatalFormat(IFormatProvider provider, string message, params object[] args)
		{
			string formattedMessage = String.Format(provider, message, args);
			WriteLogEntry(LogLevel.Fatal, formattedMessage, null, null);
		}

		/// <summary>
		/// Writes a log entry at the <see cref="LogLevel.Fatal"/> 
		/// level to the active <see cref="ILogStrategy"/>.
		/// </summary>
		/// <param name="exception">The exception that this message  is regarding.</param>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		public static void FatalFormat(Exception exception, string message, params object[] args)
		{
			string formattedMessage = String.Format(message, args);
			WriteLogEntry(LogLevel.Fatal, formattedMessage, exception, null);
		}

		/// <summary>
		/// Writes a log entry at the <see cref="LogLevel.Fatal"/> 
		/// level to the active <see cref="ILogStrategy"/>.
		/// </summary>
		/// <param name="provider">The provider which provides culture-specific formatting information.</param>
		/// <param name="exception">The exception that this message  is regarding.</param>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		public static void FatalFormat(Exception exception, IFormatProvider provider, 
			string message, params object[] args)
		{
			string formattedMessage = String.Format(provider, message, args);
			WriteLogEntry(LogLevel.Fatal, formattedMessage, exception, null);
		}

		/// <summary>
		/// Writes a log entry at the <see cref="LogLevel.Fatal"/> 
		/// level to the active <see cref="ILogStrategy"/>.
		/// </summary>
		/// <param name="exception">The exception that this message  is regarding.</param>
		/// <param name="properties">Custom properties  to add additional logging information.</param>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		public static void FatalFormat(Exception exception, IDictionary<string, object> properties, 
			string message, params object[] args)
		{
			string formattedMessage = String.Format(message, args);
			WriteLogEntry(LogLevel.Fatal, formattedMessage, exception, properties);
		}

		/// <summary>
		/// Writes a log entry at the <see cref="LogLevel.Fatal"/> 
		/// level to the active <see cref="ILogStrategy"/>.
		/// </summary>
		/// <param name="provider">The provider which provides culture-specific formatting information.</param>
		/// <param name="exception">The exception that this message  is regarding.</param>
		/// <param name="properties">Custom properties  to add additional logging information.</param>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		public static void FatalFormat(Exception exception, IDictionary<string, object> properties, 
			IFormatProvider provider, string message, params object[] args)
		{
			string formattedMessage = String.Format(provider, message, args);
			WriteLogEntry(LogLevel.Fatal, formattedMessage, exception, properties);
		}
		#endregion	
	}
}
