﻿/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="//License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2007/11/19 20:00</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/

using System;
using System.ComponentModel;
using System.Runtime.Serialization;

namespace DanielVaughan.Logging
{
	/// <summary>
	/// Provides consumers of the logging
	/// service with log configuration inforamation.
	/// </summary>
	[DataContract(Namespace = OrganizationalConstants.DataContractNamespace), Serializable]
	public class ClientConfigurationData : IExtensibleDataObject
	{
		DateTime retrievedOn = DateTime.Now;
		int expiresInSeconds = 300;
		
		/// <summary>
		/// Gets or sets the that this configuration will expire in seconds.
		/// </summary>
		/// <value>The expires in seconds.</value>
		[DataMember]
		public int ExpiresInSeconds
		{
			get
			{
				return expiresInSeconds;
			}
			set
			{
				expiresInSeconds = value;
			}
		}

		/// <summary>
		/// Gets or sets the the time that this information was retrieved.
		/// </summary>
		/// <value>The time that this information was retrieved.</value>
		[DataMember]
		public DateTime RetrievedOn
		{
			get
			{
				return retrievedOn;
			}
			set
			{
				retrievedOn = value;
			}
		}

		/// <summary>
		/// Gets or sets a value indicating whether logging is enabled
		/// for the named log.
		/// </summary>
		/// <value><c>true</c> if the log is enabled; otherwise, <c>false</c>.</value>
		[DataMember]
		public bool LogEnabled { get; set; }
		/* Serialization of enums is not supported by Silverlight yet. */
//		public LogLevel LogLevel { get; set; }  
		
		[DataMember]
		public LogLevel LogLevel { get; set; }

		public bool Expired
		{
			get
			{
				return RetrievedOn.AddSeconds(expiresInSeconds) < DateTime.Now;
				//return RetrievedOn.Add(expiresInSeconds) < DateTime.Now;
			}
		}

		/// <summary>
		/// Gets or sets the structure that contains extra data.
		/// </summary>
		/// <value></value>
		/// <returns>An <see cref="T:System.Runtime.Serialization.ExtensionDataObject"/> 
		/// that contains data that is not recognized as belonging to the data contract.</returns>
		[EditorBrowsable(EditorBrowsableState.Never)]
		public ExtensionDataObject ExtensionData { get; set; }
	}
}
