﻿/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="//License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2007/11/19 20:00</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/

using System;
using System.Runtime.Serialization;

namespace DanielVaughan.Logging.LogEntries
{
	[DataContract(Namespace = OrganizationalConstants.DataContractNamespace), Serializable]
	abstract class LogEntryBase : LogEntryData
	{
		[DataMember]
		public string PrincipalIdentity { get; set; }

		/// <summary>
		/// Initializes a new instance of the <see cref="LogEntryBase"/> class.
		/// </summary>
		/// <param name="logLevel">The log level.</param>
		/// <param name="message">The message.</param>
		protected LogEntryBase(LogLevel logLevel, string message)
		{
			LogLevel = logLevel;
			Message = message;
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="LogEntryBase"/> class.
		/// </summary>
		/// <param name="logEntryData">The log entry data.</param>
		protected LogEntryBase(LogEntryData logEntryData) : base(logEntryData)
		{
		}

		/// <summary>
		/// Returns a <see cref="T:System.String"/> 
		/// that represents the current <see cref="LogEntryBase"/>.
		/// </summary>
		/// <returns>
		/// A <see cref="T:System.String"/> that represents the current <see cref="LogEntryBase"/>.
		/// </returns>
		public override string ToString()
		{
			return string.Format("{0}, PrincipalIdentity: {1}", base.ToString(), PrincipalIdentity);
		}
	}
}
