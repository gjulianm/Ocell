﻿/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="//License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2007/11/19 20:00</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/

using DanielVaughan.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace DanielVaughan.Logging.Tests
{
    
    
    /// <summary>
    ///This is a test class for ConfigurationDataTest and is intended
    ///to contain all ConfigurationDataTest Unit Tests
    ///</summary>
	[TestClass()]
	public class ConfigurationDataTest
	{


		private TestContext testContextInstance;

		/// <summary>
		///Gets or sets the test context which provides
		///information about and functionality for the current test run.
		///</summary>
		public TestContext TestContext
		{
			get
			{
				return testContextInstance;
			}
			set
			{
				testContextInstance = value;
			}
		}

		#region Additional test attributes
		// 
		//You can use the following additional attributes as you write your tests:
		//
		//Use ClassInitialize to run code before running the first test in the class
		//[ClassInitialize()]
		//public static void MyClassInitialize(TestContext testContext)
		//{
		//}
		//
		//Use ClassCleanup to run code after all tests in a class have run
		//[ClassCleanup()]
		//public static void MyClassCleanup()
		//{
		//}
		//
		//Use TestInitialize to run code before running each test
		//[TestInitialize()]
		//public void MyTestInitialize()
		//{
		//}
		//
		//Use TestCleanup to run code after each test has run
		//[TestCleanup()]
		//public void MyTestCleanup()
		//{
		//}
		//
		#endregion


		/// <summary>
		///A test for RetrievedOn
		///</summary>
		[TestMethod()]
		public void RetrievedOnTest()
		{
			ClientConfigurationData target = new ClientConfigurationData();
			DateTime expected = DateTime.Now;
			DateTime actual;
			target.RetrievedOn = expected;
			actual = target.RetrievedOn;
			Assert.AreEqual(expected, actual);
		}

//		/// <summary>
//		///A test for LogLevel
//		///</summary>
//		[TestMethod()]
//		public void LogLevelTest()
//		{
//			ClientConfigurationData target = new ClientConfigurationData();
//			int expected = 0; 
//			int actual;
//			target.LogLevel = expected;
//			actual = target.LogLevel;
//			Assert.AreEqual(expected, actual);
//		}

		/// <summary>
		///A test for LogEnabled
		///</summary>
		[TestMethod()]
		public void LogEnabledTest()
		{
			ClientConfigurationData target = new ClientConfigurationData();
			bool expected = false;
			bool actual;
			target.LogEnabled = expected;
			actual = target.LogEnabled;
			Assert.AreEqual(expected, actual);
		}

		/// <summary>
		///A test for ExpiresInSeconds
		///</summary>
		[TestMethod()]
		public void ExpiresInSecondsTest()
		{
			ClientConfigurationData target = new ClientConfigurationData();
			int expected = 120; 
			int actual;
			target.ExpiresInSeconds = expected;
			actual = target.ExpiresInSeconds;
			Assert.AreEqual(expected, actual);
		}

		/// <summary>
		///A test for Expired
		///</summary>
		[TestMethod()]
		public void ExpiredTest()
		{
			ClientConfigurationData target = new ClientConfigurationData();
			target.ExpiresInSeconds = 30;
			Assert.IsFalse(target.Expired, "ClientConfigurationData should not have expired yet.");
			target.ExpiresInSeconds = 1;
			System.Threading.Thread.Sleep(1005);
			Assert.IsTrue(target.Expired, "ConfigurationData should have expired by now.");
		}

//		/// <summary>
//		///A test for ConfigurationData Constructor
//		///</summary>
//		[TestMethod()]
//		public void ConfigurationDataConstructorTest()
//		{
//			ConfigurationData target = new ConfigurationData();
//			Assert.Inconclusive("TODO: Implement code to verify target");
//		}
	}
}
