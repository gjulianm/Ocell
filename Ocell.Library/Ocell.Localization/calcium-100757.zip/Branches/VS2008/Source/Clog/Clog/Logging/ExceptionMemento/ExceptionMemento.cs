﻿/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="//License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2007/11/19 20:00</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/

using System;
using System.ComponentModel;
using System.Runtime.Serialization;

namespace DanielVaughan.Logging
{
	/// <summary>
	/// Provides information to allow the recreation
	/// of an <see cref="Exception"/>.
	/// </summary>
	[DataContract(Namespace = OrganizationalConstants.DataContractNamespace), Serializable]
	public class ExceptionMemento : IExceptionMemento, IExtensibleDataObject
	{
		/// <summary>
		/// Gets or sets the name of the type of <see cref="Exception"/>.
		/// </summary>
		/// <value>The name of the type.</value>
		[DataMember]
		public string TypeName { get; set; }
		[DataMember]
		public string Message { get; set; }
		[DataMember]
		public string Source { get; set; }
		[DataMember]
		public string StackTrace { get; set; }
		[DataMember]
		public string HelpLink { get; set; }

		/// <summary>
		/// Initializes a new instance of the <see cref="ExceptionMemento"/> class.
		/// </summary>
		public ExceptionMemento()
		{
		}

		public ExceptionMemento(Exception exception)
		{
			if (exception == null)
			{
				throw new ArgumentNullException("exception");
			}
			TypeName = exception.GetType().AssemblyQualifiedName;
			Message = exception.Message;
			Source = exception.Source;
			StackTrace = exception.StackTrace;
			HelpLink = exception.HelpLink;
		}

		public override string ToString()
		{
			return string.Format("{0}  Message: {1} HelpLink: {2}{3}StackTrace: {4}",
				TypeName,
				Message,
				HelpLink,
				Environment.NewLine,
				StackTrace);
		}

		/// <summary>
		/// Gets or sets the structure that contains extra data.
		/// </summary>
		/// <value></value>
		/// <returns>An <see cref="T:System.Runtime.Serialization.ExtensionDataObject"/> 
		/// that contains data that is not recognized as belonging to the data contract.</returns>
		[EditorBrowsable(EditorBrowsableState.Never)]
		public ExtensionDataObject ExtensionData { get; set; }
	}
}
