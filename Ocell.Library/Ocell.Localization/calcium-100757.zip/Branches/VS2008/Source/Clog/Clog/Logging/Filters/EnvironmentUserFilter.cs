﻿/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="//License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2007/11/27 12:44</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/

using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Security;

namespace DanielVaughan.Logging.Filters
{
	/// <summary>
	/// Restricts a log entry based on the current
	/// <see cref="Environment.UserName"/> value,
	/// as specified in the comma delimited <em>users</em> attribute
	/// of the filter element.
	/// </summary>
	class EnvironmentUserFilter : FilterBase
	{
		readonly List<string> users = new List<string>();

		/// <summary>
		/// Gets or sets a set of user names to be used by an <see cref="IFilter"/>.
		/// </summary>
		/// <value>The users.</value>
		public IEnumerable<string> Users
		{
			get
			{
				return users;
			}
		}

		public EnvironmentUserFilter()
		{
			Init += EnvironmentUserFilter_Init;
		}

		void EnvironmentUserFilter_Init(object sender, FilterInitEventArgs e)
		{
			ArgumentValidator.AssertNotNull(e, "e");
			ArgumentValidator.AssertNotNull(e.ConfigurationElement, "e.ConfigurationElement");

			/* Reset state. */
			users.Clear();

			/* TODO: put in util.*/
			var usersAttribute = e.ConfigurationElement.Attributes["Users"];
			if (usersAttribute == null)
			{
				throw new ClientLoggingException("Users attribute does not exists."); /* TODO: Make localizable resource. */
			}
			try
			{
				string usersValue = usersAttribute.Value;
				var userValues = usersValue.Split(new[] {','}, StringSplitOptions.RemoveEmptyEntries);
				users.AddRange(userValues);
			}
			catch (Exception ex)
			{
				throw new ClientLoggingException("Users attribute is invalid. Should be a comma seperated list of names.", ex); /* TODO: Make localizable resource. */
			}

			if (Action == FilterAction.Default)
			{
				Action = FilterAction.Allow;
			}

			if (Action != FilterAction.Allow && Action != FilterAction.Deny)
			{
				throw new ConfigurationErrorsException(InvalidActionMessage);
			}
		}

		public override bool IsValid(LogEntryOrigin origin, IClientInfo info)
		{
			string userName = info.UserName;

			foreach (string name in users)
			{
				if (userName != name)
				{
					continue;
				}

				if (Action == FilterAction.Deny)
				{
					return false;
				}
				if (Action == FilterAction.Allow)
				{
					return true;
				}
			}

			return Action != FilterAction.Allow;
		}
	}
}
