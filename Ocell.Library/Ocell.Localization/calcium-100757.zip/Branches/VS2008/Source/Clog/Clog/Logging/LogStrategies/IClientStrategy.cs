﻿/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="//License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2007-12-12 13:59:30Z</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DanielVaughan.Logging.LogStrategies
{
	/// <summary>
	/// Denotes a log strategy that is used client side.
	/// </summary>
	interface IClientStrategy : ILogStrategy
	{
	}
}
