﻿/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="//License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2007/11/19 20:00</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;

namespace DanielVaughan.Logging.LogStrategies
{
	/// <summary>
	/// A very simple log strategy that outputs
	/// <see cref="ILogEntry"/> instances to the console.
	/// </summary>
	public class ConsoleStrategy : ILogStrategy
	{
		public LogLevel GetLogLevel(IClientInfo clientInfo)
		{
			return LogLevel.All;
		}

		public void Write(IClientLogEntry logEntry)
		{
			ArgumentValidator.AssertNotNull(logEntry, "logEntry");

			string exceptionString = logEntry.ExceptionMemento != null 
				? logEntry.ExceptionMemento.ToString() : string.Empty;
			string text = GetPrintString(logEntry, exceptionString);
			Console.WriteLine(text);
		}

		public void Write(IServerLogEntry logEntry)
		{
			ArgumentValidator.AssertNotNull(logEntry, "logEntry");

			string exceptionString = logEntry.Exception != null 
				? logEntry.Exception.ToString() : string.Empty;
			string text = GetPrintString(logEntry, exceptionString);
			Console.WriteLine(text);
		}

		static string GetPrintString(ILogEntry logEntry, string exceptionString)
		{
			return string.Format("Log: {0} {1} {2} \t {3} {4}, Thread:{5}", logEntry.Message, exceptionString, 
				Environment.NewLine, logEntry.CodeLocation, logEntry.OccuredAt, logEntry.ThreadName);
		}
	}
}
