﻿/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="//License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2007/11/19 20:00</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/

namespace DanielVaughan.Logging
{
	/// <summary>
	/// Indicates where a <see cref="ILogEntry"/> came from.
	/// </summary>
	public enum LogEntryOrigin
	{
		/// <summary>
		/// The <see cref="ILogEntry"/> is client based.
		/// </summary>
		Remote,
		/// <summary>
		/// The <see cref="ILogEntry"/> is server based.
		/// </summary>
		Local
	}
}
