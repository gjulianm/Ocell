﻿/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="//License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2007/11/27 12:44</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/

using System;

namespace DanielVaughan.Logging
{
	/// <summary>
	/// Contains information regarding a logging event.
	/// </summary>
	public class LogEventArgs : EventArgs
	{
		ILogEntry logEntry;

		/// <summary>
		/// Gets the log entry data.
		/// </summary>
		/// <value>The log entry data.</value>
		public ILogEntry LogEntry
		{
			get
			{
				return logEntry;
			}
			internal set
			{
				logEntry = value;
			}
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="LogEventArgs"/> class.
		/// </summary>
		public LogEventArgs()
		{
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="LogEventArgs"/> class.
		/// </summary>
		/// <param name="logEntry">The log entry data.</param>
		public LogEventArgs(ILogEntry logEntry)
		{
			this.logEntry = logEntry;
		}
	}
}
