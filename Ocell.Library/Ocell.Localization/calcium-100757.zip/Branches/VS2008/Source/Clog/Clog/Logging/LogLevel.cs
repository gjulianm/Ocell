﻿/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="//License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2007/11/19 20:00</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/

namespace DanielVaughan.Logging
{
	/// <summary>
	/// Signifies the level at which to write a <see cref="ILogEntry"/>.
	/// Are used to exclude log entries that have log levels
	/// less than the current <see cref="ILogStrategy"/> threshold level.
	/// <seealso cref="ILogStrategy.GetLogLevel"/>.
	/// </summary>
	public enum LogLevel
	{
		/// <summary>
		/// The least restrictive level.
		/// </summary>
		All = 0,
		/// <summary>
		/// For debugging purposes.
		/// </summary>
		Debug = 2,
		/// <summary>
		/// Signifies verbose information.
		/// </summary>
		Info = 4,
		/// <summary>
		/// Signifies a warning from e.g. an unexpected event.
		/// </summary>
		Warn = 8,
		/// <summary>
		/// When an application error occurs.
		/// </summary>
		Error = 16,
		/// <summary>
		/// When the application is no longer
		/// able to function or is in an unreliable state.
		/// Highly restrive logging.
		/// </summary>
		Fatal = 32,
		/// <summary>
		/// Logging is disabled.
		/// </summary>
		None = 64
	}
}
