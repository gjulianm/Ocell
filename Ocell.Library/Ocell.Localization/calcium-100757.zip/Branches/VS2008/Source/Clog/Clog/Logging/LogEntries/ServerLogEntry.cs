﻿/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="//License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2007/11/19 20:00</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/

using System;
using System.Runtime.Serialization;
using System.Xml.Serialization;

namespace DanielVaughan.Logging.LogEntries
{
	[DataContract(Namespace = OrganizationalConstants.DataContractNamespace), Serializable]
	sealed class ServerLogEntry : LogEntryBase, IServerLogEntry
	{
		[XmlIgnore]
		public Exception Exception { get; set; }
		
		[DataMember]
		public string AppDomain { get; set; }
		
		[DataMember]
		public string Identity { get; set; }

		public ServerLogEntry(LogLevel logLevel, string message) : base(logLevel, message)
		{
		}

		public ServerLogEntry(LogLevel logLevel, string message, Exception exception)
			: base(logLevel, message)
		{
			Exception = exception;
		}

		public ServerLogEntry(LogEntryData logEntryData) : base(logEntryData)
		{
			/* Intentionally left blank. */
		}

		public override string ToString()
		{
			string result = string.Format("{0}, AppDomain: {1}, Identity: {2}", base.ToString(), AppDomain, Identity);
			return result;
		}
	}
}
