﻿/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="//License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2007/11/19 20:00</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.Serialization;
using System.Text;

namespace DanielVaughan.Logging.LogEntries
{
	/// <summary>
	/// Contains data pertaining to a <see cref="ILogEntry"/>.
	/// </summary>
	[DataContract(Namespace = OrganizationalConstants.DataContractNamespace), Serializable]
	public class LogEntryData : ClientInfo, ILogEntry
	{
		/// <summary>
		/// Gets or sets the log level of the log entry.
		/// This is the intended level that the log entry should be written.
		/// This may cause the log entry to be ignored if the current
		/// <see cref="ILogStrategy"/> has a higher threshold log level.
		/// </summary>
		/// <value>The log level.</value>
		[DataMember]
		public LogLevel LogLevel { get; set; }

		/// <summary>
		/// Gets or sets the message to be logged.
		/// </summary>
		/// <value>The message.</value>
		[DataMember]
		public string Message { get; set; }

		/// <summary>
		/// Gets or sets the code location of the call to log.
		/// </summary>
		/// <value>The code location.</value>
		[DataMember]
		public CodeLocation CodeLocation { get; set; }

		/// <summary>
		/// Gets or sets the exception memento, representing
		/// an exception that is to be logged.
		/// May be null.
		/// </summary>
		/// <value>The exception memento.</value>
		[DataMember]
		public virtual ExceptionMemento ExceptionMemento { get; set; }

		/// <summary>
		/// Gets or sets the name of the thread that requested
		/// the log entry to take place.
		/// </summary>
		/// <value>The name of the thread.</value>
		[DataMember]
		public string ThreadName { get; set; }
		
		/// <summary>
		/// Gets or sets the managed thread id that requested
		/// the log entry to take place.
		/// </summary>
		/// <value>The managed thread id.</value>
		[DataMember]
		public int ManagedThreadId { get; set; }

		/// <summary>
		/// Gets or sets the time that the log request was made.
		/// </summary>
		/// <value>The time that the log request was made.</value>
		[DataMember]
		public DateTime OccuredAt { get; set; }


		/// <summary>
		/// Gets or sets additional custom properties.
		/// </summary>
		/// <value>The custom properties.</value>
		[DataMember]
		public IDictionary<string, object> Properties { get; set; }

		/// <summary>
		/// Initializes a new instance of the <see cref="LogEntryData"/> class.
		/// </summary>
		public LogEntryData()
		{
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="LogEntryData"/> class.
		/// </summary>
		/// <param name="logEntryData">The log entry data.</param>
		public LogEntryData(ILogEntry logEntryData) : base(logEntryData)
		{
			ArgumentValidator.AssertNotNull(logEntryData, "logEntryData");
			CodeLocation = logEntryData.CodeLocation;
			Message = logEntryData.Message;
			LogLevel = logEntryData.LogLevel;
			ThreadName = logEntryData.ThreadName;
			ManagedThreadId = logEntryData.ManagedThreadId;
			Properties = logEntryData.Properties;
			OccuredAt = logEntryData.OccuredAt;
		}

		public override string ToString()
		{
			var propertiesBuilder = new StringBuilder();
			if (Properties != null)
			{
				foreach (var pair in Properties)
				{
					propertiesBuilder.Append(pair.Key);
					propertiesBuilder.Append('=');
					propertiesBuilder.Append(pair.Value);
					propertiesBuilder.Append(";");
				}
			}

			string result = string.Format("{0} , Message:{1}, LogLevel: {2}, ThreadName: {3}, ManagedThreadId: {4}, Properties: {5}, {6}",
					CodeLocation, Message, LogLevel, ThreadName, ManagedThreadId, propertiesBuilder, base.ToString());
			return result;
		}
	}
}
