// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Revision and Build Numbers 
// by using the '*' as shown below:
using System.Reflection;

[assembly: AssemblyVersion("1.10.0.0")]
[assembly: AssemblyFileVersion(DanielVaughan.AssemblyInfoConstants.AssemblyFileVersion)]