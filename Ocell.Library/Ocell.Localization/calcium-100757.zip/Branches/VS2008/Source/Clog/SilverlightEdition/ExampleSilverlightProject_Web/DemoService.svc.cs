﻿using System;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.Collections.Generic;
using System.Text;

using DanielVaughan.Logging;

namespace Orpius.Logging
{
	[ServiceContract(Namespace = "")]
	[AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
	public class DemoService
	{
		[OperationContract]
		public void RaiseExceptionAfterLogMessage()
		{
			try
			{
				throw new Exception("test");
			}
			catch (Exception ex)
			{
				Log.Error("test", ex);
				throw;
			}
			return;
		}

	}

}
