﻿#region File and License Information
/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="//License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2008-05-03 21:50:20Z</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/
#endregion

using System.Collections.Generic;

namespace DanielVaughan.Logging
{
	public static class GenericUtil
	{
		public static List<T> ListOfType<T>(this T type)
		{
			return new List<T>();
		}
	}
}
