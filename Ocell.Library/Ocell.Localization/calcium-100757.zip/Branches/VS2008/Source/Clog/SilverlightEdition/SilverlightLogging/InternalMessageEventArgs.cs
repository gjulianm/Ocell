﻿/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="//License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2007-12-07 00:26:12Z</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/

using System;

namespace DanielVaughan.Logging
{
	public class InternalMessageEventArgs : EventArgs
	{
		public Exception Exception { get; protected set; }
		public string Message { get; protected set; }

		public InternalMessageEventArgs(Exception exception) : this(null, exception)
		{
		}

		public InternalMessageEventArgs(string message, Exception exception)
		{
			Message = message;
			Exception = exception;
		}

		public InternalMessageEventArgs(string message) : this(message, null)
		{
		}
	}
}
