﻿/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="//License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2007/11/19 20:00</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/

#define TEST

#if TEST && DEBUG

using System;
using System.Threading;

namespace DanielVaughan.Logging.Tests
{
	/// <summary>
	/// A few tests for the client side
	/// Silverlight logging. This will be replaced
	/// when we have a Silverlight unit testing framework.
	/// </summary>
	public class LogTests
	{
		static readonly ILog log = LogManager.GetLog(typeof(LogTests));

		/// <summary>
		/// Runs all the tests in the suite.
		/// </summary>
		/// <returns></returns>
		public bool TestSuite()
		{
			bool result = false;
			try
			{
				result = TestSuiteAux();
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex);
			}
			return result;
		}

		bool TestSuiteAux()
		{
			//bool result = false;

			log.Debug("Test Debug message.");
			log.Debug("Test Debug message.", CreateException());
			log.Info("Test Info message.");
			log.Info("Test Info message.", CreateException());
			log.Warn("Test Warn message.");
			log.Warn("Test Warn message.", CreateException());
			log.Error("Test Error message.");
			log.Error("Test Error message.", CreateException());
			log.Fatal("Test Fatal message.");
			log.Fatal("Test Fatal message.", CreateException());

			ThreadPool.QueueUserWorkItem(delegate { log.Info("Test Info message Async."); }, null);

			for (int i = 0; i < 100; i++)
			{
				log.Debug("Test Looped Debug message " + i);
			}

			return true;
		}

		Exception CreateException()
		{
			Exception result = null;
			try
			{
				int divisor = 0;
				double i = 1 / divisor;
			}
			catch (Exception ex)
			{
				result = ex;
			}
			return result;
		}
	}

}
#endif