﻿/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="//License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2007/11/19 20:00</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/

using System;

using DanielVaughan.Logging.ClientLogging;

namespace DanielVaughan.Logging
{
	/// <summary>
	/// Information regarding a logging event.
	/// </summary>
	public class LogEventArgs : EventArgs
	{
		ClientLogging.LogEntryData logEntryData;

		/// <summary>
		/// Gets the log entry data.
		/// </summary>
		/// <value>The log entry data.</value>
		public ClientLogging.LogEntryData LogEntryData
		{
			get
			{
				return logEntryData;
			}
			internal set
			{
				logEntryData = value;
			}
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="LogEventArgs"/> class.
		/// </summary>
		public LogEventArgs()
		{
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="LogEventArgs"/> class.
		/// </summary>
		/// <param name="logEntryData">The log entry data.</param>
		public LogEventArgs(LogEntryData logEntryData)
		{
			this.logEntryData = logEntryData;
		}
	}
}
