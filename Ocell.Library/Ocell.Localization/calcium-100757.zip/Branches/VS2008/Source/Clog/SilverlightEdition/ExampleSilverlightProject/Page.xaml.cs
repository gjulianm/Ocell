﻿using System;
using System.Collections.Generic;
using System.Windows;
using DanielVaughan.Logging;

using Orpius.Logging.DemoServiceReference;

namespace ExampleSilverlightProject
{
    public partial class Page
    {
		static readonly ILog log = LogManager.GetLog(typeof(Page));
		int logDebugCount;
		int logMessageCount;
		int logErrorCount;

        public Page()
        {
            InitializeComponent();
			Loaded += Page_Loaded;
        }

		void Page_Loaded(object sender, RoutedEventArgs e)
		{
			LogViewer.OfflineMode = false;
			if (log.InfoEnabled)
			{
				log.Info("Page loaded.");
			}
			//throw new Exception("This is an exception thrown to test logging on ApplicationUnhandledException event.");
		}

		void Button_LogDebug_Click(object sender, RoutedEventArgs e)
		{
			string message = "Button \"Log Debug\" clicked " + ++logDebugCount + " times.";
			TextBlock_LogEntries.Text = "Logging: " + message
				+ Environment.NewLine
				+ "Note that messages will not be sent to the server if the LogLevel on the server is greater.";
			log.Debug(message);
		}

		void Button_LogInfo_Click(object sender, RoutedEventArgs e)
		{
			string message = "Button \"Log Info\" clicked " + ++logMessageCount + " times.";
			TextBlock_LogEntries.Text = "Logging with custom properties: " + Environment.NewLine + message;
			var properties = new Dictionary<string, object> { {"UserName", "DanielVaughan"} };
			log.Info(message, properties);
		}

		void Button_LogException_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				int divisor = 0;
				double i = 1 / divisor;
			}
			catch (Exception ex)
			{
				string message = "Button \"Log Exception\" clicked " + ++logErrorCount + " times.";
				TextBlock_LogEntries.Text = "Logging: " + Environment.NewLine + message + " (including Exception information)";
				log.Error(message, ex);
			}
//			try
//			{
//				DemoServiceClient serviceClient = new DemoServiceClient();
//				serviceClient.DoWorkCompleted += new EventHandler<System.ComponentModel.AsyncCompletedEventArgs>(serviceClient_DoWorkCompleted);
//							serviceClient.DoWorkAsync();
//			}
//			catch (Exception ex)
//			{
//
//			}
			
		}

		void serviceClient_DoWorkCompleted(object sender, System.ComponentModel.AsyncCompletedEventArgs e)
		{
			
		}

		void Button_RunTests_Click(object sender, RoutedEventArgs e)
		{
#if TEST && DEBUG
			DanielVaughan.Logging.Tests.LogTests logTests = new DanielVaughan.Logging.Tests.LogTests();
			string message;
			if (logTests.TestSuite())
			{
				message = "Tests ran without throwing exception.";
			}
			else
			{
				message = "Tests failed.";
			}
			TextBlock_LogEntries.Text = message;
#else
			TextBlock_LogEntries.Text = "Tests disabled for non test builds.";
#endif

		}
    }
}
