﻿/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="//License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2007/11/19 20:00</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
	<Contributions>
		<Contribution><Date>2009-04-09</Date><Name>Michael Gerfen</Name>
						<Description>Added param support.</Description></Contribution>
	</Contributions>
</File>
*/

using System;
using System.Collections.Generic;

using DanielVaughan.Logging.ClientLogging;

namespace DanielVaughan.Logging
{
	/// <summary>
	/// A log is responsible for sending log messages to the server.
	/// </summary>
	public interface ILog
	{
		event EventHandler<InternalMessageEventArgs> InternalMessage;

		/// <summary>
		/// Gets the name of the log.
		/// This is used to filter log entries on the server.
		/// </summary>
		/// <value>The name of this log.</value>
		string Name
		{
			get;
		}

		/// <summary>
		/// Occurs when a log entry is sent to the server.
		/// </summary>
		event EventHandler<LogEventArgs> LogEntrySent;

		/// <summary>
		/// Occurs when any request to log is made.
		/// This will be raised at equal or greater frequency
		/// than the <see cref="LogEntrySent"/> <code>event</code>.
		/// </summary>
		event EventHandler<LogEventArgs> WriteRequested;

		#region Enabled properties
		/// <summary>
		/// Gets a value indicating whether debug is enabled. If <code>true</code>
		/// calls to Debug will be attempted, otherwise they will be ignored.
		/// </summary>
		/// <value><c>true</c> if debug is enabled; otherwise, <c>false</c>.</value>
		bool DebugEnabled
		{ 
			get;
		}

		/// <summary>
		/// Gets a value indicating whether info is enabled. If <code>true</code>
		/// calls to Info will be attempted, otherwise they will be ignored.
		/// </summary>
		/// <value><c>true</c> if info is enabled; otherwise, <c>false</c>.</value>
		bool InfoEnabled
		{ 
			get;
		}

		/// <summary>
		/// Gets a value indicating whether warn is enabled. If <code>true</code>
		/// calls to Warn will be attempted, otherwise they will be ignored.
		/// </summary>
		/// <value><c>true</c> if warn is enabled; otherwise, <c>false</c>.</value>
		bool WarnEnabled
		{ 
			get;
		}

		/// <summary>
		/// Gets a value indicating whether error is enabled. If <code>true</code>
		/// calls to Error will be attempted, otherwise they will be ignored.
		/// </summary>
		/// <value><c>true</c> if error is enabled; otherwise, <c>false</c>.</value>
		bool ErrorEnabled
		{ 
			get;
		}

		/// <summary>
		/// Gets a value indicating whether fatal is enabled. If <code>true</code>
		/// calls to Fatal will be attempted, otherwise they will be ignored.
		/// </summary>
		/// <value><c>true</c> if fatal is enabled; otherwise, <c>false</c>.</value>
		bool FatalEnabled
		{ 
			get;
		}
		#endregion

		#region Write methods
		/// <summary>
		/// Writes a log entry at the <see cref="ClientLogging.LogLevel.Debug"/>.
		/// </summary>
		/// <param name="message">The message to write.</param>
		void Debug(string message);

		/// <summary>
		/// Writes a log entry at the <see cref="ClientLogging.LogLevel.Debug"/>.
		/// </summary>
		/// <param name="message">The message to write.</param>
		/// <param name="exception">The exception that this message 
		/// is regarding.</param>
		void Debug(string message, Exception exception);

		/// <summary>
		/// Writes a log entry at the <see cref="ClientLogging.LogLevel.Debug"/>.
		/// </summary>
		/// <param name="message">The message to write.</param>
		/// <param name="properties">Custom properties 
		/// to add additional logging information.</param>
		void Debug(string message, IDictionary<string, object> properties);

		/// <summary>
		/// Writes a log entry at the <see cref="ClientLogging.LogLevel.Debug"/>.
		/// </summary>
		/// <param name="message">The message to write.</param>
		/// <param name="exception">The exception that this message 
		/// is regarding.</param>
		/// <param name="properties">Custom properties 
		/// to add additional logging information.</param>
		void Debug(string message, Exception exception, IDictionary<string, object> properties);

		/// <summary>
		/// Writes a log entry at the <see cref="ClientLogging.LogLevel.Debug"/>.
		/// </summary>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		void DebugFormat(string message, params object[] args);

		/// <summary>
		/// Writes a log entry at the <see cref="ClientLogging.LogLevel.Debug"/>.
		/// </summary>
		/// <param name="provider">The provider which provides culture-specific formatting information.</param>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		void DebugFormat(IFormatProvider provider, string message, params object[] args);

		/// <summary>
		/// Writes a log entry at the <see cref="ClientLogging.LogLevel.Debug"/>.
		/// </summary>
		/// <param name="exception">The exception that this message
		/// is regarding.</param>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		void DebugFormat(Exception exception, string message, params object[] args);

		/// <summary>
		/// Writes a log entry at the <see cref="ClientLogging.LogLevel.Debug"/>.
		/// </summary>
		/// <param name="exception">The exception that this message
		/// is regarding.</param>
		/// <param name="provider">The provider which provides culture-specific formatting information.</param>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		void DebugFormat(Exception exception, IFormatProvider provider, string message, params object[] args);

		/// <summary>
		/// Writes a log entry at the <see cref="ClientLogging.LogLevel.Debug"/>.
		/// </summary>
		/// <param name="exception">The exception that this message
		/// is regarding.</param>
		/// <param name="properties">Custom properties
		/// to add additional logging information.</param>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		void DebugFormat(Exception exception, IDictionary<string, object> properties, string message, params object[] args);


		/// <summary>
		/// Writes a log entry at the <see cref="ClientLogging.LogLevel.Debug"/>.
		/// </summary>
		/// <param name="exception">The exception that this message
		/// is regarding.</param>
		/// <param name="properties">Custom properties
		/// to add additional logging information.</param>
		/// <param name="provider">The provider which provides culture-specific formatting information.</param>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		void DebugFormat(Exception exception, IDictionary<string, object> properties, IFormatProvider provider, string message, params object[] args);

		/// <summary>
		/// Writes a log entry at the <see cref="ClientLogging.LogLevel.Info"/>.
		/// </summary>
		/// <param name="message">The message to write.</param>
		void Info(string message);

		/// <summary>
		/// Writes a log entry at the <see cref="ClientLogging.LogLevel.Info"/>.
		/// </summary>
		/// <param name="message">The message to write.</param>
		/// <param name="exception">The exception that this message 
		/// is regarding.</param>
		void Info(string message, Exception exception);

		/// <summary>
		/// Writes a log entry at the <see cref="ClientLogging.LogLevel.Info"/>.
		/// </summary>
		/// <param name="message">The message to write.</param>
		/// <param name="properties">Custom properties 
		/// to add additional logging information.</param>
		void Info(string message, IDictionary<string, object> properties);

		/// <summary>
		/// Writes a log entry at the <see cref="ClientLogging.LogLevel.Info"/>.
		/// </summary>
		/// <param name="message">The message to write.</param>
		/// <param name="exception">The exception that this message 
		/// is regarding.</param>
		/// <param name="properties">Custom properties 
		/// to add additional logging information.</param>
		void Info(string message, Exception exception, IDictionary<string, object> properties);

		/// <summary>
		/// Writes a log entry at the <see cref="ClientLogging.LogLevel.Info"/>.
		/// </summary>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		void InfoFormat(string message, params object[] args);

		/// <summary>
		/// Writes a log entry at the <see cref="ClientLogging.LogLevel.Info"/>.
		/// </summary>
		/// <param name="provider">The provider which provides culture-specific formatting information.</param>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		void InfoFormat(IFormatProvider provider, string message, params object[] args);

		/// <summary>
		/// Writes a log entry at the <see cref="ClientLogging.LogLevel.Info"/>.
		/// </summary>
		/// <param name="exception">The exception that this message
		/// is regarding.</param>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		void InfoFormat(Exception exception, string message, params object[] args);

		/// <summary>
		/// Writes a log entry at the <see cref="ClientLogging.LogLevel.Info"/>.
		/// </summary>
		/// <param name="exception">The exception that this message
		/// is regarding.</param>
		/// <param name="provider">The provider which provides culture-specific formatting information.</param>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		void InfoFormat(Exception exception, IFormatProvider provider, string message, params object[] args);

		/// <summary>
		/// Writes a log entry at the <see cref="ClientLogging.LogLevel.Info"/>.
		/// </summary>
		/// <param name="exception">The exception that this message
		/// is regarding.</param>
		/// <param name="properties">Custom properties
		/// to add additional logging information.</param>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		void InfoFormat(Exception exception, IDictionary<string, object> properties, string message, params object[] args);


		/// <summary>
		/// Writes a log entry at the <see cref="ClientLogging.LogLevel.Info"/>.
		/// </summary>
		/// <param name="exception">The exception that this message
		/// is regarding.</param>
		/// <param name="properties">Custom properties
		/// to add additional logging information.</param>
		/// <param name="provider">The provider which provides culture-specific formatting information.</param>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		void InfoFormat(Exception exception, IDictionary<string, object> properties, IFormatProvider provider, string message, params object[] args);

		/// <summary>
		/// Writes a log entry at the <see cref="ClientLogging.LogLevel.Warn"/>.
		/// </summary>
		/// <param name="message">The message to write.</param>
		void Warn(string message);

		/// <summary>
		/// Writes a log entry at the <see cref="ClientLogging.LogLevel.Warn"/>.
		/// </summary>
		/// <param name="message">The message to write.</param>
		/// <param name="exception">The exception that this message 
		/// is regarding.</param>
		void Warn(string message, Exception exception);

		/// <summary>
		/// Writes a log entry at the <see cref="ClientLogging.LogLevel.Warn"/>.
		/// </summary>
		/// <param name="message">The message to write.</param>
		/// <param name="properties">Custom properties 
		/// to add additional logging information.</param>
		void Warn(string message, IDictionary<string, object> properties);

		/// <summary>
		/// Writes a log entry at the <see cref="ClientLogging.LogLevel.Warn"/>.
		/// </summary>
		/// <param name="message">The message to write.</param>
		/// <param name="exception">The exception that this message 
		/// is regarding.</param>
		/// <param name="properties">Custom properties 
		/// to add additional logging information.</param>
		void Warn(string message, Exception exception, IDictionary<string, object> properties);

		/// <summary>
		/// Writes a log entry at the <see cref="ClientLogging.LogLevel.Warn"/>.
		/// </summary>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		void WarnFormat(string message, params object[] args);

		/// <summary>
		/// Writes a log entry at the <see cref="ClientLogging.LogLevel.Warn"/>.
		/// </summary>
		/// <param name="provider">The provider which provides culture-specific formatting information.</param>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		void WarnFormat(IFormatProvider provider, string message, params object[] args);

		/// <summary>
		/// Writes a log entry at the <see cref="ClientLogging.LogLevel.Warn"/>.
		/// </summary>
		/// <param name="exception">The exception that this message
		/// is regarding.</param>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		void WarnFormat(Exception exception, string message, params object[] args);

		/// <summary>
		/// Writes a log entry at the <see cref="ClientLogging.LogLevel.Warn"/>.
		/// </summary>
		/// <param name="exception">The exception that this message
		/// is regarding.</param>
		/// <param name="provider">The provider which provides culture-specific formatting information.</param>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		void WarnFormat(Exception exception, IFormatProvider provider, string message, params object[] args);

		/// <summary>
		/// Writes a log entry at the <see cref="ClientLogging.LogLevel.Warn"/>.
		/// </summary>
		/// <param name="exception">The exception that this message
		/// is regarding.</param>
		/// <param name="properties">Custom properties
		/// to add additional logging information.</param>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		void WarnFormat(Exception exception, IDictionary<string, object> properties, string message, params object[] args);


		/// <summary>
		/// Writes a log entry at the <see cref="ClientLogging.LogLevel.Warn"/>.
		/// </summary>
		/// <param name="exception">The exception that this message
		/// is regarding.</param>
		/// <param name="properties">Custom properties
		/// to add additional logging information.</param>
		/// <param name="provider">The provider which provides culture-specific formatting information.</param>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		void WarnFormat(Exception exception, IDictionary<string, object> properties, IFormatProvider provider, string message, params object[] args);

		/// <summary>
		/// Writes a log entry at the <see cref="ClientLogging.LogLevel.Error"/>.
		/// </summary>
		/// <param name="message">The message to write.</param>
		void Error(string message);

		/// <summary>
		/// Writes a log entry at the <see cref="ClientLogging.LogLevel.Error"/>.
		/// </summary>
		/// <param name="message">The message to write.</param>
		/// <param name="exception">The exception that this message 
		/// is regarding.</param>
		void Error(string message, Exception exception);

		/// <summary>
		/// Writes a log entry at the <see cref="ClientLogging.LogLevel.Error"/>.
		/// </summary>
		/// <param name="message">The message to write.</param>
		/// <param name="properties">Custom properties 
		/// to add additional logging information.</param>
		void Error(string message, IDictionary<string, object> properties);

		/// <summary>
		/// Writes a log entry at the <see cref="ClientLogging.LogLevel.Error"/>.
		/// </summary>
		/// <param name="message">The message to write.</param>
		/// <param name="exception">The exception that this message 
		/// is regarding.</param>
		/// <param name="properties">Custom properties 
		/// to add additional logging information.</param>
		void Error(string message, Exception exception, IDictionary<string, object> properties);

		/// <summary>
		/// Writes a log entry at the <see cref="ClientLogging.LogLevel.Error"/>.
		/// </summary>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		void ErrorFormat(string message, params object[] args);

		/// <summary>
		/// Writes a log entry at the <see cref="ClientLogging.LogLevel.Error"/>.
		/// </summary>
		/// <param name="provider">The provider which provides culture-specific formatting information.</param>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		void ErrorFormat(IFormatProvider provider, string message, params object[] args);

		/// <summary>
		/// Writes a log entry at the <see cref="ClientLogging.LogLevel.Error"/>.
		/// </summary>
		/// <param name="exception">The exception that this message
		/// is regarding.</param>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		void ErrorFormat(Exception exception, string message, params object[] args);

		/// <summary>
		/// Writes a log entry at the <see cref="ClientLogging.LogLevel.Error"/>.
		/// </summary>
		/// <param name="exception">The exception that this message
		/// is regarding.</param>
		/// <param name="provider">The provider which provides culture-specific formatting information.</param>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		void ErrorFormat(Exception exception, IFormatProvider provider, string message, params object[] args);

		/// <summary>
		/// Writes a log entry at the <see cref="ClientLogging.LogLevel.Error"/>.
		/// </summary>
		/// <param name="exception">The exception that this message
		/// is regarding.</param>
		/// <param name="properties">Custom properties
		/// to add additional logging information.</param>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		void ErrorFormat(Exception exception, IDictionary<string, object> properties, string message, params object[] args);


		/// <summary>
		/// Writes a log entry at the <see cref="ClientLogging.LogLevel.Error"/>.
		/// </summary>
		/// <param name="exception">The exception that this message
		/// is regarding.</param>
		/// <param name="properties">Custom properties
		/// to add additional logging information.</param>
		/// <param name="provider">The provider which provides culture-specific formatting information.</param>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		void ErrorFormat(Exception exception, IDictionary<string, object> properties, IFormatProvider provider, string message, params object[] args);

		/// <summary>
		/// Writes a log entry at the <see cref="ClientLogging.LogLevel.Fatal"/>.
		/// </summary>
		/// <param name="message">The message to write.</param>
		void Fatal(string message);

		/// <summary>
		/// Writes a log entry at the <see cref="ClientLogging.LogLevel.Fatal"/>.
		/// </summary>
		/// <param name="message">The message to write.</param>
		/// <param name="exception">The exception that this message 
		/// is regarding.</param>
		void Fatal(string message, Exception exception);

		/// <summary>
		/// Writes a log entry at the <see cref="ClientLogging.LogLevel.Fatal"/>.
		/// </summary>
		/// <param name="message">The message to write.</param>
		/// <param name="properties">Custom properties 
		/// to add additional logging information.</param>
		void Fatal(string message, IDictionary<string, object> properties);

		/// <summary>
		/// Writes a log entry at the <see cref="LogLevel.Fatal"/>.
		/// </summary>
		/// <param name="message">The message to write.</param>
		/// <param name="exception">The exception that this message 
		/// is regarding.</param>
		/// <param name="properties">Custom properties 
		/// to add additional logging information.</param>
		void Fatal(string message, Exception exception, IDictionary<string, object> properties);

		/// <summary>
		/// Writes a log entry at the <see cref="ClientLogging.LogLevel.Fatal"/>.
		/// </summary>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		void FatalFormat(string message, params object[] args);

		/// <summary>
		/// Writes a log entry at the <see cref="ClientLogging.LogLevel.Fatal"/>.
		/// </summary>
		/// <param name="provider">The provider which provides culture-specific formatting information.</param>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		void FatalFormat(IFormatProvider provider, string message, params object[] args);

		/// <summary>
		/// Writes a log entry at the <see cref="ClientLogging.LogLevel.Fatal"/>.
		/// </summary>
		/// <param name="exception">The exception that this message
		/// is regarding.</param>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		void FatalFormat(Exception exception, string message, params object[] args);

		/// <summary>
		/// Writes a log entry at the <see cref="ClientLogging.LogLevel.Fatal"/>.
		/// </summary>
		/// <param name="exception">The exception that this message
		/// is regarding.</param>
		/// <param name="provider">The provider which provides culture-specific formatting information.</param>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		void FatalFormat(Exception exception, IFormatProvider provider, string message, params object[] args);

		/// <summary>
		/// Writes a log entry at the <see cref="ClientLogging.LogLevel.Fatal"/>.
		/// </summary>
		/// <param name="exception">The exception that this message
		/// is regarding.</param>
		/// <param name="properties">Custom properties
		/// to add additional logging information.</param>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		void FatalFormat(Exception exception, IDictionary<string, object> properties, string message, params object[] args);


		/// <summary>
		/// Writes a log entry at the <see cref="ClientLogging.LogLevel.Fatal"/>.
		/// </summary>
		/// <param name="exception">The exception that this message
		/// is regarding.</param>
		/// <param name="properties">Custom properties
		/// to add additional logging information.</param>
		/// <param name="provider">The provider which provides culture-specific formatting information.</param>
		/// <param name="message">The message to write.</param>
		/// <param name="args">The arguments used to format the supplied message.</param>
		void FatalFormat(Exception exception, IDictionary<string, object> properties, IFormatProvider provider, string message, params object[] args);
		#endregion
	}
}
