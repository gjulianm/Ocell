﻿#region File and License Information
/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="//License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2009-04-09 23:00:38Z</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
	<Contributions>
		<Contribution><Date>2009-04-09</Date><Name>Michael Gerfen</Name>
						<Description>Added param support.</Description></Contribution>
	</Contributions>
</File>
*/
#endregion

using System;
using System.Collections.Generic;

using DanielVaughan.Logging.ClientLogging;

namespace DanielVaughan.Logging
{
	partial class Log
	{
		#region Enabled properties (Short-circuiting)
		public bool DebugEnabled
		{
			get
			{
				return IsLevelEnabled(LogLevel.Debug);
			}
		}

		public bool InfoEnabled
		{
			get
			{
				return IsLevelEnabled(LogLevel.Info);
			}
		}

		public bool WarnEnabled
		{
			get
			{
				return IsLevelEnabled(LogLevel.Warn);
			}
		}

		public bool ErrorEnabled
		{
			get
			{
				return IsLevelEnabled(LogLevel.Error);
			}
		}

		public bool FatalEnabled
		{
			get
			{
				return IsLevelEnabled(LogLevel.Fatal);
			}
		}
		#endregion

		#region Logging Overloads
		public void Debug(string message)
		{
			WriteLogEntry(LogLevel.Debug, message, null, null);
		}

		public void Debug(string message, IDictionary<string, object> properties)
		{
			WriteLogEntry(LogLevel.Debug, message, null, properties);
		}

		public void Debug(string message, Exception exception)
		{
			WriteLogEntry(LogLevel.Debug, message, exception, null);
		}

		public void Debug(string message, Exception exception, IDictionary<string, object> properties)
		{
			WriteLogEntry(LogLevel.Debug, message, exception, properties);
		}

		public void DebugFormat(string message, params object[] args)
		{
			string formattedMessage = String.Format(message, args);
			WriteLogEntry(LogLevel.Debug, formattedMessage, null, null);
		}

		public void DebugFormat(IFormatProvider provider, string message, params object[] args)
		{
			string formattedMessage = String.Format(provider, message, args);
			WriteLogEntry(LogLevel.Debug, formattedMessage, null, null);
		}

		public void DebugFormat(Exception exception, string message, params object[] args)
		{
			string formattedMessage = String.Format(message, args);
			WriteLogEntry(LogLevel.Debug, formattedMessage, exception, null);
		}

		public void DebugFormat(Exception exception, IFormatProvider provider, string message, params object[] args)
		{
			string formattedMessage = String.Format(provider, message, args);
			WriteLogEntry(LogLevel.Debug, formattedMessage, exception, null);
		}

		public void DebugFormat(Exception exception, IDictionary<string, object> properties, string message, params object[] args)
		{
			string formattedMessage = String.Format(message, args);
			WriteLogEntry(LogLevel.Debug, formattedMessage, exception, properties);
		}

		public void DebugFormat(Exception exception, IDictionary<string, object> properties, IFormatProvider provider, string message, params object[] args)
		{
			string formattedMessage = String.Format(provider, message, args);
			WriteLogEntry(LogLevel.Debug, formattedMessage, exception, properties);
		}

		public void Info(string message)
		{
			WriteLogEntry(LogLevel.Info, message, null, null);
		}

		public void Info(string message, IDictionary<string, object> properties)
		{
			WriteLogEntry(LogLevel.Info, message, null, properties);
		}

		public void Info(string message, Exception exception)
		{
			WriteLogEntry(LogLevel.Info, message, exception, null);
		}

		public void Info(string message, Exception exception, IDictionary<string, object> properties)
		{
			WriteLogEntry(LogLevel.Info, message, exception, properties);
		}

		public void InfoFormat(string message, params object[] args)
		{
			string formattedMessage = String.Format(message, args);
			WriteLogEntry(LogLevel.Info, formattedMessage, null, null);
		}

		public void InfoFormat(IFormatProvider provider, string message, params object[] args)
		{
			string formattedMessage = String.Format(provider, message, args);
			WriteLogEntry(LogLevel.Info, formattedMessage, null, null);
		}

		public void InfoFormat(Exception exception, string message, params object[] args)
		{
			string formattedMessage = String.Format(message, args);
			WriteLogEntry(LogLevel.Info, formattedMessage, exception, null);
		}

		public void InfoFormat(Exception exception, IFormatProvider provider, string message, params object[] args)
		{
			string formattedMessage = String.Format(provider, message, args);
			WriteLogEntry(LogLevel.Info, formattedMessage, exception, null);
		}

		public void InfoFormat(Exception exception, IDictionary<string, object> properties, string message, params object[] args)
		{
			string formattedMessage = String.Format(message, args);
			WriteLogEntry(LogLevel.Info, formattedMessage, exception, properties);
		}

		public void InfoFormat(Exception exception, IDictionary<string, object> properties, IFormatProvider provider, string message, params object[] args)
		{
			string formattedMessage = String.Format(provider, message, args);
			WriteLogEntry(LogLevel.Info, formattedMessage, exception, properties);
		}

		public void Warn(string message)
		{
			WriteLogEntry(LogLevel.Warn, message, null, null);
		}

		public void Warn(string message, IDictionary<string, object> properties)
		{
			WriteLogEntry(LogLevel.Warn, message, null, properties);
		}

		public void Warn(string message, Exception exception)
		{
			WriteLogEntry(LogLevel.Warn, message, exception, null);
		}

		public void Warn(string message, Exception exception, IDictionary<string, object> properties)
		{
			WriteLogEntry(LogLevel.Warn, message, exception, properties);
		}

		public void WarnFormat(string message, params object[] args)
		{
			string formattedMessage = String.Format(message, args);
			WriteLogEntry(LogLevel.Warn, formattedMessage, null, null);
		}

		public void WarnFormat(IFormatProvider provider, string message, params object[] args)
		{
			string formattedMessage = String.Format(provider, message, args);
			WriteLogEntry(LogLevel.Warn, formattedMessage, null, null);
		}

		public void WarnFormat(Exception exception, string message, params object[] args)
		{
			string formattedMessage = String.Format(message, args);
			WriteLogEntry(LogLevel.Warn, formattedMessage, exception, null);
		}

		public void WarnFormat(Exception exception, IFormatProvider provider, string message, params object[] args)
		{
			string formattedMessage = String.Format(provider, message, args);
			WriteLogEntry(LogLevel.Warn, formattedMessage, exception, null);
		}

		public void WarnFormat(Exception exception, IDictionary<string, object> properties, string message, params object[] args)
		{
			string formattedMessage = String.Format(message, args);
			WriteLogEntry(LogLevel.Warn, formattedMessage, exception, properties);
		}

		public void WarnFormat(Exception exception, IDictionary<string, object> properties, IFormatProvider provider, string message, params object[] args)
		{
			string formattedMessage = String.Format(provider, message, args);
			WriteLogEntry(LogLevel.Warn, formattedMessage, exception, properties);
		}

		public void Error(string message)
		{
			WriteLogEntry(LogLevel.Error, message, null, null);
		}

		public void Error(string message, IDictionary<string, object> properties)
		{
			WriteLogEntry(LogLevel.Error, message, null, properties);
		}

		public void Error(string message, Exception exception)
		{
			WriteLogEntry(LogLevel.Error, message, exception, null);
		}

		public void Error(string message, Exception exception, IDictionary<string, object> properties)
		{
			WriteLogEntry(LogLevel.Error, message, exception, properties);
		}

		public void ErrorFormat(string message, params object[] args)
		{
			string formattedMessage = String.Format(message, args);
			WriteLogEntry(LogLevel.Error, formattedMessage, null, null);
		}

		public void ErrorFormat(IFormatProvider provider, string message, params object[] args)
		{
			string formattedMessage = String.Format(provider, message, args);
			WriteLogEntry(LogLevel.Error, formattedMessage, null, null);
		}

		public void ErrorFormat(Exception exception, string message, params object[] args)
		{
			string formattedMessage = String.Format(message, args);
			WriteLogEntry(LogLevel.Error, formattedMessage, exception, null);
		}

		public void ErrorFormat(Exception exception, IFormatProvider provider, string message, params object[] args)
		{
			string formattedMessage = String.Format(provider, message, args);
			WriteLogEntry(LogLevel.Error, formattedMessage, exception, null);
		}

		public void ErrorFormat(Exception exception, IDictionary<string, object> properties, string message, params object[] args)
		{
			string formattedMessage = String.Format(message, args);
			WriteLogEntry(LogLevel.Error, formattedMessage, exception, properties);
		}

		public void ErrorFormat(Exception exception, IDictionary<string, object> properties, IFormatProvider provider, string message, params object[] args)
		{
			string formattedMessage = String.Format(provider, message, args);
			WriteLogEntry(LogLevel.Error, formattedMessage, exception, properties);
		}

		public void Fatal(string message)
		{
			WriteLogEntry(LogLevel.Fatal, message, null, null);
		}

		public void Fatal(string message, IDictionary<string, object> properties)
		{
			WriteLogEntry(LogLevel.Fatal, message, null, properties);
		}

		public void Fatal(string message, Exception exception)
		{
			WriteLogEntry(LogLevel.Fatal, message, exception, null);
		}

		public void Fatal(string message, Exception exception, IDictionary<string, object> properties)
		{
			WriteLogEntry(LogLevel.Fatal, message, exception, properties);
		}

		public void FatalFormat(string message, params object[] args)
		{
			string formattedMessage = String.Format(message, args);
			WriteLogEntry(LogLevel.Fatal, formattedMessage, null, null);
		}

		public void FatalFormat(IFormatProvider provider, string message, params object[] args)
		{
			string formattedMessage = String.Format(provider, message, args);
			WriteLogEntry(LogLevel.Fatal, formattedMessage, null, null);
		}

		public void FatalFormat(Exception exception, string message, params object[] args)
		{
			string formattedMessage = String.Format(message, args);
			WriteLogEntry(LogLevel.Fatal, formattedMessage, exception, null);
		}

		public void FatalFormat(Exception exception, IFormatProvider provider, string message, params object[] args)
		{
			string formattedMessage = String.Format(provider, message, args);
			WriteLogEntry(LogLevel.Fatal, formattedMessage, exception, null);
		}

		public void FatalFormat(Exception exception, IDictionary<string, object> properties, string message, params object[] args)
		{
			string formattedMessage = String.Format(message, args);
			WriteLogEntry(LogLevel.Fatal, formattedMessage, exception, properties);
		}

		public void FatalFormat(Exception exception, IDictionary<string, object> properties, IFormatProvider provider, string message, params object[] args)
		{
			string formattedMessage = String.Format(provider, message, args);
			WriteLogEntry(LogLevel.Fatal, formattedMessage, exception, properties);
		}
		#endregion
	}
}
