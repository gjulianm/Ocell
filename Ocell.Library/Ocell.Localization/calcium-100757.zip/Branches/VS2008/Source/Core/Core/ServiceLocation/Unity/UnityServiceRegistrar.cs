#region File and License Information
/*
<File>
	<Copyright>Copyright � 2009, Daniel Vaughan. All rights reserved.</Copyright>
	<License>
	This file is part of Daniel Vaughan's Core Library

    Daniel Vaughan's Core Library is free software: you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Daniel Vaughan's Core Library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public License
    along with Daniel Vaughan's Core Library.  If not, see http://www.gnu.org/licenses/.
	</License>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2009-10-14 16:43:29Z</CreationDate>
</File>
*/
#endregion

using System;

using Microsoft.Practices.ObjectBuilder2;
using Microsoft.Practices.ServiceLocation;
using Microsoft.Practices.Unity;

namespace DanielVaughan.ServiceLocation.Unity
{
	/// <summary>
	/// Default implementation of <see cref="IServiceRegistrar"/>
	/// </summary>
	public sealed class UnityServiceRegistrar : UnityContainerExtension, IServiceRegistrar
	{
		public void RegisterInstance<TService>(TService service)
		{
			var unityContainer = ServiceLocator.Current.GetInstance<IUnityContainer>();
			unityContainer.RegisterInstance<TService>(service);
		}

		public void RegisterInstance(Type serviceType, object service)
		{
			var unityContainer = ServiceLocator.Current.GetInstance<IUnityContainer>();
			unityContainer.RegisterInstance(serviceType, service);
		}

		public void RegisterType<TFrom, TTo>() where TTo : TFrom
		{
			var unityContainer = ServiceLocator.Current.GetInstance<IUnityContainer>();
			unityContainer.RegisterType<TFrom, TTo>();
		}

		public bool IsTypeRegistered(Type type)
		{
			var unityContainer = ServiceLocator.Current.GetInstance<IUnityContainer>();
			unityContainer.AddExtension(this);
			var policy = Context.Policies.Get<IBuildKeyMappingPolicy>(new NamedTypeBuildKey(type));
			return policy != null;
		}

		public void RegisterSingleton<TFrom, TTo>() where TTo : TFrom
		{
			var unityContainer = ServiceLocator.Current.GetInstance<IUnityContainer>();
			unityContainer.RegisterType<TFrom, TTo>(new ContainerControlledLifetimeManager());
		}

		public void RegisterSingleton(Type fromType, Type toType)
		{
			var unityContainer = ServiceLocator.Current.GetInstance<IUnityContainer>();
			unityContainer.RegisterType(fromType, toType, new ContainerControlledLifetimeManager());
		}

		protected override void Initialize()
		{
			/* Intentionally left blank. */
		}
	}
}