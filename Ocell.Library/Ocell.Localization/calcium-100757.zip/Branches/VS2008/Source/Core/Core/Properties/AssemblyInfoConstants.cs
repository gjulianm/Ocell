
namespace DanielVaughan
{
	public static class AssemblyInfoConstants
	{
		public const string AssemblyFileVersion = "2.0.3892.5";
	}
}