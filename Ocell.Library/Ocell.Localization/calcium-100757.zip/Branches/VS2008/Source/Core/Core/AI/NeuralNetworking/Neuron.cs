#region File and License Information
/*
<File>
	<Copyright>Copyright � 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="prj:///Documentation/License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2008-12-27 18:12:16Z</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/
#endregion

using System;
using System.Collections.Generic;

namespace DanielVaughan.AI.NeuralNetworking
{
	[Serializable]
	class Neuron
	{
		double error;
		readonly object neuronLock = new object();

		public Neuron(double bias)
		{
			Inputs = new Dictionary<Neuron, NeuralBias>();
			Bias = new NeuralBias(bias);
		}

		public Neuron() : this(0)
		{
		}

		public double Output { get; set; }
		public Dictionary<Neuron, NeuralBias> Inputs { get; set; }
		public double LastError { get; set; }
		public NeuralBias Bias { get; set; }

		public double Error
		{
			get
			{
				return error;
			}
			set
			{
				LastError = error;
				error = value;
			}
		}

		public void Pulse(NeuralLayer layer)
		{
			lock (neuronLock)
			{
				Output = 0;

				foreach (var pair in Inputs)
				{
					Output += pair.Key.Output * pair.Value.Weight;
				}

				Output += Bias.Weight;
				Output = ApplySigmoid(Output);
			}
		}
        
		public void ApplyLearning(NeuralLayer layer, ref double learningRate)
		{
			foreach (var bias in Inputs.Values)
			{
				bias.ApplyWeightChange(ref learningRate);
			}

			Bias.ApplyWeightChange(ref learningRate);
		}

		public void InitializeLearning(NeuralLayer layer)
		{
			foreach (var bias in Inputs.Values)
			{
				bias.ResetWeightDelta();
			}

			Bias.ResetWeightDelta();
		}

		public static double ApplySigmoid(double value)
		{
			return 1 / (1 + Math.Exp(-value));
		}
        
	}
}