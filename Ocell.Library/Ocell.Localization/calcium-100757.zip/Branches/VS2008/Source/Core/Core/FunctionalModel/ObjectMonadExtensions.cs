﻿#region File and License Information
/*
<File>
	<Copyright>Copyright © 2009, Daniel Vaughan. All rights reserved.</Copyright>
	<License>
	This file is part of Daniel Vaughan's base library.

    Daniel Vaughan's base library is free software: you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Daniel Vaughan's base library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public License
    along with Daniel Vaughan's base library.  If not, see http://www.gnu.org/licenses/.
	</License>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2010-09-13 16:59:50Z</CreationDate>
</File>
*/
#endregion
/* Original source from http://www.codeproject.com/KB/cs/maybemonads.aspx */
using System;

namespace DanielVaughan
{
	public static class ObjectMonadExtensions
	{
		public static TResult With<TInput, TResult>(
			this TInput input, Func<TInput, TResult> evaluator) 
			where TResult : class where TInput : class
		{
			if (input == null)
			{
				return null;
			}
			return evaluator(input);
		}

		public static TResult With<TInput, TResult>(
			this TInput input, Func<TInput, TResult> evaluator, TResult resultIfInputNull) 
			where TInput : class
		{
			if (input == null)
			{
				return resultIfInputNull;
			}
			return evaluator(input);
		}

		public static TInput If<TInput>(this TInput input, Func<TInput, bool> evaluator) 
			where TInput : class
		{
			if (input == null)
			{
				return null;
			}
			return evaluator(input) ? input : null;
		}

		public static TInput Unless<TInput>(this TInput input, Func<TInput, bool> evaluator) 
			where TInput : class
		{
			if (input == null)
			{
				return null;
			}
			return evaluator(input) ? null : input;
		}

		public static TInput Do<TInput>(this TInput input, Action<TInput> action) 
			where TInput : class
		{
			if (input == null)
			{
				return null;
			}
			action(input);
			return input;
		}
	}
}
