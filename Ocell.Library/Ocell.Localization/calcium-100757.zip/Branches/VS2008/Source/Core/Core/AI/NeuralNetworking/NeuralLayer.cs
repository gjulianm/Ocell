#region File and License Information
/*
<File>
	<Copyright>Copyright � 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="prj:///Documentation/License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2008-12-27 18:11:04Z</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/
#endregion

using System;
using System.Collections;
using System.Collections.Generic;

namespace DanielVaughan.AI.NeuralNetworking
{
	[Serializable]
	class NeuralLayer : IList<Neuron>
	{
		readonly List<Neuron> neurons = new List<Neuron>();

		public int IndexOf(Neuron item)
		{
			return neurons.IndexOf(item);
		}

		public void Insert(int index, Neuron item)
		{
			neurons.Insert(index, item);
		}

		public void RemoveAt(int index)
		{
			neurons.RemoveAt(index);
		}

		public Neuron this[int index]
		{
			get
			{
				return neurons[index];
			}
			set
			{
				neurons[index] = value;
			}
		}

		public void Add(Neuron item)
		{
			neurons.Add(item);
		}

		public void Clear()
		{
			neurons.Clear();
		}

		public bool Contains(Neuron item)
		{
			return neurons.Contains(item);
		}

		public void CopyTo(Neuron[] array, int arrayIndex)
		{
			neurons.CopyTo(array, arrayIndex);
		}

		public int Count
		{
			get
			{
				return neurons.Count;
			}
		}

		public bool IsReadOnly
		{
			get
			{
				return false;
			}
		}

		public bool Remove(Neuron item)
		{
			return neurons.Remove(item);
		}

		public IEnumerator<Neuron> GetEnumerator()
		{
			return neurons.GetEnumerator();
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			return GetEnumerator();
		}

		public void Pulse()
		{
			foreach (var neuron in neurons)
			{
				neuron.Pulse(this);
			}
		}

		public void ApplyLearning(NeuralNetwork network)
		{
			double learningRate = network.LearningRate;

			foreach (var neuron in neurons)
			{
				neuron.ApplyLearning(this, ref learningRate);
			}
		}

		public void InitializeLearning(NeuralNetwork network)
		{
			foreach (var neuron in neurons)
			{
				neuron.InitializeLearning(this);
			}
		}
        
	}
}