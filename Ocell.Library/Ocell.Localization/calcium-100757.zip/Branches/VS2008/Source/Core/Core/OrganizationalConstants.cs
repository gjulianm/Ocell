﻿#region File and License Information
/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="prj:///Documentation/License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2009-03-22 14:02:51Z</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/
#endregion

namespace DanielVaughan
{
	public static class OrganizationalConstants
	{
		public const string ServiceContractNamespace = "http://schemas.danielvaughan.orpius.com/2009/02/";
		public const string DataContractNamespace = "http://schemas.danielvaughan.orpius.com/2009/02/";
	}
}
