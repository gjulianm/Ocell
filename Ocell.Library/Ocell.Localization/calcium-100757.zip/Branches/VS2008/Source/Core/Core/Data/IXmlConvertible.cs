﻿#region File and License Information
/*
<File>
	<Copyright>Copyright © 2009, Daniel Vaughan. All rights reserved.</Copyright>
	<License>
	This file is part of DanielVaughan's base library

    DanielVaughan's base library is free software: you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    DanielVaughan's base library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public License
    along with DanielVaughan's base library.  If not, see http://www.gnu.org/licenses/.
	</License>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2010-01-30 19:39:31Z</CreationDate>
</File>
*/
#endregion

using System.Xml.Linq;

namespace DanielVaughan.Data
{
	/// <summary>
	/// Provides for conversion and population to and from an XElement.
	/// Allows an object instance to be converted to XML and perhaps serialized.
	/// </summary>
	public interface IXmlConvertible
	{
		/// <summary>
		/// Populates the instance from the values in the specified element.
		/// This is the reverse process of <see cref="ToXElement"/>.
		/// </summary>
		/// <param name="element">The element.</param>
		void FromXElement(XElement element);

		/// <summary>
		/// Convert to an XElement. This is the reverse process of <see cref="FromXElement"/>.
		/// </summary>
		/// <returns>An element representing the current object instance.</returns>
		XElement ToXElement();
	}
}
