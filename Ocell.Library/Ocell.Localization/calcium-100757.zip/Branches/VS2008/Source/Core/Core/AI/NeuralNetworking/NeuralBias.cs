#region File and License Information
/*
<File>
	<Copyright>Copyright � 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="prj:///Documentation/License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2008-12-27 18:10:49Z</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/
#endregion

using System;

namespace DanielVaughan.AI.NeuralNetworking
{
	[Serializable]
	class NeuralBias : ICloneable
	{
		public double Weight { get; set; }
		public double WeightDelta { get; set; }

		public NeuralBias(double weight)
		{
			Weight = weight;
		}

		public void ApplyWeightChange(ref double learningRate)
		{
			Weight += WeightDelta * learningRate;
		}

		public void ResetWeightDelta()
		{
			WeightDelta = 0;
		}

		public object Clone()
		{
			return new NeuralBias(Weight) {WeightDelta = WeightDelta};
		}
	}
}