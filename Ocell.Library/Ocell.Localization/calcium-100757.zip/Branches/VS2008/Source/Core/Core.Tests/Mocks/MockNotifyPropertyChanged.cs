﻿#region File and License Information
/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="prj:///Documentation/License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2009-08-01 14:28:25Z</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/
#endregion

using System.ComponentModel;

using DanielVaughan.ComponentModel;

namespace DanielVaughan.Tests.Mocks
{
	class MockNotifyPropertyChanged : INotifyPropertyChanged, INotifyPropertyChanging
	{
		readonly PropertyChangeNotifier notifier;

		#region INotifyPropertyChanged Implementation
		public event PropertyChangedEventHandler PropertyChanged
		{
			add
			{
				notifier.PropertyChanged += value;
			}
			remove
			{
				notifier.PropertyChanged -= value;
			}
		}
		#endregion

		#region INotifyPropertyChanging Implementation
		public event PropertyChangingEventHandler PropertyChanging
		{
			add
			{
				notifier.PropertyChanging += value;
			}
			remove
			{
				notifier.PropertyChanging -= value;
			}
		}
		#endregion

		public MockNotifyPropertyChanged()
		{
			notifier = new PropertyChangeNotifier(this);
		}

		public MockNotifyPropertyChanged(bool useExtendedEventArgs)
		{
			notifier = new PropertyChangeNotifier(this, useExtendedEventArgs);
		}

		/// <summary>
		/// Gets the property changed notifier for testing purposes.
		/// </summary>
		/// <value>The property changed notifier.</value>
		internal PropertyChangeNotifier PropertyChangeNotifier
		{
			get
			{
				return notifier;
			}
		}

		string testProperty1;

		public string TestPropertyString
		{
			get
			{
				return testProperty1;
			}
			set
			{
				var oldValue = testProperty1;
				testProperty1 = value;
				notifier.NotifyChanged("TestPropertyString", oldValue, value);
			}
		}

		string testProperty2;

		public string TestPropertyLambda
		{
			get
			{
				return testProperty2;
			}
			set
			{
				var oldValue = testProperty2;
				testProperty2 = value;		
				/* Slow. */
				notifier.NotifyChanged(
					(MockNotifyPropertyChanged mock) => mock.TestPropertyLambda, oldValue, value);
			}
		}

		int int1;

		public int TestPropertyAssigned
		{
			get
			{
				return int1;
			}
			set
			{
				notifier.Assign(
					"TestPropertyAssigned", ref int1, value);
			}
		}

		string assigned2;

		public string TestPropertyAssigned2
		{
			get
			{
				return assigned2;
			}
			set
			{
				notifier.Assign(
					"TestPropertyAssigned2", ref assigned2, value);
			}
		}

		string string1;

		public string TestPropertyAssignedLambda
		{
			get
			{
				return string1;
			}
			set
			{
				notifier.Assign(
					(MockNotifyPropertyChanged mock) => mock.TestPropertyAssignedLambda, 
					ref string1, value);
			}
		}
		
	}
}
