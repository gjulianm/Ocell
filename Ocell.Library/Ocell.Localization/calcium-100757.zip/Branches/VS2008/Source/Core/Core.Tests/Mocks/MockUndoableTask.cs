﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using DanielVaughan.TaskModel;

namespace DanielVaughan.Tests.Mocks
{
	class MockUndoableTask : UndoableTaskBase<string>
	{
		public MockUndoableTask()
		{
			Execute += OnExecute;
			Undo += OnUndo;
		}

		public int ExecutionCount { get; private set; }
		public string LastArgument { get; private set; }

		void OnUndo(object sender, TaskEventArgs<string> e)
		{
			ExecutionCount--;
			e.TaskResult = TaskResult.Completed;
		}
       
		void OnExecute(object sender, TaskEventArgs<string> e)
		{
			ExecutionCount++;
			LastArgument = e.Argument;
		}

		public override string DescriptionForUser
		{
			get
			{
				return "Mock Undoable task";
			}
		}

		public bool RepeatableTest
		{
			get
			{
				return Repeatable;
			}
			set
			{
				Repeatable = value;
			}
		}
        
	}
}
