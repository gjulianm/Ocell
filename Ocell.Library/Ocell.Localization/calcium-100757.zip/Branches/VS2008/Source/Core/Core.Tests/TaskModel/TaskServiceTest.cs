﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;

using DanielVaughan.TaskModel;
using DanielVaughan.Tests.Mocks;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace DanielVaughan.Tests.TaskModel
{
    /// <summary>
    ///This is a test class for PropertyChangedNotifierTest and is intended
    ///to contain all PropertyChangedNotifierTest Unit Tests
    ///</summary>
	[TestClass]
	public class TaskServiceTest
	{
		[TestMethod]
		public void AGlobalTaskShouldBePerformed()
		{
			var mockTask = new MockTask();
			string expectedValue1 = "1";
			var target = new TaskService();

			target.PerformTask(mockTask, expectedValue1, null);

			Assert.AreEqual(mockTask.LastArgument, expectedValue1);
			Assert.AreEqual(mockTask.ExecutionCount, 1);
		}

		[TestMethod]
		public void TaskServiceShouldUndoGlobalTasks()
		{
			TaskServiceShouldUndoTasks(null);
		}

		[TestMethod]
		public void TaskServiceShouldUndoNonGlobalTasks()
		{
			TaskServiceShouldUndoTasks(new object());
		}

		void TaskServiceShouldUndoTasks(object key)
		{
			var mockTask1 = new MockUndoableTask { RepeatableTest = true };
			string expectedValue1 = "1";
			string expectedValue2 = "2";
			var target = new TaskService();

			Assert.IsFalse(target.CanUndo(key));
			Assert.IsFalse(target.CanRedo(key));
			Assert.IsFalse(target.CanRepeat(key));

			target.PerformTask(mockTask1, expectedValue1, key);

			Assert.AreEqual(mockTask1.LastArgument, expectedValue1);
			Assert.AreEqual(mockTask1.ExecutionCount, 1);

			Assert.IsTrue(target.CanUndo(key));
			Assert.IsFalse(target.CanRedo(key));
			Assert.IsTrue(target.CanRepeat(key));

			target.Undo(key);

			Assert.AreEqual(mockTask1.LastArgument, expectedValue1);
			Assert.AreEqual(mockTask1.ExecutionCount, 0);

			Assert.IsFalse(target.CanUndo(key));
			Assert.IsTrue(target.CanRedo(key));
			Assert.IsFalse(target.CanRepeat(key));

			target.Redo(key);

			Assert.AreEqual(mockTask1.LastArgument, expectedValue1);
			Assert.AreEqual(mockTask1.ExecutionCount, 1);

			Assert.IsTrue(target.CanUndo(key));
			Assert.IsFalse(target.CanRedo(key));
			Assert.IsTrue(target.CanRepeat(key));

			target.Repeat(key);

			Assert.AreEqual(mockTask1.LastArgument, expectedValue1);
			Assert.AreEqual(mockTask1.ExecutionCount, 2);

			Assert.IsTrue(target.CanUndo(key));
			Assert.IsFalse(target.CanRedo(key));
			Assert.IsTrue(target.CanRepeat(key));

			target.Repeat(key);

			Assert.AreEqual(mockTask1.LastArgument, expectedValue1);
			Assert.AreEqual(mockTask1.ExecutionCount, 3);

			Assert.IsTrue(target.CanUndo(key));
			Assert.IsFalse(target.CanRedo(key));
			Assert.IsTrue(target.CanRepeat(key));

			target.Undo(key);

			Assert.AreEqual(mockTask1.LastArgument, expectedValue1);
			Assert.AreEqual(mockTask1.ExecutionCount, 2);

			Assert.IsTrue(target.CanUndo(key));
			Assert.IsTrue(target.CanRedo(key));
			Assert.IsTrue(target.CanRepeat(key));

			target.Undo(key);

			Assert.AreEqual(mockTask1.LastArgument, expectedValue1);
			Assert.AreEqual(mockTask1.ExecutionCount, 1);

			Assert.IsTrue(target.CanUndo(key));
			Assert.IsTrue(target.CanRedo(key));
			Assert.IsTrue(target.CanRepeat(key));

			target.Undo(key);

			Assert.AreEqual(mockTask1.LastArgument, expectedValue1);
			Assert.AreEqual(mockTask1.ExecutionCount, 0);

			Assert.IsFalse(target.CanUndo(key));
			Assert.IsTrue(target.CanRedo(key));
			Assert.IsFalse(target.CanRepeat(key));

			var mockTask2 = new MockUndoableTask { RepeatableTest = true };
			target.PerformTask(mockTask1, expectedValue1, key);
			target.PerformTask(mockTask2, expectedValue2, key);

			Assert.AreEqual(mockTask1.LastArgument, expectedValue1);
			Assert.AreEqual(mockTask1.ExecutionCount, 1);
			Assert.AreEqual(mockTask2.LastArgument, expectedValue2);
			Assert.AreEqual(mockTask2.ExecutionCount, 1);

			Assert.IsTrue(target.CanUndo(key));
			Assert.IsFalse(target.CanRedo(key));
			Assert.IsTrue(target.CanRepeat(key));

			target.Undo(key);

			Assert.AreEqual(mockTask1.ExecutionCount, 1);
			Assert.AreEqual(mockTask2.ExecutionCount, 0);

			Assert.IsTrue(target.CanUndo(key));
			Assert.IsTrue(target.CanRedo(key));
			Assert.IsTrue(target.CanRepeat(key));

			var list = target.GetRepeatableTasks(key);
			Assert.IsNotNull(list);
			Assert.IsTrue(list.ToList().Count == 1);
		}

		[TestMethod]
		public void GetRepeatableTasksShouldReturnRepeatableTasks()
		{
			GetRepeatableTasksShouldReturnRepeatableTasks(null);
		}

		[TestMethod]
		public void GetRepeatableGlobalTasksShouldReturnRepeatableTasks()
		{
			GetRepeatableTasksShouldReturnRepeatableTasks(new object());
		}

		void GetRepeatableTasksShouldReturnRepeatableTasks(object key)
		{
			var task1 = new MockTask { RepeatableTest = true };
			var target = new TaskService();
			var list = target.GetRepeatableTasks(key);
			Assert.IsTrue(list.Count() < 1);
			target.PerformTask(task1, string.Empty, key);
			list = target.GetRepeatableTasks(key);
			Assert.IsTrue(list.Count() > 0);
		}

		[TestMethod]
		public void NonRepeatableGlobalTaskShouldNotBeRepeatable()
		{
			var task1 = new MockTask();
			var target = new TaskService();
			string arg1 = "1";
			Assert.IsFalse(target.CanRepeat(null));
			target.PerformTask(task1, arg1, null);
			Assert.IsFalse(target.CanRepeat(null));
		}

		[TestMethod]
		public void RepeatableGlobalTaskShouldBeRepeatable()
		{
			var task1 = new MockTask {RepeatableTest = true};
			var target = new TaskService();
			string arg1 = "1";
			Assert.IsFalse(target.CanRepeat(null));
			target.PerformTask(task1, arg1, null);
			Assert.IsTrue(target.CanRepeat(null));
			target.Repeat(null);
			Assert.IsTrue(task1.ExecutionCount == 2);
		}

		[TestMethod]
		public void NonRepeatableTaskShouldNotBeRepeatable()
		{
			var task1 = new MockTask();
			var target = new TaskService();
			object key = new object();
			Assert.IsFalse(target.CanRepeat(key));
			target.PerformTask(task1, "1", key);
			Assert.IsFalse(target.CanRepeat(key));
		}

		[TestMethod]
		public void RepeatableTaskShouldBeRepeatable()
		{
			var task1 = new MockTask { RepeatableTest = true };
			var target = new TaskService();
			object key = new object();
			Assert.IsFalse(target.CanRepeat(key));
			target.PerformTask(task1, "1", key);
			Assert.IsTrue(target.CanRepeat(key));
			target.Repeat(key);
			Assert.IsTrue(task1.ExecutionCount == 2);
		}

		[TestMethod]
		public void UndoableTaskShouldBeRedoable()
		{
			UndoableTaskShouldBeRedoable(null);
		}

		[TestMethod]
		public void UndoableGlobalTaskShouldBeRedoable()
		{
			UndoableTaskShouldBeRedoable(new object());
		}

		void UndoableTaskShouldBeRedoable(object key)
		{
			var task1 = new MockUndoableTask();
			var target = new TaskService();
			Assert.IsFalse(target.CanRedo(key));
			target.PerformTask(task1, "1", key);
			target.Undo(key);
			Assert.IsTrue(target.CanRedo(key));
		}

		[TestMethod]
		public void NonUndoableTasksShouldNotBeUndoable()
		{
			NonUndoableTasksShouldNotBeUndoable(null);
		}

		[TestMethod]
		public void NonUndoableGlobalTasksShouldNotBeUndoable()
		{
			NonUndoableTasksShouldNotBeUndoable(new object());
		}

		[TestMethod]
		public void PerformingGlobalTaskShouldClearUndoableList()
		{
			PerformingTaskShouldClearUndoableList(null);
		}

		[TestMethod]
		public void PerformingTaskShouldClearUndoableList()
		{
			PerformingTaskShouldClearUndoableList(new object());
		}
		
		void PerformingTaskShouldClearUndoableList(object key)
		{
			/* First set up some undoable tasks. */
			var task1 = new MockUndoableTask();
			var target = new TaskService();
			target.PerformTask(task1, "1", key);			
			Assert.IsTrue(target.CanUndo(key));

			/* Perform a non-undoable task. This must clear the undoable list. */
			var task2 = new MockTask { RepeatableTest = true };
			target.PerformTask(task2, "1", key);
			Assert.IsFalse(target.CanUndo(key));
		}

		void NonUndoableTasksShouldNotBeUndoable(object key)
		{
			var task1 = new MockTask();
			var target = new TaskService();
			Assert.IsFalse(target.CanUndo(key));
			target.PerformTask(task1, "1", key);
			Assert.IsFalse(target.CanUndo(key));
		}

		[TestMethod]
		public void CompositeTasksShouldbePerformedInParallel()
		{
			CompositeTasksShouldBePerformedInParallel(new object());
		}

		[TestMethod]
		public void GlobalCompositeTasksShouldBePerformedInParallel()
		{
			CompositeTasksShouldBePerformedInParallel(null);
		}

		void CompositeTasksShouldBePerformedInParallel(object contextKey)
		{
			var tasks = new Dictionary<TaskBase<string>, string>();
			for (int i = 0; i < 100; i++)
			{
				tasks.Add(new MockTask(), i.ToString());
			}
			var compositeTask = new CompositeTask<string>(tasks, "1") { Parallel = true };
			var target = new TaskService();
			target.PerformTask(compositeTask, null, contextKey);
			foreach (KeyValuePair<TaskBase<string>, string> keyValuePair in tasks)
			{
				var mockTask = (MockTask)keyValuePair.Key;
				Assert.AreEqual(1, mockTask.ExecutionCount);
			}
		}

		[TestMethod]
		public void CompositeUndoableTasksShouldbePerformedInParallel()
		{
			CompositeUndoableTasksShouldBePerformedInParallel(new object());
		}

		[TestMethod]
		public void GlobalCompositeUndoableTasksShouldBePerformedInParallel()
		{
			CompositeUndoableTasksShouldBePerformedInParallel(null);
		}

		void CompositeUndoableTasksShouldBePerformedInParallel(object contextKey)
		{
			var tasks = new Dictionary<UndoableTaskBase<string>, string>();
			for (int i = 0; i < 100; i++)
			{
				tasks.Add(new MockUndoableTask(), i.ToString());
			}
			var compositeTask = new CompositeUndoableTask<string>(tasks, "1") { Parallel = true };
			var target = new TaskService();
			target.PerformTask(compositeTask, null, contextKey);
			foreach (KeyValuePair<UndoableTaskBase<string>, string> keyValuePair in tasks)
			{
				var mockTask = (MockUndoableTask)keyValuePair.Key;
				Assert.AreEqual(1, mockTask.ExecutionCount);
			}

			/* Test undo. */
			target.Undo(contextKey);

			foreach (KeyValuePair<UndoableTaskBase<string>, string> keyValuePair in tasks)
			{
				var mockTask = (MockUndoableTask)keyValuePair.Key;
				Assert.AreEqual(0, mockTask.ExecutionCount);
			}
		}
	}
}
