﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using DanielVaughan.TaskModel;

namespace DanielVaughan.Tests.Mocks
{
	class MockTask : TaskBase<string>
	{
		public MockTask()
		{
			Execute += OnExecute;	
		}

		void OnExecute(object sender, TaskEventArgs<string> e)
		{
			ExecutionCount++;
			LastArgument = e.Argument;
		}

		public override string DescriptionForUser
		{
			get
			{
				return "Mock task";
			}
		}

		public int ExecutionCount { get; private set; }

		public string LastArgument { get; private set; }

		public bool RepeatableTest
		{
			get
			{
				return Repeatable;
			}
			set
			{
				Repeatable = value;
			}
		}
	}
}
