﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using DanielVaughan.Windows;

namespace DanielVaughan.Calcium.Gui.Controls
{
	public partial class StandardToolBarTray : UserControl
	{
		public StandardToolBarTray()
		{

			InitializeComponent();

			blah.Text = System.ComponentModel.DesignerProperties.GetIsInDesignMode(this) + "";//DesignTimeEnvironment.DesignTime + "";

			Loaded += new RoutedEventHandler(StandardToolBarTray_Loaded);
		}

		void StandardToolBarTray_Loaded(object sender, RoutedEventArgs e)
		{
			//if (System.ComponentModel.DesignerProperties.GetIsInDesignMode(this))//DesignTimeEnvironment.DesignTime)
			//{
			//    throw new Exception("test");
			//}
			throw new Exception("test");
		}
	}
}
