#region File and License Information
/*
<File>
	<Copyright>Copyright � 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License>
		Redistribution and use in source and binary forms, with or without
		modification, are permitted provided that the following conditions are met:
			* Redistributions of source code must retain the above copyright
			  notice, this list of conditions and the following disclaimer.
			* Redistributions in binary form must reproduce the above copyright
			  notice, this list of conditions and the following disclaimer in the
			  documentation and/or other materials provided with the distribution.
			* Neither the name of the <organization> nor the
			  names of its contributors may be used to endorse or promote products
			  derived from this software without specific prior written permission.

		THIS SOFTWARE IS PROVIDED BY <copyright holder> ''AS IS'' AND ANY
		EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
		WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
		DISCLAIMED. IN NO EVENT SHALL <copyright holder> BE LIABLE FOR ANY
		DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
		(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
		LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
		ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
		(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
		SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
	</License>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2009-05-17 19:14:47Z</CreationDate>
</File>
*/
#endregion

using System.Collections.Generic;

namespace DanielVaughan.Calcium
{
	public static class ModuleNames
	{
		public const string WebBrowser = "Web Browser";
		public const string OutputDisplay = "Output Display";
		public const string ModuleManager = "Module Manager";
		public const string TextEditor = "Text Editor";
		public const string UserAffinity = "User Affinity";
		public const string Communication = "Communication";
		/// <summary>
		/// Future feature.
		/// </summary>
		public const string History = "History";

		static List<string> defaultModuleNameList;

		static ModuleNames()
		{
			defaultModuleNameList = new List<string> {OutputDisplay, ModuleManager, Communication, History, WebBrowser};
		}

		/// <summary>
		/// Gets the default module names. These are modules that are loaded by default.
		/// </summary>
		/// <value>The default module names.</value>
		public static IEnumerable<string> DefaultModuleNames
		{
			get
			{
				return defaultModuleNameList;
			}
		}
	}
}
