﻿#region File and License Information
/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License>
		Redistribution and use in source and binary forms, with or without
		modification, are permitted provided that the following conditions are met:
			* Redistributions of source code must retain the above copyright
			  notice, this list of conditions and the following disclaimer.
			* Redistributions in binary form must reproduce the above copyright
			  notice, this list of conditions and the following disclaimer in the
			  documentation and/or other materials provided with the distribution.
			* Neither the name of the <organization> nor the
			  names of its contributors may be used to endorse or promote products
			  derived from this software without specific prior written permission.

		THIS SOFTWARE IS PROVIDED BY <copyright holder> ''AS IS'' AND ANY
		EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
		WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
		DISCLAIMED. IN NO EVENT SHALL <copyright holder> BE LIABLE FOR ANY
		DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
		(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
		LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
		ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
		(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
		SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
	</License>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2009-05-21 13:30:53Z</CreationDate>
</File>
*/
#endregion

using System;
using System.Linq;
using System.ServiceModel;
using System.Threading;

using DanielVaughan.Services;

namespace DanielVaughan.Calcium.ClientServices
{
	/// <summary>
	/// This class is the server-side implementation of the <see cref="IMessageService"/>.
	/// It sends all messaging requests to the <see cref="OperationContext"/> 
	/// derived <see cref="ICommunicationCallback"/> channel.
	/// This, in effect, causes the <seealso cref="IMessageService"/> on the client
	/// to be called.
	/// </summary>
	public class ServerSideMessageService : IMessageService
	{
		ICommunicationCallback CommunicationCallback { get; set; }

		/// <summary>
		/// Retrieves the callback from the <seealso cref="OperationContext"/>.
		/// </summary>
		/// <returns></returns>
		static ICommunicationCallback GetCommunicationCallback()
		{
			var callback = CommunicationService.GetCallback();
			return callback;
		}

		public ServerSideMessageService()
		{
			CommunicationCallback = GetCommunicationCallback();
		}

		public void ShowMessage(string message, MessageImportance importanceThreshold)
		{
			ShowUsingCallback(callback => callback.ShowMessage(message, importanceThreshold));
		}

		delegate void ShowMessageUsingCallback(ICommunicationCallback callback);

		void ShowUsingCallback(ShowMessageUsingCallback showMessageUsingCallback)
		{
			var callback = CommunicationCallback;
			if (callback != null)
			{
				ThreadPool.QueueUserWorkItem(state =>
				{
					try
					{
						showMessageUsingCallback(callback);
					}
					catch (Exception ex)
					{
						Log.Warn("Unable to show using callback", ex);
					}

				}, callback);
				return;
			}
		}

		public void ShowMessage(string message, string caption, MessageImportance importanceThreshold)
		{
			ShowUsingCallback(callback => callback.ShowMessage(message, caption, importanceThreshold));
		}

		public void ShowWarning(string message)
		{
			ShowUsingCallback(callback => callback.ShowWarning(message));
		}

		public void ShowWarning(string message, string caption)
		{
			ShowUsingCallback(callback => callback.ShowWarning(message, caption));
		}

		public void ShowError(string message)
		{
			ShowUsingCallback(callback => callback.ShowError(message));
		}

		public void ShowError(string message, string caption)
		{
			ShowUsingCallback(callback => callback.ShowError(message, caption));
		}

		public bool AskYesNoQuestion(string question)
		{
			return CommunicationCallback.AskYesNoQuestion(question);
		}

		public bool AskYesNoQuestion(string question, string caption)
		{
			return CommunicationCallback.AskYesNoQuestion(question, caption);
		}

		public YesNoCancelQuestionResult AskYesNoCancelQuestion(string question)
		{
			return CommunicationCallback.AskYesNoCancelQuestion(question);
		}

		public YesNoCancelQuestionResult AskYesNoCancelQuestion(string question, string caption)
		{
			return CommunicationCallback.AskYesNoCancelQuestion(question, caption);
		}

		public bool AskOkCancelQuestion(string question)
		{
			return CommunicationCallback.AskOkCancelQuestion(question);
		}

		public bool AskOkCancelQuestion(string question, string caption)
		{
			return CommunicationCallback.AskOkCancelQuestion(question, caption);
		}
	}
}
