﻿using System;
using System.ComponentModel;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using DanielVaughan.ComponentModel;

namespace DanielVaughan.Calcium.Modules.Output
{
	public class TestViewModelBase
	{
		PropertyChangeNotifier notifier;

		protected PropertyChangeNotifier Notifier
		{
			get
			{
				return notifier;
			}
		}

		public TestViewModelBase()
		{
			notifier = new PropertyChangeNotifier(this);
		}

		public event PropertyChangedEventHandler PropertyChanged
		{
			add
			{
				notifier.PropertyChanged += value;
			}
			remove
			{
				notifier.PropertyChanged -= value;
			}
		}

		object tabHeader;

		public object TabHeader
		{
			get
			{
				return tabHeader;
			}
			set
			{
				notifier.Assign("TabHeader", ref tabHeader, value);
			}
		}
	}
}
