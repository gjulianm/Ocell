﻿#region File and License Information
/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License>
		Redistribution and use in source and binary forms, with or without
		modification, are permitted provided that the following conditions are met:
			* Redistributions of source code must retain the above copyright
			  notice, this list of conditions and the following disclaimer.
			* Redistributions in binary form must reproduce the above copyright
			  notice, this list of conditions and the following disclaimer in the
			  documentation and/or other materials provided with the distribution.
			* Neither the name of the <organization> nor the
			  names of its contributors may be used to endorse or promote products
			  derived from this software without specific prior written permission.

		THIS SOFTWARE IS PROVIDED BY <copyright holder> ''AS IS'' AND ANY
		EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
		WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
		DISCLAIMED. IN NO EVENT SHALL <copyright holder> BE LIABLE FOR ANY
		DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
		(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
		LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
		ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
		(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
		SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
	</License>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2009-05-21 13:30:03Z</CreationDate>
</File>
*/
#endregion

using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.Threading;

using DanielVaughan.ServiceModel;

namespace DanielVaughan.Calcium.ClientServices
{
	[AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
	public class CommunicationService : ICommunicationService
	{
		static readonly Dictionary<Guid, ICommunicationCallback> callbacks = new Dictionary<Guid, ICommunicationCallback>();
		static readonly ReaderWriterLockSlim callbacksLockSlim = new ReaderWriterLockSlim();
		static readonly Dictionary<string, ConnectedUser> connectedUsers = new Dictionary<string, ConnectedUser>();
		static readonly ReaderWriterLockSlim connectedUsersLock = new ReaderWriterLockSlim();

		static ICommunicationCallback GetCallbackFromOperationContext()
		{
			var callback = OperationContext.Current.GetCallbackChannel<ICommunicationCallback>();
			return callback;
		}

		internal static ICommunicationCallback GetCallback()
		{
			var instanceId = GetInstanceIdFromHeader();
			if (!instanceId.HasValue)
			{
				return GetCallbackFromOperationContext();
			}
			callbacksLockSlim.EnterReadLock();
			try
			{
				ICommunicationCallback callback;
				if (!callbacks.TryGetValue(instanceId.Value, out callback))
				{
					Log.Warn("callback with id " + instanceId + " not found in list.");
					return GetCallbackFromOperationContext();
				}
				return callback;
			}
			finally
			{
				callbacksLockSlim.ExitReadLock();
			}
		}

		static Guid? GetInstanceIdFromHeader()
		{
			var findHeaderResult = OperationContext.Current.IncomingMessageHeaders.FindHeader(InstanceIdHeader.HeaderName, InstanceIdHeader.HeaderNamespace);
			Guid? instanceId = null;

			if (findHeaderResult != -1)
			{
				String instanceIdValue = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>(InstanceIdHeader.HeaderName, OrganizationalConstants.ServiceContractNamespace);
				try
				{
					instanceId = new Guid(instanceIdValue);
				}
				catch (Exception ex)
				{
					Log.Error("Unable to parse header instance id.", ex);
				}
			}
			else
			{
				Log.Warn("InstanceId header not found.");
			}
			return instanceId;
		}

		public string InitiateConnection(string arbitraryIdentifier)
		{
			try
			{
				Log.Info("CommunicationService connection initiated with identifier: " + arbitraryIdentifier);

				AddCurrentCallback();

				var callback = GetCallbackFromOperationContext();
				var communicationObject = (ICommunicationObject)callback;
				communicationObject.Closing += OnClientClosing;
				communicationObject.Closed += OnClientClosed;

				ServiceSecurityContext securityContext = ServiceSecurityContext.Current;
				string userName = null;
                
				connectedUsersLock.EnterWriteLock();
				try
				{
					if (securityContext != null && securityContext.WindowsIdentity != null)
					{
						userName = securityContext.WindowsIdentity.Name;
					}

					if (!string.IsNullOrEmpty(userName))
					{
						var connectedUser = new ConnectedUser { UserName = userName, ConnectedAt = DateTime.Now};
						connectedUsers[userName] = connectedUser;
						communicationObject.Closing += delegate
						                               	{
															connectedUsersLock.EnterWriteLock();
						                               		try
						                               		{
						                               			connectedUsers.Remove(userName);
						                               		}
						                               		catch (Exception ex)
						                               		{
						                               			Log.Warn("Unable to remove connected user " + userName, ex);
						                               		}
															finally
						                               		{
						                               			connectedUsersLock.ExitWriteLock();
						                               		}
						                               	};
					}
				}
				catch (Exception ex)
				{
					Log.Warn("Unable to retrieve userName form current principal.", ex);
					/* Ignore. We should improve this logging event as it could produce a lot of log messages. */
				}
				finally
				{
					connectedUsersLock.ExitWriteLock();
				}
			}
			catch (Exception ex)
			{
				Log.Error("Unable to initiate connection.", ex);
				throw;
			}
			return "Connected";
		}

		static void OnClientClosing(object sender, EventArgs e)
		{
			Log.Debug("Client closing.");
		}

		static void OnClientClosed(object sender, EventArgs e)
		{
			try
			{
				var callback = (ICommunicationCallback)sender;
				RemoveCallback(callback);
			}
			catch (Exception ex)
			{
				Log.Error("Problem removing callback.", ex);
				/* Ignore. */
			}
		}

		#region Callbacks crud operations.

		static void AddCurrentCallback()
		{
			var instanceId = GetInstanceIdFromHeader() ?? Guid.NewGuid();

			var callback = OperationContext.Current.GetCallbackChannel<ICommunicationCallback>();
			callbacksLockSlim.EnterUpgradeableReadLock();

			try
			{
				if (!callbacks.ContainsValue(callback))
				{
					callbacksLockSlim.EnterWriteLock();
					try
					{
						if (!callbacks.ContainsValue(callback))
						{
							callbacks[instanceId] = callback;
						}
					}
					finally
					{
						callbacksLockSlim.ExitWriteLock();
					}
				}
			}
			finally
			{
				callbacksLockSlim.ExitUpgradeableReadLock();
			}
		}

		static bool RemoveCallback(ICommunicationCallback callback)
		{
			ArgumentValidator.AssertNotNull(callback, "callback");

			callbacksLockSlim.EnterUpgradeableReadLock();
			try
			{
				if (callbacks.Values.Contains(callback))
				{
					callbacksLockSlim.EnterWriteLock();
					try
					{
						Guid? instanceId = null;
						foreach (var pair in callbacks)
						{
							if (pair.Value == callback)
							{
								instanceId = pair.Key;
								break;
							}
						}
						if (instanceId.HasValue)
						{
							return callbacks.Remove(instanceId.Value);
						}
						else
						{
							Log.Warn("Collection is in invalid state. Key for value was not found. callback: " + callback);
						}
					}
					finally
					{
						callbacksLockSlim.ExitWriteLock();
					}
				}
			}
			finally
			{
				callbacksLockSlim.ExitUpgradeableReadLock();
			}
			return false;
		}

		#endregion

		public void NotifyAlive()
		{
			/* Intentionally left blank. */
		}

		public List<ConnectedUser> GetConnectedUsers()
		{
			try
			{
				return GetConnectedUsersAux();
			}
			catch (Exception ex)
			{
				Log.Error("Unable to retrieve connected users.", ex);
				throw;
			}
		}

		List<ConnectedUser> GetConnectedUsersAux()
		{
			List<ConnectedUser> usersTemp;
			connectedUsersLock.EnterReadLock();
			try
			{
				usersTemp = new List<ConnectedUser>(connectedUsers.Values);
			}
			finally
			{
				connectedUsersLock.ExitReadLock();
			}
			return usersTemp;
		}

		public int ConnectedClientCount
		{
			get
			{
				callbacksLockSlim.EnterReadLock();
				try
				{
					return callbacks.Count;
				}
				finally
				{
					callbacksLockSlim.ExitReadLock();
				}
			}
		}

		public IEnumerable<ICommunicationCallback> CommunicationCallbacks
		{
			get
			{
				callbacksLockSlim.EnterReadLock();
				try
				{
					return callbacks.Values.ToList();
				}
				finally
				{
					callbacksLockSlim.ExitReadLock();
				}
			}
		}

	}
}
