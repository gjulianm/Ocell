﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Controls;

namespace DanielVaughan.Calcium.Gui.Controls
{
	public class StandardMenu : UserControl
	{
		public override void OnApplyTemplate()
		{
			base.OnApplyTemplate();
		}
	}
}
