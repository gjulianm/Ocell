using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using DanielVaughan;
using DanielVaughan.Calcium;
using DanielVaughan.Calcium.Services;

using Microsoft.Practices.Composite.Modularity;

namespace DesktopClient.ModuleProjectTemplate
{
	[Module(ModuleName = "Template")]
	public class TemplateModule : ModuleBase
	{
		/* The location where the view will be placed. */
		const string defaultRegion = RegionNames.Tools;
		/* The default view for this module. */
		TemplateView view;

		public TemplateModule()
		{
			Initialized += OnInitialized;
		}

		void OnInitialized(object sender, EventArgs e)
		{
			view = new TemplateView();
			/* The view is registered with the view service so that it appears in the 'view' menu. */
			var viewService = ServiceLocatorSingleton.Instance.GetInstance<IViewService>();
			viewService.RegisterView("Template", obj => ShowView(defaultRegion, view, true), null, null, null);

			/* Populate the defaultRegion with the view. */
			ShowView(defaultRegion, view, false);
		}
	}
}
