﻿#region File and License Information
/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License>
		Redistribution and use in source and binary forms, with or without
		modification, are permitted provided that the following conditions are met:
			* Redistributions of source code must retain the above copyright
			  notice, this list of conditions and the following disclaimer.
			* Redistributions in binary form must reproduce the above copyright
			  notice, this list of conditions and the following disclaimer in the
			  documentation and/or other materials provided with the distribution.
			* Neither the name of the <organization> nor the
			  names of its contributors may be used to endorse or promote products
			  derived from this software without specific prior written permission.

		THIS SOFTWARE IS PROVIDED BY <copyright holder> ''AS IS'' AND ANY
		EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
		WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
		DISCLAIMED. IN NO EVENT SHALL <copyright holder> BE LIABLE FOR ANY
		DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
		(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
		LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
		ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
		(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
		SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
	</License>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2010-01-31 12:39:18Z</CreationDate>
</File>
*/
#endregion

using System;
using System.Windows;
using System.Windows.Markup;

using DanielVaughan.Gui;
using DanielVaughan.ServiceLocation.Unity;

namespace DanielVaughan.Calcium
{
	public class AppStarter
	{
		StartupOptions startupOptions;

		/// <summary>
		/// Gets or sets the startup options that are used for configuring 
		/// the e.g., the splash screen image.
		/// </summary>
		/// <value>The startup options.</value>
		public StartupOptions StartupOptions
		{
			get
			{
				if (startupOptions == null)
				{
					startupOptions = new StartupOptions();
				}
				return startupOptions;
			}
			set
			{
				startupOptions = value;
			}
		}

		public virtual void Start()
		{
			try
			{
				/* Load the resource dictionaries into the application. */
				//string assemblyFullName = Assembly.GetExecutingAssembly().FullName;

				IBootstrapper bootstrapper;
				if (!(ServiceLocatorSingleton.Instance.IsInitialized()
						&& ServiceLocatorSingleton.Instance.TryGetInstance<IBootstrapper>(out bootstrapper)))
				{
					bootstrapper = new Bootstrapper();
					bootstrapper.Run();
				}

				//ProcessCommandLineArguments();
				/* The ServiceLocatorSingleton must be initialized before this call. 
				 * If not performed in user code, then the default Bootstrapper will initialize it. */
				var mainWindow = ServiceLocatorSingleton.Instance.GetInstance<IMainWindow>();
				
				var rootVisual = mainWindow as UIElement;
				if (rootVisual != null)
				{
					Application.Current.RootVisual = rootVisual;
				}
				else
				{
					// log a warning.
				}
			}
			catch (Exception ex)
			{
				HandleApplicationException(ex, false);
			}
		}

		static void HandleApplicationException(Exception exception, bool allowContinue)
		{
			throw exception;
//			try
//			{
//				//Log.Error("Error processed by HandleApplicationException", exception);
//
//				//				var action = new HandleApplicationExceptionAction();
//				//				TaskServiceSingleton.Instance.PerformTask(action, new HandleExceptionArgument { AllowIgnore = allowContinue, Exception = exception });
//			}
//			catch (Exception ex)
//			{
//				//Log.Error("Unable to perform action HandleApplicationExceptionAction", ex);
//				/* Suppress. */
//			}
		}
	}

	public class StartupOptions
	{

	}
}
