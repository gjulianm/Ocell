#region File and License Information
/*
<File>
	<Copyright>Copyright � 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License>
		Redistribution and use in source and binary forms, with or without
		modification, are permitted provided that the following conditions are met:
			* Redistributions of source code must retain the above copyright
			  notice, this list of conditions and the following disclaimer.
			* Redistributions in binary form must reproduce the above copyright
			  notice, this list of conditions and the following disclaimer in the
			  documentation and/or other materials provided with the distribution.
			* Neither the name of the <organization> nor the
			  names of its contributors may be used to endorse or promote products
			  derived from this software without specific prior written permission.

		THIS SOFTWARE IS PROVIDED BY <copyright holder> ''AS IS'' AND ANY
		EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
		WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
		DISCLAIMED. IN NO EVENT SHALL <copyright holder> BE LIABLE FOR ANY
		DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
		(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
		LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
		ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
		(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
		SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
	</License>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2009-05-17 19:16:09Z</CreationDate>
</File>
*/
#endregion

using System;
using System.ComponentModel;
using System.IO;
using System.Windows.Threading;

using DanielVaughan.Calcium.Content;
using DanielVaughan.Calcium.Gui;
using DanielVaughan.IO;
using DanielVaughan.Services;

namespace DanielVaughan.Calcium.TextEditor
{
	public class TextEditorViewModel : ViewModelBase, 
		IContentProvider<ISavableContent>, ISavableContent
	{
		#region TextContent Dependency Property
		
		string textContent;
		[Description("Text content to display.")]
		[Browsable(true)]
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]	
		public string TextContent
		{
			get
			{
				return textContent;
			}
			set
			{
				Notifier.Assign("TextContent", ref textContent, value);
				Dirty = true;
			}
		}

		#endregion
        
		public TextEditorViewModel()
		{
		}

		public void CreateNew(string name)
		{
			fileName = name;
			Title = CreateName(fileName);
		}

		public void CreateOpened(string name, string content)
		{
			CreateNew(name);
			TextContent = content;
			Dirty = false;
			NewFile = false;
		}

		#region Implementation of IContentProvider<ISavableContent>

		public ISavableContent Content
		{
			get
			{
				return this;
			}
		}

		#endregion

		#region Implementation of ISavableContent

		public bool CanSave
		{
			get
			{
				return true;
			}
		}

		#region Dirty Dependency Property

		bool dirty;
		public bool Dirty
		{
			get
			{
				return dirty;
			}
			set
			{
				Notifier.Assign("Dirty", ref dirty, value);
			}
		}

		#endregion

		bool newFile = true;

		public bool NewFile
		{
			get
			{
				return newFile;
			}
			internal set
			{
				Notifier.Assign("NewFile", ref newFile, value);
			}
		}

		public FileOperationResult Save(FileErrorAction fileErrorAction)
		{
			return SaveAux(fileErrorAction, false);
		}

		public FileOperationResult SaveAs(FileErrorAction fileErrorAction)
		{
			return SaveAux(fileErrorAction, true);
		}

		string fileName;

		FileOperationResult SaveAux(FileErrorAction fileErrorAction, bool performSaveAs)
		{
			FileOperationResult result;
			string temp = fileName;

			if (NewFile || performSaveAs)
			{
				result = SaveAux(fileErrorAction, true, ref temp);
			}
			else
			{
				result = SaveAux(fileErrorAction, false, ref temp);
			}

			if (result == FileOperationResult.Successful)
			{
				FileName = temp;
				NewFile = false;
				Title = CreateName(fileName);
				Dirty = false;
			}

			return result;
		}
        
		FileOperationResult SaveAux(FileErrorAction fileErrorAction, bool performSaveAs, 
			ref string tempFileName)
		{
			var fileService = ServiceLocatorSingleton.Instance.GetInstance<IFileService>();
			string nameTemp = tempFileName;
#if SILVERLIGHT
			FileOperationResult result = FileOperationResult.Failed;
#else
			FileOperationHandler handler = 
				name =>
                   	{
                   		string fileContent = null;
                   		var dispatcher = ServiceLocatorSingleton.Instance.GetInstance<Dispatcher>();
                   		dispatcher.InvokeIfRequired(
                   			delegate { fileContent = TextContent; });

                   		FileSystem.WriteFile(name, fileContent);

                   		nameTemp = name;
                   	};

			FileOperationResult result = performSaveAs
						? fileService.SaveAs(tempFileName, handler, fileErrorAction)
						: fileService.Save(tempFileName, handler, fileErrorAction);

			tempFileName = nameTemp;
#endif
			return result;
		}

		static string CreateName(string fileName)
		{
			var result = Path.GetFileName(fileName);
			return result;
		}

		public string FileName
		{
			get
			{
				return fileName;
			}
			set
			{
				Notifier.Assign("FileName", ref fileName, value);
			}
		}

		#endregion
	}
}
