﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Theming;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using Microsoft.Practices.Composite.Events;

namespace DanielVaughan.Calcium.Modules.Output
{
	public partial class OutputView : IOutputView
	{
		public OutputView()
		{
			InitializeComponent();
			
			try
			{
//				var blah = new OutputViewModel();
//				ViewModel = blah;//ServiceLocatorSingleton.Container.Resolve<OutputViewModel>(); 
//				DataContext = new object();
			}
			catch (Exception ex)
			{
				
				throw;
			}
			DataContext = ViewModel = new OutputViewModel();
			Loaded += OnLoaded;
//			LayoutUpdated += OnLayoutUpdated; 
		}

//		void OnLayoutUpdated(object sender, EventArgs e)
//		{
//			LayoutUpdated -= OnLayoutUpdated;
//			ImplicitStyleManager.SetApplyMode(this, ImplicitStylesApplyMode.None);
//			ImplicitStyleManager.Apply(this); // redundant call to workaround datagrid style issue)
//		} 

		void OnLoaded(object sender, RoutedEventArgs e)
		{
//			ViewModel = (OutputViewModel)DataContext;
//			var eventAggregator = ServiceLocatorSingleton.Container.Resolve<IEventAggregator>();
//			var blah = eventAggregator.GetEvent<OutputPostedEvent>();
//			blah.Publish(new OutputMessage() {Category = "sdflj", Message = "sdajklfsdjlk ljkjsl"});
		}
	}
}
