#region File and License Information
/*
<File>
	<Copyright>Copyright � 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License>
		Redistribution and use in source and binary forms, with or without
		modification, are permitted provided that the following conditions are met:
			* Redistributions of source code must retain the above copyright
			  notice, this list of conditions and the following disclaimer.
			* Redistributions in binary form must reproduce the above copyright
			  notice, this list of conditions and the following disclaimer in the
			  documentation and/or other materials provided with the distribution.
			* Neither the name of the <organization> nor the
			  names of its contributors may be used to endorse or promote products
			  derived from this software without specific prior written permission.

		THIS SOFTWARE IS PROVIDED BY <copyright holder> ''AS IS'' AND ANY
		EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
		WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
		DISCLAIMED. IN NO EVENT SHALL <copyright holder> BE LIABLE FOR ANY
		DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
		(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
		LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
		ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
		(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
		SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
	</License>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2009-07-12 15:23:52Z</CreationDate>
</File>
*/
#endregion

using System;
using System.Collections.Generic;

using Microsoft.Practices.Composite.Modularity;
using Microsoft.Practices.Composite.Regions;

using DanielVaughan.Calcium.Services;

namespace DanielVaughan.Calcium
{
	/// <summary>
	/// Base class for <see cref="IModule"/>s.
	/// </summary>
	public abstract class ModuleBase : IModule
	{
		void IModule.Initialize()
		{
			/* By using an event rather than a virtual or abstract method, 
			 * we allow the base class to vary independently, 
			 * as it prevents code that must be executed in this class's Initialize method 
			 * from being skipped by a failure to call base.Initialize 
			 * if the method is overridden. */
			if (Initialized != null)
			{
				Initialized(this, EventArgs.Empty);
			}
		}

		public event EventHandler Initialized;

		/// <summary>
		/// Gets the region with the specified name.
		/// </summary>
		/// <param name="regionName">Name of the region.</param>
		/// <returns></returns>
		/// <exception cref="UserMessageException">If a region with the specified name was not found.</exception>
		static protected IRegion GetRegion(string regionName)
		{
			ArgumentValidator.AssertNotNullOrEmpty(regionName, "regionName");

			var regionManager = ServiceLocatorSingleton.Instance.GetInstance<IRegionManager>();
			try
			{
				return regionManager.Regions[regionName];
			}
			catch (KeyNotFoundException ex)
			{
				throw new UserMessageException(regionName + " region was not found.", ex); /* TODO: Make localizable resource. */
			}
		}

		/// <summary>
		/// Adds a view to the specified region.
		/// </summary>
		/// <param name="regionName">Name of the region to add the view.</param>
		/// <param name="view">The view.</param>
		/// <exception cref="ArgumentNullException">If the specified view is null.</exception>
		/// <exception cref="ArgumentException">If regionName is null or empty.</exception>
		protected void ShowView(string regionName, object view)
		{
			ShowView(regionName, view, false);
		}

		/// <summary>
		/// Adds a view to the specified region. If the view already exists in the UI
		/// it will not be added. If activate is <c>true</c> the view will be brought 
		/// forward to the user.
		/// </summary>
		/// <param name="regionName">Name of the region to add the view.</param>
		/// <param name="view">The view.</param>
		/// <param name="activate">If <c>true</c> the view will be immediatly brought to visibility. 
		/// If <c>false</c> it may or may not be made visible.
		/// For example, if the view is located in a TabControl, 
		/// if <c>true</c> the view will be made the <c>SelectedItem</c>.</param>
		/// <exception cref="ArgumentNullException">If the specified view is null.</exception>
		/// <exception cref="ArgumentException">If regionName is null or empty.</exception>
		protected void ShowView(string regionName, object view, bool activate)
		{
			ArgumentValidator.AssertNotNullOrEmpty(regionName, "regionName");
			ArgumentValidator.AssertNotNull(view, "view");

			var viewService = ServiceLocatorSingleton.Instance.GetInstance<IViewService>();
			string actualRegionName;
			viewService.ShowView(view, regionName, activate, out actualRegionName);
		}

		/// <summary>
		/// Adds a list of views to a region.
		/// </summary>
		/// <param name="regionName">Name of the region.</param>
		/// <param name="views">The views.</param>
		/// <exception cref="ArgumentNullException">If the specified view list is null.</exception>
		/// <exception cref="ArgumentException">If regionName is null or empty.</exception>
		protected void ShowView(string regionName, IEnumerable<object> views)
		{
			ArgumentValidator.AssertNotNullOrEmpty(regionName, "regionName");
			ArgumentValidator.AssertNotNull(views, "views");

			var viewService = ServiceLocatorSingleton.Instance.GetInstance<IViewService>();
			string actualRegionName;
			
			foreach (var view in views)
			{
				viewService.ShowView(view, regionName, false, out actualRegionName);
			}
		}
	}
}
