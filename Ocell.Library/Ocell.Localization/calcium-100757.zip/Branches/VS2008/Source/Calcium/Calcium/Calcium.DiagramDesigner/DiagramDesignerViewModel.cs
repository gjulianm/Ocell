#region File and License Information
/*
<File>
	<Copyright>Copyright � 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License>
		Redistribution and use in source and binary forms, with or without
		modification, are permitted provided that the following conditions are met:
			* Redistributions of source code must retain the above copyright
			  notice, this list of conditions and the following disclaimer.
			* Redistributions in binary form must reproduce the above copyright
			  notice, this list of conditions and the following disclaimer in the
			  documentation and/or other materials provided with the distribution.
			* Neither the name of the <organization> nor the
			  names of its contributors may be used to endorse or promote products
			  derived from this software without specific prior written permission.

		THIS SOFTWARE IS PROVIDED BY <copyright holder> ''AS IS'' AND ANY
		EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
		WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
		DISCLAIMED. IN NO EVENT SHALL <copyright holder> BE LIABLE FOR ANY
		DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
		(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
		LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
		ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
		(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
		SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
	</License>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2010-01-29 16:34:07Z</CreationDate>
</File>
*/
#endregion

using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;

using DanielVaughan.Calcium.CommandModel;
using DanielVaughan.Calcium.DiagramDesigner.Commands;
using DanielVaughan.Calcium.DiagramDesigner.Tasks;
using DanielVaughan.Calcium.Gui;
using DanielVaughan.Calcium.Services;
using DanielVaughan.Services;
using DanielVaughan.TaskModel;

using Microsoft.Practices.Composite.Events;
using Microsoft.Practices.Composite.Presentation.Commands;

namespace DanielVaughan.Calcium.DiagramDesigner
{
	/// <summary>
	/// Layout and business logic for the <see cref="DiagramDesignerView"/>
	/// </summary>
	public class DiagramDesignerViewModel : ViewModelBase
	{
		readonly DelegateCommand<object> addDesignerItemCommand;
		readonly DelegateCommand<object> alignLeftCommand;

		public DiagramDesignerViewModel()
		{
			Title = "Model Designer";

			var commandsProxy = new DiagramDesignerCommandsProxy();

			addDesignerItemCommand = new UICommand<object>(AddDesignerItem, arg => Active);
			commandsProxy.AddDesignerItemCommand.RegisterCommand(addDesignerItemCommand);

			alignLeftCommand = new UICommand<object>(OnAlignLeft, arg => 
				Active && designerItems.Count > 0);
			commandsProxy.AlignLeftCommand.RegisterCommand(alignLeftCommand);

			ActiveChanged += OnActiveChanged;
		}

		bool shown;

		void OnActiveChanged(object sender, EventArgs e)
		{
			addDesignerItemCommand.IsActive = alignLeftCommand.IsActive = Active;

			if (shown)
			{
				return;
			}
			shown = true;
			AddDesignerItem(null);
			/* Clear the task service so that the add initial designer is not present. */
			var taskService = ServiceLocatorSingleton.Instance.GetInstance<ITaskService>();
			taskService.Clear(Id);
		}

		void OnAlignLeft(object obj)
		{
			var tasksAndArgs = designerItems.ToDictionary(
					x => (UndoableTaskBase<MoveDesignerHostArgs>)new MoveDesignerHostTask(), 
					x => new MoveDesignerHostArgs(x, new Point(20, x.Top)));

			var undoableTask = new CompositeUndoableTask<MoveDesignerHostArgs>(tasksAndArgs, "Align Left");
			var taskService = ServiceLocatorSingleton.Instance.GetInstance<ITaskService>();
			taskService.PerformTask(undoableTask, null, Id);
		}

		Point lastAddedAt = new Point(0, 0);
		double offset = 10;
		double offsetIncrement = 10;

		/// <summary>
		/// Adds a designer item to the list of designer items.
		/// This method demonstrates the <see cref="UndoableTask{T}"/>.
		/// </summary>
		/// <param name="obj">The obj parameter passed by the DelegateEvent. (Unused)</param>
		void AddDesignerItem(object obj)
		{
			DesignerItemViewModel designerItemViewModel;
			var removedItems = new Stack<DesignerItemViewModel>();
			UndoableTask<object> task = new UndoableTask<object>(
				delegate 
				{
					if (removedItems.Count > 0)
					{
						designerItemViewModel = removedItems.Pop();
					}
					else
					{
						if (lastAddedAt.Y > 200)
						{
							offset += offsetIncrement;
							lastAddedAt = new Point(offset, 0);
						}
						lastAddedAt = new Point(lastAddedAt.X + offsetIncrement, lastAddedAt.Y + offsetIncrement);
						designerItemViewModel = new DesignerItemViewModel
						                        	{
						                        		Left = lastAddedAt.X, Top = lastAddedAt.Y
						                        	};
					}

					designerItems.Add(designerItemViewModel);
				},
				delegate 
				{
					if (lastAddedAt.X > offset && lastAddedAt.Y > offset)
					{
						lastAddedAt = new Point(lastAddedAt.X - offset, lastAddedAt.Y - offset);
					}
					int removalIndex = designerItems.Count - 1;
					var viewModel = designerItems[removalIndex];
					designerItems.RemoveAt(removalIndex);
					removedItems.Push(viewModel);
					/* The align left command may not be executable now. */
					alignLeftCommand.RaiseCanExecuteChanged();

				}, "Add Designer Item"); 

			task.Repeatable = true;
			var taskService = ServiceLocatorSingleton.Instance.GetInstance<ITaskService>();
			taskService.PerformTask(task, null, Id);

			/* The align left command can now be executed. */
			alignLeftCommand.RaiseCanExecuteChanged();
		}

		readonly ObservableCollection<DesignerItemViewModel> designerItems = new ObservableCollection<DesignerItemViewModel>();

		/// <summary>
		/// Gets the designer items.
		/// </summary>
		/// <value>The designer items.</value>
		public ObservableCollection<DesignerItemViewModel> DesignerItems
		{
			get
			{
				return designerItems;
			}
		}

		/// <summary>
		/// Notifies the this instance that a drag 
		/// of a <see cref="DesignerItemViewModel"/> has completed.
		/// This method enables the creation of an undoable task
		/// which is sent to the <see cref="ITaskService"/>.
		/// </summary>
		/// <param name="viewModel">The view model.</param>
		/// <param name="startPoint">The start point.</param>
		public void PerformPostDrag(DesignerItemViewModel viewModel, Point startPoint)
		{
			Point endPoint = new Point(viewModel.Left, viewModel.Top);
			var task = new MoveDesignerHostTask();
			var taskService = ServiceLocatorSingleton.Instance.GetInstance<ITaskService>();
			var args = new MoveDesignerHostArgs(viewModel, startPoint, endPoint);
			taskService.PerformTask(task, args, Id);
		}
	}
}
