﻿#region File and License Information
/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License>
		Redistribution and use in source and binary forms, with or without
		modification, are permitted provided that the following conditions are met:
			* Redistributions of source code must retain the above copyright
			  notice, this list of conditions and the following disclaimer.
			* Redistributions in binary form must reproduce the above copyright
			  notice, this list of conditions and the following disclaimer in the
			  documentation and/or other materials provided with the distribution.
			* Neither the name of the <organization> nor the
			  names of its contributors may be used to endorse or promote products
			  derived from this software without specific prior written permission.

		THIS SOFTWARE IS PROVIDED BY <copyright holder> ''AS IS'' AND ANY
		EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
		WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
		DISCLAIMED. IN NO EVENT SHALL <copyright holder> BE LIABLE FOR ANY
		DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
		(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
		LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
		ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
		(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
		SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
	</License>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2009-05-17 19:18:46Z</CreationDate>
</File>
*/
#endregion

using System;
using System.Collections.Generic;

namespace DanielVaughan.Calcium
{
	/// <summary>
	/// Use this class to write to the application log.
	/// </summary>
	public static class Log
	{
		#region Write log overloads
		public static void Debug(string message)
		{
			Logging.Log.Debug(message);
		}

		public static void Debug(string message, Exception exception)
		{
			Logging.Log.Debug(message, exception);
		}

		public static void Debug(string message, Dictionary<string, object> properties)
		{
			/* TODO: [DV] implement properties in Clog. */
			Logging.Log.Debug(message);
		}

		public static void Debug(string message, Exception exception, Dictionary<string, object> properties)
		{
			/* TODO: [DV] implement properties in Clog. */
			Logging.Log.Debug(message, exception);
		}

		public static void Info(string message)
		{
			Logging.Log.Info(message);
		}

		public static void Info(string message, Exception exception)
		{
			Logging.Log.Info(message, exception);
		}

		public static void Info(string message, Dictionary<string, object> properties)
		{
			/* TODO: [DV] implement properties in Clog. */
			Logging.Log.Info(message);
		}

		public static void Info(string message, Exception exception, Dictionary<string, object> properties)
		{
			/* TODO: [DV] implement properties in Clog. */
			Logging.Log.Info(message, exception);
		}

		public static void Warn(string message)
		{
			Logging.Log.Warn(message);
		}

		public static void Warn(string message, Exception exception)
		{
			Logging.Log.Warn(message, exception);
		}

		public static void Warn(string message, Dictionary<string, object> properties)
		{
			/* TODO: [DV] implement properties in Clog. */
			Logging.Log.Warn(message);
		}

		public static void Warn(string message, Exception exception, Dictionary<string, object> properties)
		{
			/* TODO: [DV] implement properties in Clog. */
			Logging.Log.Warn(message, exception);
		}

		public static void Error(string message)
		{
			Logging.Log.Error(message);
		}

		public static void Error(string message, Exception exception)
		{
			Logging.Log.Error(message, exception);
		}

		public static void Error(string message, Dictionary<string, object> properties)
		{
			/* TODO: [DV] implement properties in Clog. */
			Logging.Log.Error(message);
		}

		public static void Error(string message, Exception exception, Dictionary<string, object> properties)
		{
			/* TODO: [DV] implement properties in Clog. */
			Logging.Log.Error(message, exception);
		}

		public static void Fatal(string message)
		{
			Logging.Log.Fatal(message);
		}

		public static void Fatal(string message, Exception exception)
		{
			Logging.Log.Fatal(message, exception);
		}

		public static void Fatal(string message, Dictionary<string, object> properties)
		{
			/* TODO: [DV] implement properties in Clog. */
			Logging.Log.Fatal(message);
		}

		public static void Fatal(string message, Exception exception, Dictionary<string, object> properties)
		{
			/* TODO: [DV] implement properties in Clog. */
			Logging.Log.Fatal(message, exception);
		}
		#endregion

		#region IsEnabled Properties
		public static bool DebugEnabled
		{
			get
			{
				return Logging.Log.DebugEnabled;
			}
		}

		public static bool InfoEnabled
		{
			get
			{
				return Logging.Log.InfoEnabled;
			}
		}

		public static bool WarnEnabled
		{
			get
			{
				return Logging.Log.WarnEnabled;
			}
		}

		public static bool ErrorEnabled
		{
			get
			{
				return Logging.Log.ErrorEnabled;
			}
		}

		public static bool FatalEnabled
		{
			get
			{
				return Logging.Log.FatalEnabled;
			}
		}
		#endregion
	}
}
