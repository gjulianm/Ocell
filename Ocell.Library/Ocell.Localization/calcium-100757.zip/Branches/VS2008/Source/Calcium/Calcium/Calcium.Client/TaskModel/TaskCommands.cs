﻿#region File and License Information
/*
<File>
	<Copyright>Copyright © 2010, Daniel Vaughan. All rights reserved.</Copyright>
	<License>
		Redistribution and use in source and binary forms, with or without
		modification, are permitted provided that the following conditions are met:
			* Redistributions of source code must retain the above copyright
			  notice, this list of conditions and the following disclaimer.
			* Redistributions in binary form must reproduce the above copyright
			  notice, this list of conditions and the following disclaimer in the
			  documentation and/or other materials provided with the distribution.
			* Neither the name of the <organization> nor the
			  names of its contributors may be used to endorse or promote products
			  derived from this software without specific prior written permission.

		THIS SOFTWARE IS PROVIDED BY <copyright holder> ''AS IS'' AND ANY
		EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
		WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
		DISCLAIMED. IN NO EVENT SHALL <copyright holder> BE LIABLE FOR ANY
		DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
		(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
		LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
		ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
		(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
		SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
	</License>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2010-02-03 18:59:21Z</CreationDate>
</File>
*/
#endregion

using System.Linq;

using DanielVaughan.Calcium.CommandModel;
using DanielVaughan.Calcium.Services;
using DanielVaughan.Services;
using DanielVaughan.Windows;

namespace DanielVaughan.Calcium.TaskModel
{
	public class TaskCommandProxies
	{
		static readonly UndoGlobalTaskCommandLogic undoGlobalTaskCommandLogic = new UndoGlobalTaskCommandLogic();
		public static UndoGlobalTaskCommandLogic UndoGlobalTaskCommandLogic
		{
			get
			{
				return undoGlobalTaskCommandLogic;
			}
		}

		static readonly RedoGlobalTaskCommandLogic redoGlobalTaskCommandLogic = new RedoGlobalTaskCommandLogic();
		public static RedoGlobalTaskCommandLogic RedoGlobalTaskCommandLogic
		{
			get
			{
				return redoGlobalTaskCommandLogic;
			}
		}

		static readonly RepeatGlobalTaskCommandLogic repeatGlobalTaskCommandLogic = new RepeatGlobalTaskCommandLogic();
		public static RepeatGlobalTaskCommandLogic RepeatGlobalTaskCommandLogic
		{
			get
			{
				return repeatGlobalTaskCommandLogic;
			}
		}

		static readonly UndoTaskCommandLogic undoTaskCommandLogic = new UndoTaskCommandLogic();
		public static UndoTaskCommandLogic UndoTaskCommandLogic
		{
			get
			{
				return undoTaskCommandLogic;
			}
		}

		static readonly RedoTaskCommandLogic redoTaskCommandLogic = new RedoTaskCommandLogic();
		public static RedoTaskCommandLogic RedoTaskCommandLogic
		{
			get
			{
				return redoTaskCommandLogic;
			}
		}

		static readonly RepeatTaskCommandLogic repeatTaskCommandLogic = new RepeatTaskCommandLogic();
		public static RepeatTaskCommandLogic RepeatTaskCommandLogic
		{
			get
			{
				return repeatTaskCommandLogic;
			}
		}
	}

	public class UndoGlobalTaskCommandLogic
	{
		readonly UICommand<object> command;

		public UndoGlobalTaskCommandLogic()
		{
			command = new UICommand<object>(OnExecuteMethod, OnCanExecuteMethod);	
		}

		bool OnCanExecuteMethod(object arg)
		{
			if (DesignTimeEnvironment.DesignTime)
			{
				return true;
			}

			var taskService = ServiceLocatorSingleton.Instance.GetInstance<ITaskService>();
			var result = taskService.CanUndo(null);
			string newText = string.Empty;
			if (result)
			{
				/* For now we ignore the fact that we can retrieve the last task 
				 * from the task service and find out it's description. */
				var lastTask = taskService.GetUndoableTasks(null).ToList().LastOrDefault();
				if (lastTask != null)
				{
					newText = lastTask.DescriptionForUser;
				}
			}
			command.Text = string.Format(StringResources.TaskModel_UndoGlobalFormat, newText);
			return result;
		}

		void OnExecuteMethod(object obj)
		{
			var taskService = ServiceLocatorSingleton.Instance.GetInstance<ITaskService>();
			var taskResult = taskService.Undo(null);
		}

		public UICommand<object> Command
		{
			get
			{
				return command;
			}
		}
	}

	public class RedoGlobalTaskCommandLogic
	{
		readonly UICommand<object> command;

		public RedoGlobalTaskCommandLogic()
		{
			command = new UICommand<object>(OnExecuteMethod, OnCanExecuteMethod);
		}

		bool OnCanExecuteMethod(object arg)
		{
			if (DesignTimeEnvironment.DesignTime)
			{
				return true;
			}

			var taskService = ServiceLocatorSingleton.Instance.GetInstance<ITaskService>();
			var result = taskService.CanRedo(null);
			string newText = string.Empty;
			if (result)
			{
				var lastTask = taskService.GetRedoableTasks(null).ToList().LastOrDefault();
				if (lastTask != null)
				{
					newText = lastTask.DescriptionForUser;
				}
			}
			command.Text = string.Format(StringResources.TaskModel_RedoGlobalFormat, newText);
			return result;
		}

		void OnExecuteMethod(object obj)
		{
			var taskService = ServiceLocatorSingleton.Instance.GetInstance<ITaskService>();
			var taskResult = taskService.Redo(null);
		}

		public UICommand<object> Command
		{
			get
			{
				return command;
			}
		}
	}

	public class RepeatGlobalTaskCommandLogic
	{
		readonly UICommand<object> command;

		public RepeatGlobalTaskCommandLogic()
		{
			command = new UICommand<object>(OnExecuteMethod, OnCanExecuteMethod);
		}

		bool OnCanExecuteMethod(object arg)
		{
			if (DesignTimeEnvironment.DesignTime)
			{
				return true;
			}

			var taskService = ServiceLocatorSingleton.Instance.GetInstance<ITaskService>();
			var result = taskService.CanRepeat(null);
			string newText = string.Empty;
			if (result)
			{
				var lastTask = taskService.GetRepeatableTasks(null).ToList().LastOrDefault();
				if (lastTask != null)
				{
					newText = lastTask.DescriptionForUser;
				}
			}
			command.Text = string.Format(StringResources.TaskModel_RepeatGlobalFormat, newText);
			return result;
		}

		void OnExecuteMethod(object obj)
		{
			var taskService = ServiceLocatorSingleton.Instance.GetInstance<ITaskService>();
			var taskResult = taskService.Repeat(null);
		}

		public UICommand<object> Command
		{
			get
			{
				return command;
			}
		}
	}

	public class UndoTaskCommandLogic
	{
		readonly UICommand<object> command;

		public UndoTaskCommandLogic()
		{
			command = new UICommand<object>(OnExecuteMethod, OnCanExecuteMethod);
		}

		bool OnCanExecuteMethod(object arg)
		{
			if (DesignTimeEnvironment.DesignTime)
			{
				return true;
			}

			var viewService = ServiceLocatorSingleton.Instance.GetInstance<IViewService>();
			var activeView = viewService.ActiveView;
			if (activeView == null)
			{
				return false;
			}

			var taskService = ServiceLocatorSingleton.Instance.GetInstance<ITaskService>();
			var id = activeView.ViewModel != null ? (object)activeView.ViewModel.Id : activeView;
			var result = taskService.CanUndo(id);
			string newText = string.Empty;
			if (result)
			{
				var lastTask = taskService.GetUndoableTasks(id).ToList().LastOrDefault();
				if (lastTask != null)
				{
					newText = lastTask.DescriptionForUser;
				}
			}
			command.Text = string.Format(StringResources.TaskModel_UndoFormat, newText);
			return result;
		}

		void OnExecuteMethod(object obj)
		{
			var viewService = ServiceLocatorSingleton.Instance.GetInstance<IViewService>();
			var activeView = viewService.ActiveView;
			if (activeView == null)
			{
				return;
			}
			var taskService = ServiceLocatorSingleton.Instance.GetInstance<ITaskService>();
			var id = activeView.ViewModel != null ? (object)activeView.ViewModel.Id : activeView;
			taskService.Undo(id);
		}

		public UICommand<object> Command
		{
			get
			{
				return command;
			}
		}
	}

	public class RedoTaskCommandLogic
	{
		readonly UICommand<object> command;

		public RedoTaskCommandLogic()
		{
			command = new UICommand<object>(OnExecuteMethod, OnCanExecuteMethod);
		}

		bool OnCanExecuteMethod(object arg)
		{
			if (DesignTimeEnvironment.DesignTime)
			{
				return true;
			}

			var viewService = ServiceLocatorSingleton.Instance.GetInstance<IViewService>();
			var activeView = viewService.ActiveView;
			if (activeView == null)
			{
				return false;
			}

			var taskService = ServiceLocatorSingleton.Instance.GetInstance<ITaskService>();
			var id = activeView.ViewModel != null ? (object)activeView.ViewModel.Id : activeView;
			var result = taskService.CanRedo(id);
			string newText = string.Empty;
			if (result)
			{
				var lastTask = taskService.GetRedoableTasks(id).ToList().LastOrDefault();
				if (lastTask != null)
				{
					newText = lastTask.DescriptionForUser;
				}
			}
			command.Text = string.Format(StringResources.TaskModel_RedoFormat, newText);
			return result;
		}

		void OnExecuteMethod(object obj)
		{
			var viewService = ServiceLocatorSingleton.Instance.GetInstance<IViewService>();
			var activeView = viewService.ActiveView;
			if (activeView == null)
			{
				return;
			}
			var taskService = ServiceLocatorSingleton.Instance.GetInstance<ITaskService>();
			var id = activeView.ViewModel != null ? (object)activeView.ViewModel.Id : activeView;
			taskService.Redo(id);
		}

		public UICommand<object> Command
		{
			get
			{
				return command;
			}
		}
	}

	public class RepeatTaskCommandLogic
	{
		readonly UICommand<object> command;

		public RepeatTaskCommandLogic()
		{
			command = new UICommand<object>(OnExecuteMethod, OnCanExecuteMethod);
		}

		bool OnCanExecuteMethod(object arg)
		{
			if (DesignTimeEnvironment.DesignTime)
			{
				return true;
			}

			var viewService = ServiceLocatorSingleton.Instance.GetInstance<IViewService>();
			var activeView = viewService.ActiveView;
			if (activeView == null)
			{
				return false;
			}

			var taskService = ServiceLocatorSingleton.Instance.GetInstance<ITaskService>();
			var id = activeView.ViewModel != null ? (object)activeView.ViewModel.Id : activeView;
			var result = taskService.CanRepeat(id);
			string newText = string.Empty;
			if (result)
			{
				var lastTask = taskService.GetRepeatableTasks(id).ToList().LastOrDefault();
				if (lastTask != null)
				{
					newText = lastTask.DescriptionForUser;
				}
			}
			command.Text = string.Format(StringResources.TaskModel_RepeatFormat, newText);
			return result;
		}

		void OnExecuteMethod(object obj)
		{
			var viewService = ServiceLocatorSingleton.Instance.GetInstance<IViewService>();
			var activeView = viewService.ActiveView;
			if (activeView == null)
			{
				return;
			}
			var taskService = ServiceLocatorSingleton.Instance.GetInstance<ITaskService>();
			var id = activeView.ViewModel != null ? (object)activeView.ViewModel.Id : activeView;
			taskService.Repeat(id);
		}

		public UICommand<object> Command
		{
			get
			{
				return command;
			}
		}
	}

}
