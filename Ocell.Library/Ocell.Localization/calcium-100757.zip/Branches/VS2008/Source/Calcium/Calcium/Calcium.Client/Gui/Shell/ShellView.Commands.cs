﻿#region File and License Information
/*
<File>
	<Copyright>Copyright © 2010, Daniel Vaughan. All rights reserved.</Copyright>
	<License>
		Redistribution and use in source and binary forms, with or without
		modification, are permitted provided that the following conditions are met:
			* Redistributions of source code must retain the above copyright
			  notice, this list of conditions and the following disclaimer.
			* Redistributions in binary form must reproduce the above copyright
			  notice, this list of conditions and the following disclaimer in the
			  documentation and/or other materials provided with the distribution.
			* Neither the name of the <organization> nor the
			  names of its contributors may be used to endorse or promote products
			  derived from this software without specific prior written permission.

		THIS SOFTWARE IS PROVIDED BY <copyright holder> ''AS IS'' AND ANY
		EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
		WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
		DISCLAIMED. IN NO EVENT SHALL <copyright holder> BE LIABLE FOR ANY
		DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
		(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
		LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
		ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
		(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
		SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
	</License>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2010-03-12 19:38:09Z</CreationDate>
</File>
*/
#endregion

using System.Collections.Generic;
using System.Windows.Input;

using DanielVaughan.Calcium.Events;
using DanielVaughan.IO;

using Microsoft.Practices.Composite.Events;

namespace DanielVaughan.Calcium.Gui
{
	public partial class ShellView
	{
		public static RoutedUICommand SaveAll = new RoutedUICommand("Save All", "SaveAll", typeof(ShellView));

		void AttachCommandBindings()
		{
			var commandList = new List<CommandBinding>
			                  	{
			                  		new CommandBinding(ApplicationCommands.Close,	OnCloseCommandExecute,	CloseCommandCanExecute),
			                  		new CommandBinding(ApplicationCommands.Save,	OnSave,					OnCanSave),
			                  		new CommandBinding(ApplicationCommands.SaveAs,	OnSaveAs,				OnCanSaveAs),
									new CommandBinding(SaveAll,						OnSaveAll,				OnCanSaveAll)
			                  	};
			CommandBindings.AddRange(commandList);
		}

		void OnCanSaveAll(object sender, CanExecuteRoutedEventArgs e)
		{
			var allSavableContent = GetAllSavableContent();
			foreach (var content in allSavableContent)
			{
				if (content.CanSave && content.Dirty)
				{
					e.CanExecute = true;
					e.Handled = true;
				}
			}
		}

		void OnSaveAll(object sender, ExecutedRoutedEventArgs e)
		{
			var allSavableContent = GetAllSavableContent();
			foreach (var content in allSavableContent)
			{
				if (content.CanSave && content.Dirty)
				{
					var operationResult = content.Save(FileErrorAction.UseAlternative);
					if (operationResult == FileOperationResult.Cancelled)
					{
						break;
					}
				}
			}
			e.Handled = true;
		}

		void OnCanSaveAs(object sender, CanExecuteRoutedEventArgs e)
		{
			var savableContent = GetSavableContent();

			if (savableContent != null)
			{
				e.CanExecute = savableContent.CanSave;
			}
		}

		void OnSaveAs(object sender, ExecutedRoutedEventArgs e)
		{
			var savableContent = GetSavableContent();

			if (savableContent != null)
			{
				savableContent.SaveAs(FileErrorAction.UseAlternative);
				e.Handled = true;
			}
		}

		void OnCanSave(object sender, CanExecuteRoutedEventArgs e)
		{
			var savableContent = GetSavableContent();

			if (savableContent != null)
			{
				e.CanExecute = savableContent.CanSave;
				e.Handled = true;
			}
		}

		void OnSave(object sender, ExecutedRoutedEventArgs e)
		{
			var savableContent = GetSavableContent();

			if (savableContent != null)
			{
				if (savableContent.NewFile)
				{
					savableContent.SaveAs(FileErrorAction.UseAlternative);
				}
				else
				{
					savableContent.Save(FileErrorAction.UseAlternative);
				}
				e.Handled = true;
			}
		}

		#region Close
		protected override void OnClosing(System.ComponentModel.CancelEventArgs e)
		{
			bool wasCancelled;
			ExitApplication(out wasCancelled);
			if (wasCancelled)
			{
				e.Cancel = true;
				return;
			}
			base.OnClosing(e);
		}

		void ExitApplication(out bool cancel)
		{
			/* We allow subscribers to the ApplicationExitEvent to cancel the close. */
			var eventAggregator = ServiceLocatorSingleton.Instance.GetInstance<IEventAggregator>();
			var exitEvent = eventAggregator.GetEvent<ApplicationExitEvent>();
			var eventArgs = new CancelableEventArgs<object>(null);
			exitEvent.Publish(eventArgs);
			if (eventArgs.Cancel) /* If a subscriber has cancelled the exit then we abort. */
			{
				cancel = true;
				return;
			}
			cancel = false;
			return;
		}

		void OnCloseCommandExecute(object sender, ExecutedRoutedEventArgs e)
		{
			var view = e.Parameter as IView ?? MainView;
			if (view != null)
			{
				e.Handled = true;
				view.Close(false);
			}
		}

		void CloseCommandCanExecute(object sender, CanExecuteRoutedEventArgs e)
		{
			e.CanExecute = true;
		}
		#endregion
	}
}
