﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using DanielVaughan;
using DanielVaughan.Calcium;
using DanielVaughan.Calcium.Gui;

using Microsoft.Practices.Composite.Events;
using Microsoft.Practices.Composite.Presentation.Commands;
using Microsoft.Practices.Composite.Presentation.Events;

namespace $safeprojectname$
{
	public class $CustomModule$ViewModel : ViewModelBase
	{
		public $CustomModule$ViewModel()
		{
			Title = "$CustomModule$";
		}
	}
}
