﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Net;
//using System.Windows;
//using System.Windows.Controls;
//using System.Windows.Documents;
//using System.Windows.Ink;
//using System.Windows.Input;
//using System.Windows.Media;
//using System.Windows.Media.Animation;
//using System.Windows.Shapes;
//
//using Infusion.Silverlight.Controls.Ribbon;
//
//using Microsoft.Practices.Composite.Presentation.Regions;
//using Microsoft.Practices.Composite.Regions;
//
//namespace DanielVaughan.Calcium.Gui.RegionAdapters
//{
//	public class RibbonRegionAdapter : RegionAdapterBase<Ribbon>
//	{
//		public RibbonRegionAdapter(IRegionBehaviorFactory regionBehaviorFactory) : base(regionBehaviorFactory)
//		{
//			/* Intentionally left blank. */
//		}
//
//		protected override IRegion CreateRegion()
//		{
//			IRegion region = new AllActiveRegion();
//			return region;
//		}
//
//		protected override void Adapt(IRegion region, Ribbon regionTarget)
//		{
//			AddItems(regionTarget, region.ActiveViews.ToList());
//		}
//
//		static void AddItems(Ribbon control, IList<object> newItems)
//		{
//			ArgumentValidator.AssertNotNull(control, "control");
//
//			if (newItems == null)
//			{
//				return;
//			}
//
//			foreach (var item in newItems.OfType<RibbonButton>())
//			{
//				control.QuickLaunchButtons.Add(item);
//			}
//
//			var dependencyItem = control as DependencyObject;
//			if (dependencyItem == null)
//			{
//				return;
//			}
//			RegionManager.SetRegionName(dependencyItem, RegionManager.GetRegionName(dependencyItem));
//		}
//
//		static void RemoveItems(Ribbon control, IList<object> oldItems)
//		{
//			if (oldItems == null)
//			{
//				return;
//			}
//
//			foreach (var item in oldItems.OfType<RibbonButton>())
//			{
//				control.QuickLaunchButtons.Remove(item);
//			}
//		}
//	}
//}
