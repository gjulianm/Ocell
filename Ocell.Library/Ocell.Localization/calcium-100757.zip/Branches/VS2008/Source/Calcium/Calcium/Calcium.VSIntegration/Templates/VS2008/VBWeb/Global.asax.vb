﻿Imports System.Web.SessionState
Imports System.IO

Imports log4net.Config

Imports Microsoft.Practices.Unity
Imports Microsoft.Practices.Unity.Configuration

Imports DanielVaughan
Imports DanielVaughan.Calcium
Imports DanielVaughan.Calcium.ClientServices
Imports DanielVaughan.ServiceLocation.Unity
Imports DanielVaughan.Services


Public Class Global_asax
    Inherits System.Web.HttpApplication

    Sub Application_Start(ByVal sender As Object, ByVal e As EventArgs)
		Dim ex As Exception
		'This causes log4net to initalise. 
		' We need this for the ClientLogging library 
		' to be able to log using log4net. 
		' It triggers reading the config etc. [DV] */
		XmlConfigurator.Configure(New FileInfo((MyBase.Server.MapPath("~") & "Log4Net.config")))
		Log.Info("Web application starting.")
		Try
			Dim container As New UnityContainer
			Dim section As UnityConfigurationSection = DirectCast(ConfigurationManager.GetSection("unity"), UnityConfigurationSection)
			section.Containers.Default.Configure(container)
			ServiceLocatorSingleton.Instance.InitializeServiceLocator(container)
		Catch exception1 As Exception
			ex = exception1
			Log.Fatal("Unable to initialize Unity from configuration.", ex)
			Throw
		End Try
		Try
			Me.ConfigureUnity()
		Catch exception2 As Exception
			ex = exception2
			Log.Fatal("Unable to initialize Unity core services.", ex)
			Throw
		End Try

    End Sub
	Private Sub ConfigureUnity()
		Dim communicationService As New CommunicationService
		ServiceLocatorSingleton.Instance.RegisterInstance(Of ICommunicationService)(communicationService)
		ServiceLocatorSingleton.Instance.RegisterType(Of IMessageService, ServerSideMessageService)()
	End Sub

    Sub Session_Start(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires when the session is started
    End Sub

    Sub Application_BeginRequest(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires at the beginning of each request
    End Sub

    Sub Application_AuthenticateRequest(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires upon attempting to authenticate the use
    End Sub

    Sub Application_Error(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires when an error occurs
    End Sub

    Sub Session_End(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires when the session ends
    End Sub

    Sub Application_End(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires when the application ends
    End Sub

End Class