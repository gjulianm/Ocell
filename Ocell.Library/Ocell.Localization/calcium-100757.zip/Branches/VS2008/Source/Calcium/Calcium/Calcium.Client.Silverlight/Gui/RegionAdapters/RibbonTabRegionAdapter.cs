﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Net;
//using System.Windows;
//using System.Windows.Controls;
//using System.Windows.Documents;
//using System.Windows.Ink;
//using System.Windows.Input;
//using System.Windows.Media;
//using System.Windows.Media.Animation;
//using System.Windows.Shapes;
//
//using Infusion.Silverlight.Controls.Ribbon;
//
//using Microsoft.Practices.Composite.Presentation.Regions;
//using Microsoft.Practices.Composite.Regions;
//
//namespace DanielVaughan.Calcium.Gui.RegionAdapters
//{
//	public class RibbonTabRegionAdapter : RegionAdapterBase<RibbonTab>
//	{
//		public RibbonTabRegionAdapter(IRegionBehaviorFactory regionBehaviorFactory)
//			: base(regionBehaviorFactory)
//		{
//			/* Intentionally left blank. */
//		}
//
//		protected override IRegion CreateRegion()
//		{
//			IRegion region = new AllActiveRegion();
//			return region;
//		}
//
//		protected override void Adapt(IRegion region, RibbonTab regionTarget)
//		{
//			AddItems(regionTarget, region.ActiveViews.ToList());
//		}
//
//		static void AddItems(RibbonTab control, IList<object> newItems)
//		{
//			ArgumentValidator.AssertNotNull(control, "control");
//
//			if (newItems == null)
//			{
//				return;
//			}
//
//			foreach (var item in newItems.OfType<RibbonTabGroup>())
//			{
//				control.Groups.Add(item);
//			}
//
//			var dependencyItem = control as DependencyObject;
//			if (dependencyItem == null)
//			{
//				return;
//			}
//			RegionManager.SetRegionName(dependencyItem, RegionManager.GetRegionName(dependencyItem));
//		}
//
//		static void RemoveItems(RibbonTab control, IList<object> oldItems)
//		{
//			if (oldItems == null)
//			{
//				return;
//			}
//
//			foreach (var item in oldItems.OfType<RibbonTabGroup>())
//			{
//				control.Groups.Remove(item);
//			}
//		}
//	}
//}
