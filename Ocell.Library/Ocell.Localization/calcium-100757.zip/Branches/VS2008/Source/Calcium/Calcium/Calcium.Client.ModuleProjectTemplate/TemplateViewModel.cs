using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using DanielVaughan.Calcium.Gui;

namespace DesktopClient.ModuleProjectTemplate
{
	public class TemplateViewModel : ViewModelBase
	{
		public TemplateViewModel()
		{
			Title = "Template";
		}
	}
}
