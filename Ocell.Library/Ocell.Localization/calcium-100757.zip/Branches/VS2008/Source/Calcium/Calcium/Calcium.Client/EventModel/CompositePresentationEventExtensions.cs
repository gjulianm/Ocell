﻿//using System;

//using Microsoft.Practices.Composite.Presentation.Events;

//namespace DanielVaughan.Calcium.EventModel
//{
//    public static class CompositePresentationEventExtensions
//    {
//        public static IObservable<TEventArgs> AsObservable<TEventArgs>(
//            this CompositePresentationEvent<TEventArgs> presentationEvent)
//        {
//            return new CompositePresentationEventObservable<TEventArgs>(presentationEvent);
//        }
//    }

//    public class CompositePresentationEventObservable<TEventArgs> : IObservable<TEventArgs>
//    {
//        readonly CompositePresentationEvent<TEventArgs> presentationEvent;

//        public CompositePresentationEventObservable(
//            CompositePresentationEvent<TEventArgs> presentationEvent)
//        {
//            if (presentationEvent == null)
//            {
//                throw new ArgumentNullException("presentationEvent");
//            }
//            this.presentationEvent = presentationEvent;
//        }

//        public IDisposable Subscribe(IObserver<TEventArgs> observer)
//        {
//            return new CompositePresentationEventSubscription<TEventArgs>(presentationEvent, observer);
//        }
//    }

//    public class CompositePresentationEventSubscription<TEventArgs> : IDisposable
//    {
//        readonly IObserver<TEventArgs> observer;
//        readonly CompositePresentationEvent<TEventArgs> presentationEvent;

//        public CompositePresentationEventSubscription(
//            CompositePresentationEvent<TEventArgs> presentationEvent,
//            IObserver<TEventArgs> observer)
//        {
//            ArgumentValidator.AssertNotNull(presentationEvent, "presentationEvent");
//            ArgumentValidator.AssertNotNull(observer, "observer");

//            this.presentationEvent = presentationEvent;
//            this.observer = observer;

//            presentationEvent.Subscribe(observer.OnNext);
//        }

//        protected virtual void Dispose(bool disposing)
//        {
//            if (disposing)
//            {
//                presentationEvent.Unsubscribe(observer.OnNext);
//            }
//        }

//        public void Dispose()
//        {
//            Dispose(true);
//            GC.SuppressFinalize(this);
//        }

//        ~CompositePresentationEventSubscription()
//        {
//            Dispose(false);
//        }
//    }
//}