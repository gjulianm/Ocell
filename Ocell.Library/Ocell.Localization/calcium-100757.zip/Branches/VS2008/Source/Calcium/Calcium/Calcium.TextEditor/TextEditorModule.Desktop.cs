using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using DanielVaughan.Calcium;

using Microsoft.Practices.Composite.Modularity;

namespace DanielVaughan.Calcium.TextEditor
{
	[Module(ModuleName = ModuleNames.TextEditor)]
	public partial class TextEditorModule
	{
	}
}
