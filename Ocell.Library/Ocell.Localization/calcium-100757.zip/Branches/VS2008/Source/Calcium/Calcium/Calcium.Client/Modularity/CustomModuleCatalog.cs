#region File and License Information
/*
<File>
	<Copyright>Copyright � 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License>
		Redistribution and use in source and binary forms, with or without
		modification, are permitted provided that the following conditions are met:
			* Redistributions of source code must retain the above copyright
			  notice, this list of conditions and the following disclaimer.
			* Redistributions in binary form must reproduce the above copyright
			  notice, this list of conditions and the following disclaimer in the
			  documentation and/or other materials provided with the distribution.
			* Neither the name of the <organization> nor the
			  names of its contributors may be used to endorse or promote products
			  derived from this software without specific prior written permission.

		THIS SOFTWARE IS PROVIDED BY <copyright holder> ''AS IS'' AND ANY
		EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
		WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
		DISCLAIMED. IN NO EVENT SHALL <copyright holder> BE LIABLE FOR ANY
		DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
		(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
		LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
		ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
		(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
		SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
	</License>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2009-05-17 19:06:56Z</CreationDate>
</File>
*/
#endregion

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Permissions;
using System.Security.Policy;

using DanielVaughan.Reflection;

using Microsoft.Practices.Composite;
using Microsoft.Practices.Composite.Modularity;

namespace DanielVaughan.Calcium.Modularity
{
	/// <summary>
	/// Represets a catalog created from a directory on disk.
	/// </summary>
	/// <remarks>
	/// The directory catalog will scan the contents of a directory, locating classes that implement
	/// <see cref="IModule"/> and add them to the catalog based on contents in their associated <see cref="ModuleAttribute"/>.
	/// Assemblies are loaded into a new application domain with ReflectionOnlyLoad.  The application domain is destroyed
	/// once the assemblies have been discovered.
	/// 
	/// The diretory catalog does not continue to monitor the directory after it has created the initialze catalog.
	/// </remarks>
	[SecurityPermission(SecurityAction.LinkDemand)]
	[SecurityPermission(SecurityAction.InheritanceDemand)]
	public class CustomModuleCatalog : ModuleCatalog
	{
		/// <summary>
		/// Directory containing modules to search for.
		/// </summary>
		public string ModulePath { get; set; }

		/// <summary>
		/// Drives the main logic of building the child domain and searching for the assemblies.
		/// </summary>
		protected override void InnerLoad()
		{
			if (string.IsNullOrEmpty(ModulePath))
			{
				throw new InvalidOperationException("ModulePath can't be null or empty.");
			}

            if (!Directory.Exists(ModulePath))
			{
				throw new InvalidOperationException(
					string.Format(CultureInfo.CurrentCulture, "Directory not found {0}", ModulePath));
			}

			/* Record start time so that we can measure how long the loading takes. */
			DateTime startTime = DateTime.Now;

			IEnumerable<ModuleInfo> knownModules = new List<ModuleInfo>();
			AppDomain childDomain = BuildChildDomain(AppDomain.CurrentDomain);
			try
			{
				ModuleInfo[] defaultInfos = new ModuleInfo[0];
				var loadedAssemblies = new List<string>();

				var assemblies = (
									 from Assembly assembly in AppDomain.CurrentDomain.GetAssemblies()
									 where !(assembly is System.Reflection.Emit.AssemblyBuilder)
										   && !String.IsNullOrEmpty(assembly.Location)
									 select assembly.Location
								 );

				loadedAssemblies.AddRange(assemblies);

				Type loaderType = typeof(InnerModuleInfoLoader);

				if (loaderType.Assembly != null)
				{
					var loader = (InnerModuleInfoLoader)childDomain.CreateInstanceFrom(
						loaderType.Assembly.Location, loaderType.FullName).Unwrap();
					loader.LoadAssemblies(loadedAssemblies);
					defaultInfos = loader.GetModuleInfos(ModulePath);

					knownModules = defaultInfos;
					var parameters = ServiceLocatorSingleton.Instance.GetInstance<ModuleCatalogOptions>();
					/* Exclude those modules that have been explicitly defined as excluded modules. */
					if (parameters != null && parameters.ExcludedModules != null 
						&& parameters.ExcludedModules.Count > 0)
					{
						knownModules = defaultInfos.Where(x => !parameters.ExcludedModules.Contains(x.ModuleName));
					}
					
					/* This is required to list unloaded modules in the module manager. */
					ModuleManagerSingleton.Instance.AddKnownModuleRange(knownModules);
				}
			}
			finally
			{
				AppDomain.Unload(childDomain);
			}

			var failedModules = ModuleManagerSingleton.Instance.FailedModules.ToList();
			var nonStartupModules = ModuleManagerSingleton.Instance.NonStartupModules.ToList();
			var failedOrDisabledModuleNames = failedModules.Union(nonStartupModules);

			var dependents = (from module in knownModules
			                 from name in module.DependsOn
			                 where failedOrDisabledModuleNames.Contains(name)
			                 select module.ModuleName).ToList();

			foreach (string dependent in dependents)
			{
				ModuleManagerSingleton.Instance.AddNonStartupModuleName(dependent);
			}
			
			var nonStartupWithDependencies = dependents.Union(failedOrDisabledModuleNames);
			var startupModules = (from moduleInfo in knownModules
								 where moduleInfo.InitializationMode == InitializationMode.WhenAvailable
									&& !nonStartupWithDependencies.Contains(moduleInfo.ModuleName)
								 select moduleInfo).ToList();

			var onDemandModules = (from moduleInfo in knownModules
								  where moduleInfo.InitializationMode == InitializationMode.OnDemand
									&& !nonStartupWithDependencies.Contains(moduleInfo.ModuleName)
								  select moduleInfo).ToList();

			/* Select those modules that are on demand, yet have startup modules that depend on them. */
			var onDemandModulesWithStartupDependents = (from onDemandModule in onDemandModules
			                                           from startupModule in startupModules
			                                           where startupModule.DependsOn.Contains(onDemandModule.ModuleName)
			                                           select onDemandModule).Distinct();

			/* Change the initialization mode for the modules to WhenAvailable 
			 * so that they are loaded normally. */
			foreach (ModuleInfo info in onDemandModulesWithStartupDependents)
			{
				info.InitializationMode = InitializationMode.WhenAvailable;
			}

			var range = startupModules.Union(onDemandModules);

			Items.AddRange(range.ToArray());

			/* Log load time. */
			DateTime endTime = DateTime.Now;
			TimeSpan loadTime = endTime - startTime;
			Log.Debug(string.Format("CustomModuleCatalog load time: {0}", loadTime));
		}

		/// <summary>
		/// Creates a new child domain and copies the evidence from a parent domain.
		/// </summary>
		/// <param name="parentDomain">The parent domain.</param>
		/// <returns>The new child domain.</returns>
		/// <remarks>
		/// Grabs the <paramref name="parentDomain"/> evidence and uses it to construct the new
		/// <see cref="AppDomain"/> because in a ClickOnce execution environment, creating an
		/// <see cref="AppDomain"/> will by default pick up the partial trust environment of 
		/// the AppLaunch.exe, which was the root executable. The AppLaunch.exe does a 
		/// create domain and applies the evidence from the ClickOnce manifests to 
		/// create the domain that the application is actually executing in. This will 
		/// need to be Full Trust for Composite Application Library applications.
		/// </remarks>
		protected virtual AppDomain BuildChildDomain(AppDomain parentDomain)
		{
			Evidence evidence = new Evidence(parentDomain.Evidence);
			AppDomainSetup setup = parentDomain.SetupInformation;
			return AppDomain.CreateDomain("DiscoveryRegion", evidence, setup);
		}

		class InnerModuleInfoLoader : MarshalByRefObject
		{
			[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic")]
			internal ModuleInfo[] GetModuleInfos(string path)
			{
				DirectoryInfo directory = new DirectoryInfo(path);

				ResolveEventHandler resolveEventHandler 
					= delegate(object sender, ResolveEventArgs args) { return OnReflectionOnlyResolve(args, directory); };

				AppDomain.CurrentDomain.ReflectionOnlyAssemblyResolve += resolveEventHandler;

				Assembly moduleReflectionOnlyAssembly = AppDomain.CurrentDomain.ReflectionOnlyGetAssemblies().First(
						asm => asm.FullName == typeof(IModule).Assembly.FullName);
				Type IModuleType = moduleReflectionOnlyAssembly.GetType(typeof(IModule).FullName);

				IEnumerable<ModuleInfo> modules = GetAssemblyModuleInfos(directory, IModuleType);

				var array = modules.ToArray();
				AppDomain.CurrentDomain.ReflectionOnlyAssemblyResolve -= resolveEventHandler;
				return array;
			}

			IEnumerable<ModuleInfo> GetAssemblyModuleInfos(DirectoryInfo directory, Type IModuleType)
			{
				var result = directory.GetFiles("*.dll")
					.Where(file => new AssemblyFile(file.Name).Managed)
					.SelectMany(file => Assembly.ReflectionOnlyLoadFrom(file.FullName)
											.GetExportedTypes()
											.Where(IModuleType.IsAssignableFrom)
											.Where(t => t != IModuleType)
											.Where(t => !t.IsAbstract)
											.Select(type => CreateModuleInfo(type)));
				return result;
			}

			Assembly OnReflectionOnlyResolve(ResolveEventArgs args, DirectoryInfo directory)
			{
				Assembly loadedAssembly = AppDomain.CurrentDomain.ReflectionOnlyGetAssemblies().FirstOrDefault(
					asm => string.Equals(asm.FullName, args.Name, StringComparison.OrdinalIgnoreCase));
				if (loadedAssembly != null)
				{
					return loadedAssembly;
				}
				AssemblyName assemblyName = new AssemblyName(args.Name);
				string dependentAssemblyFilename = Path.Combine(directory.FullName, assemblyName.Name + ".dll");
				if (File.Exists(dependentAssemblyFilename))
				{
					return Assembly.ReflectionOnlyLoadFrom(dependentAssemblyFilename);
				}
				return Assembly.ReflectionOnlyLoad(args.Name);
			}

			[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic")]
			internal void LoadAssemblies(IEnumerable<string> assemblies)
			{
				foreach (string assemblyPath in assemblies)
				{
					try
					{
						Assembly.ReflectionOnlyLoadFrom(assemblyPath);
					}
					catch (FileNotFoundException)
					{
						/* Continue loading assemblies even if an assembly 
						 * can not be loaded in the new AppDomain. */
					}
				}
			}

			static ModuleInfo CreateModuleInfo(Type type)
			{
				string moduleName = type.Name;
				List<string> dependsOn = new List<string>();
				bool onDemand = false;
				var moduleAttribute = CustomAttributeData.GetCustomAttributes(type).FirstOrDefault(
						cad => cad.Constructor.DeclaringType.FullName == typeof(ModuleAttribute).FullName);

				if (moduleAttribute != null)
				{
					foreach (CustomAttributeNamedArgument argument in moduleAttribute.NamedArguments)
					{
						string argumentName = argument.MemberInfo.Name;
						switch (argumentName)
						{
							case "ModuleName":
								moduleName = (string)argument.TypedValue.Value;
								break;

							case "OnDemand":
								onDemand = (bool)argument.TypedValue.Value;
								break;

							case "StartupLoaded":
								onDemand = !((bool)argument.TypedValue.Value);
								break;
						}
					}
				}

				var moduleDependencyAttributes 
					= CustomAttributeData.GetCustomAttributes(type).Where(
						cad => cad.Constructor.DeclaringType.FullName == typeof(ModuleDependencyAttribute).FullName);

				foreach (CustomAttributeData cad in moduleDependencyAttributes)
				{
					dependsOn.Add((string)cad.ConstructorArguments[0].Value);
				}

				ModuleInfo moduleInfo = new ModuleInfo(moduleName, type.AssemblyQualifiedName)
				{
					InitializationMode =
						onDemand
							? InitializationMode.OnDemand
							: InitializationMode.WhenAvailable,
					Ref = type.Assembly.CodeBase,
				};
				moduleInfo.DependsOn.AddRange(dependsOn);
				return moduleInfo;
			}
		}
	}
}