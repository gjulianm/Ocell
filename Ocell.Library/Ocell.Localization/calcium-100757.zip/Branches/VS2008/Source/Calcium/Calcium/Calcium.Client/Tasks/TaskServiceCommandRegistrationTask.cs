#region File and License Information
/*
<File>
	<Copyright>Copyright � 2010, Daniel Vaughan. All rights reserved.</Copyright>
	<License>
		Redistribution and use in source and binary forms, with or without
		modification, are permitted provided that the following conditions are met:
			* Redistributions of source code must retain the above copyright
			  notice, this list of conditions and the following disclaimer.
			* Redistributions in binary form must reproduce the above copyright
			  notice, this list of conditions and the following disclaimer in the
			  documentation and/or other materials provided with the distribution.
			* Neither the name of the <organization> nor the
			  names of its contributors may be used to endorse or promote products
			  derived from this software without specific prior written permission.

		THIS SOFTWARE IS PROVIDED BY <copyright holder> ''AS IS'' AND ANY
		EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
		WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
		DISCLAIMED. IN NO EVENT SHALL <copyright holder> BE LIABLE FOR ANY
		DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
		(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
		LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
		ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
		(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
		SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
	</License>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2010-02-06 16:05:52Z</CreationDate>
</File>
*/
#endregion

using System.Windows.Input;

using DanielVaughan.Calcium.Gui;
using DanielVaughan.Calcium.Services;
using DanielVaughan.Services;
using DanielVaughan.TaskModel;

namespace DanielVaughan.Calcium.Tasks
{
	class TaskServiceCommandRegistrationTask : TaskBase<ICommandService>
	{
		public TaskServiceCommandRegistrationTask()
		{
			Execute += OnExecute;
		}

		void OnExecute(object sender, TaskEventArgs<ICommandService> e)
		{
			ArgumentValidator.AssertNotNull(e, "e");
			var commandService = e.Argument;

			#region Undo with Context
			commandService.AddCommandBinding(ApplicationCommands.Undo,
				delegate
				{
					var activeView = GetActiveView();
					if (activeView == null)
					{
						return false;
					}
					var taskService = ServiceLocatorSingleton.Instance.GetInstance<ITaskService>();
					var id = activeView.ViewModel != null ? (object)activeView.ViewModel.Id : activeView;
					var taskResult = taskService.Undo(id);
					return true; /* We do not allow the event to bubble. */
				},
				delegate
				{
					var activeView = GetActiveView();
					if (activeView == null)
					{
						return false;
					}
					var taskService = ServiceLocatorSingleton.Instance.GetInstance<ITaskService>();
					var id = activeView.ViewModel != null ? (object)activeView.ViewModel.Id : activeView;
					var result = taskService.CanUndo(id);
					return result;
				}, 
				new KeyGesture(Key.Z, ModifierKeys.Control));
			#endregion

			#region Redo with Context
			commandService.AddCommandBinding(ApplicationCommands.Redo,
				delegate
				{
					var activeView = GetActiveView();
					if (activeView == null)
					{
						return false;
					}
					var taskService = ServiceLocatorSingleton.Instance.GetInstance<ITaskService>();
					var id = activeView.ViewModel != null ? (object)activeView.ViewModel.Id : activeView;
					var taskResult = taskService.Redo(id);
					return true; /* We do not allow the event to bubble. */
				},
				delegate
				{
					var activeView = GetActiveView();
					if (activeView == null)
					{
						return false;
					}
					var taskService = ServiceLocatorSingleton.Instance.GetInstance<ITaskService>();
					var id = activeView.ViewModel != null ? (object)activeView.ViewModel.Id : activeView;
					return taskService.CanRedo(id);
				}, 
				new KeyGesture(Key.Y, ModifierKeys.Control));
			#endregion
		}

		IView GetActiveView()
		{
			var viewService = ServiceLocatorSingleton.Instance.GetInstance<IViewService>();
			var activeView = viewService.ActiveView;
			return activeView;
		}

		public override string DescriptionForUser
		{
			get
			{
				/* TODO: Make localizable resource. */
				return "Register default Task Service commands";
			}
		}
	}
}
