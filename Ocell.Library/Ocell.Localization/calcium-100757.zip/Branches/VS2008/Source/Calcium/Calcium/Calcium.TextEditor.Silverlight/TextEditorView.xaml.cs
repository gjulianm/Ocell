﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace DanielVaughan.Calcium.TextEditor
{
	public partial class TextEditorView : ITextEditorView
	{
		public TextEditorView()
		{
			DataContext = ViewModel = new TextEditorViewModel();
			InitializeComponent();
		}

		public TextEditorViewModel TextEditorViewModel
		{
			get
			{
				return (TextEditorViewModel)DataContext;
			}
		}

		void TextBox_TextChanged(object sender, TextChangedEventArgs e)
		{
			TextEditorViewModel.Dirty = true;
		}

		#region Implementation of ITextEditorView

		public string TextEditorContent
		{
			get
			{
				return TextBox.Text;
			}
			set
			{
				Dispatcher.InvokeIfRequired(() => TextBox.Text = value);
			}
		}

		#endregion
	}
}
