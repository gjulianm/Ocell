﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Navigation;

using DanielVaughan.Calcium.Gui.Windows;
using DanielVaughan.Calcium.Services;
using DanielVaughan.Gui;
using DanielVaughan.Input;

using Microsoft.Practices.Composite.Modularity;

namespace DanielVaughan.Calcium.Gui
{
	public partial class SLShellView : IShellView, IMainWindow, ICommandService
	{
		public SLShellView()
		{
			InitializeComponent();
			Loaded += OnLoaded;

			DataContext = new ShellViewModel(this);
		}

		bool loaded;

		void OnLoaded(object sender, RoutedEventArgs e)
		{
			if (loaded)
			{
				return;
			}
			loaded = true;

			if (ViewLoaded != null)
			{
				ViewLoaded(this, e);
			}

			UpdateRegionExpansion();
//			UpdateGridSplitterLeftState();
//			UpdateGridSplitterRightState();
//			UpdateGridSplitterBottomState();

//			var moduleManager = ServiceLocatorSingleton.Instance.GetInstance<IModuleManager>();
//			moduleManager.LoadModule("Text Editor");
		}

		// Executes when the user navigates to this page.
		protected override void OnNavigatedTo(NavigationEventArgs e)
		{
		}

		void workspaceTabCorntrol_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{

		}

		private void gridSplitter_Left_CollapseButtonClickEvent(object sender)
		{
			if (columnDefinition_Left.Width.Value == 0)
			{
				OpenLeft.Begin();
			}
			else if (sender != this)
			{
				animCloseCol.From = columnDefinition_Left.Width.Value;
				CloseLeft.Begin();
			}
		}

		#region Implementation of ICommandService

		public void AddCommandBindingForContentType<TContent>(ICommand command, Func<TContent, bool> executeHandler, Func<TContent, bool> canExecuteHandler) where TContent : class
		{
			
		}

		public void AddCommandBindingForContentType<TContent>(ICommand command, Func<TContent, object, bool> executeHandler, Func<TContent, object, bool> canExecuteHandler) where TContent : class
		{

		}

		public void AddCommandBindingForContentType<TContent>(ICommand command, Func<TContent, bool> executeHandler, Func<TContent, bool> canExecuteHandler, KeyGesture keyGesture) where TContent : class
		{

		}

		public void AddCommandBinding(ICommand command, Func<bool> executeHandler, Func<bool> canExecuteHandler)
		{
//			CommandBindings.Add(new CommandBinding(command,
//				(sender, e) =>
//				{
//					e.Handled = executeHandler();
//				},
//				(sender, e) =>
//				{
//					e.CanExecute = canExecuteHandler();
//				}));
		}

		public void AddCommandBinding(ICommand command, Func<bool> executeHandler, Func<bool> canExecuteHandler, KeyGesture keyGesture)
		{

		}

		public void RegisterKeyGester(KeyGesture keyGesture, ICommand command)
		{

		}

		public void RemoveCommandBinding(ICommand command)
		{

		}

		#endregion

		void page_Root_SizeChanged(object sender, SizeChangedEventArgs e)
		{
			//RibbonCtrl.Width = e.NewSize.Width;
		}

		#region Implementation of IView

		public IViewModel ViewModel
		{
			get
			{
				return (IViewModel)DataContext;
			}
		}

		public event EventHandler<EventArgs> ViewLoaded;

		public bool Close(bool force)
		{
			throw new NotImplementedException();
		}

		#endregion

	}
}
