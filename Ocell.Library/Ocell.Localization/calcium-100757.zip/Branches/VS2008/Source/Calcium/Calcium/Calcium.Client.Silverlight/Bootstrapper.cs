﻿#region File and License Information
/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License>
		Redistribution and use in source and binary forms, with or without
		modification, are permitted provided that the following conditions are met:
			* Redistributions of source code must retain the above copyright
			  notice, this list of conditions and the following disclaimer.
			* Redistributions in binary form must reproduce the above copyright
			  notice, this list of conditions and the following disclaimer in the
			  documentation and/or other materials provided with the distribution.
			* Neither the name of the <organization> nor the
			  names of its contributors may be used to endorse or promote products
			  derived from this software without specific prior written permission.

		THIS SOFTWARE IS PROVIDED BY <copyright holder> ''AS IS'' AND ANY
		EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
		WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
		DISCLAIMED. IN NO EVENT SHALL <copyright holder> BE LIABLE FOR ANY
		DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
		(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
		LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
		ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
		(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
		SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
	</License>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2009-08-08 20:24:35Z</CreationDate>
</File>
*/
#endregion

using System;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;

using DanielVaughan.Calcium.Gui;
using DanielVaughan.Calcium.Modularity.RegionAdapters;
using DanielVaughan.Calcium.Services;
using DanielVaughan.Calcium.Services.ViewService;
using DanielVaughan.Gui;
using DanielVaughan.ServiceLocation.Unity;
using DanielVaughan.Services;
using DanielVaughan.Services.FileService;

using Microsoft.Practices.Composite.Modularity;
using Microsoft.Practices.Composite.Presentation.Regions;
using Microsoft.Practices.Composite.UnityExtensions;
using Microsoft.Practices.Unity;

namespace DanielVaughan.Calcium
{
	public class Bootstrapper : UnityBootstrapper, IBootstrapper
	{
		protected override DependencyObject CreateShell()
		{
			var commandService = Container.TryResolve<ICommandService>();
			var shell = Container.TryResolve<IShell>();
			if (shell == null)
			{
				var shellView = new SLShellView();
				shell = (IShell)shellView.ViewModel;
				Container.RegisterInstance<IShell>(shell);
				Container.RegisterInstance<IMainWindow>(shellView);

				if (commandService == null)
				{
					/* The shell implementation acts as the Command Service. */
					Container.RegisterInstance<ICommandService>((ICommandService)shellView);
				}
				App.Current.RootVisual = shellView;
				return shellView;
			}

			var mainWindow = Container.TryResolve<IMainWindow>();
			if (mainWindow == null)
			{
				mainWindow = shell as IMainWindow;
				if (mainWindow != null)
				{
					if (commandService == null)
					{
						/* The shell implementation acts as the Command Service. */
						Container.RegisterInstance<ICommandService>((ICommandService)shell);
					}
					/* Required by independent services. E.g. FileService. */
					Container.RegisterInstance<IMainWindow>(mainWindow);
					var result = (UIElement)mainWindow;
					App.Current.RootVisual = result;
					return result;
				}
			}
			throw new Exception("IMainWindow is not registered with the IOC container.");
		}

		protected override IUnityContainer CreateContainer()
		{
			IUnityContainer result;
			if (!ServiceLocatorSingleton.Instance.IsInitialized())
			{
				result = base.CreateContainer();
				/* In order to allow instance registration using the IServiceLocator implementation 
				 * we must allow the ServiceLocatorSingleton to set 
				 * the Unity implementation of the IServiceRegistrar. */
				ServiceLocatorSingleton.Instance.InitializeServiceLocator(result);
			}
			else
			{
				result = ServiceLocatorSingleton.Instance.GetInstance<IUnityContainer>();
			}

			return result;
		}

		protected override void ConfigureContainer()
		{
			base.ConfigureContainer();

			/* For resolving types with delegates. */
			//Container.AddNewExtension<StaticFactoryExtension>();

			/* By registering the UI thread dispatcher 
			 * we are able to invoke controls from anywhere. */
			RegisterInstanceIfMissing<Dispatcher>(Deployment.Current.Dispatcher);

			/* File Service */
			RegisterTypeIfMissing<IFileService, FileService>(true);

			/* IViewService will hide and show visual elements 
			 * depending on workspace content. */
			RegisterTypeIfMissing<IViewService, ViewService>(true);
		}

		void RegisterInstanceIfMissing<TFrom>(TFrom instance)
		{
			if (!Container.IsTypeRegistered(typeof(TFrom)))
			{
				Container.RegisterInstance<TFrom>(instance);
			}
		}

		void RegisterTypeIfMissing<TFrom, TTo>(bool registerAsSingleton) where TTo : TFrom
		{
			if (!Container.IsTypeRegistered(typeof(TFrom)))
			{
				if (registerAsSingleton)
				{
					Container.RegisterType(typeof(TFrom), typeof(TTo), new ContainerControlledLifetimeManager());
				}
				else
				{
					Container.RegisterType<TFrom, TTo>();
				}
			}
		}

		protected override IModuleCatalog GetModuleCatalog()
		{
			var catalog = Container.TryResolve<IModuleCatalog>();
			if (catalog != null)
			{
				return catalog;
			}

			string assemblyFullName = Assembly.GetExecutingAssembly().FullName;
			var assemblyName  = assemblyFullName.Substring(0, assemblyFullName.IndexOf(','));
			string url = string.Format("/{0};component/ModuleCatalog.xaml", assemblyName);
			var uri = new Uri(url, UriKind.Relative);
			catalog = ModuleCatalog.CreateFromXaml(uri);
			return catalog;
		}

		protected override RegionAdapterMappings ConfigureRegionAdapterMappings()
		{
			var mappings = base.ConfigureRegionAdapterMappings() ?? Container.Resolve<RegionAdapterMappings>();
//			mappings.RegisterMapping(typeof(Ribbon), Container.Resolve<RibbonRegionAdapter>());
//			mappings.RegisterMapping(typeof(RibbonTab), Container.Resolve<RibbonTabRegionAdapter>());
//			mappings.RegisterMapping(typeof(ToolBarTray), Container.Resolve<ToolBarTrayRegionAdapter>());
//			mappings.RegisterMapping(typeof(Menu), Container.Resolve<CustomItemsControlRegionAdapter>());
//			mappings.RegisterMapping(typeof(MenuItem), Container.Resolve<CustomItemsControlRegionAdapter>());
			mappings.RegisterMapping(typeof(StackPanel), Container.Resolve<StackPanelRegionAdapter>());
			
			return mappings;
		}

		
	}
}
