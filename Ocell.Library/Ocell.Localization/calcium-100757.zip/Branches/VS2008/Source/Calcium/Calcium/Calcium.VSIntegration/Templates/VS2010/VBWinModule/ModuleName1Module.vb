﻿Imports DanielVaughan
Imports DanielVaughan.Calcium
Imports DanielVaughan.Calcium.Services
Imports Microsoft.Practices.Composite.Modularity

<[Module](ModuleName:="$CustomModule$")> _
Public Class $CustomModule$Module
	Inherits ModuleBase

	Public Sub New()
		AddHandler MyBase.Initialized, New EventHandler(AddressOf Me.OnInitialized)
	End Sub

	Private Sub OnInitialized(ByVal sender As Object, ByVal e As EventArgs)
		Me.view = New $CustomModule$View
		Dim viewService As IViewService = ServiceLocatorSingleton.Instance.GetInstance(Of IViewService)()
		viewService.RegisterView("$CustomModule$", AddressOf ShowView2, Nothing, Nothing, Nothing)
		ShowView2(Nothing)
	End Sub

	Private Sub ShowView2(ByVal obj As Object)
		MyBase.ShowView(defaultRegion, Me.view, True)
	End Sub

	Private Const defaultRegion As String = "Tools"
	Private view As $CustomModule$View

End Class
