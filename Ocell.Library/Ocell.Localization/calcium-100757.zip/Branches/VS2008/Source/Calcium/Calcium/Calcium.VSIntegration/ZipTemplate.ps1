$projectDir = $args[0] 
#echo "Project directory: " + $projectDir;
Remove-Item $projectDir\DeploymentItems\VS2008Templates\*.zip -force
Remove-Item $projectDir\DeploymentItems\VS2010Templates\*.zip -force

get-childitem $projectDir\Templates -include *._ReSharper.* -recurse | foreach ($_) {remove-item $_.fullname}

$projectDirPath = $projectDir.ToString();
$zipLibraryPath = [System.IO.Path]::GetFullPath([System.IO.Path]::Combine($projectDir.ToString(), 
  "..\\..\\..\\..\\Libraries\\SharpZipLib\\ICSharpCode.SharpZipLib.dll"));

[Reflection.Assembly]::LoadFile($zipLibraryPath);
$zip = new-object ICSharpCode.SharpZipLib.Zip.FastZip;
$zip.CreateEmptyDirectories = $true;

$deploymentPath = $projectDirPath + "\DeploymentItems";
#echo $deploymentPath

# VS2008 C#
$zip.CreateZip($deploymentPath + "\\VS2008Templates\\VS2008CalciumCSWinModule.zip", $projectDirPath + "\\Templates\\VS2008\\CSWinModule\\", $true, "")
$zip.CreateZip($deploymentPath + "\\VS2008Templates\\VS2008CalciumCSWinLauncher.zip", $projectDirPath + "\\Templates\\VS2008\\CSWinLauncher\\", $true, "")
$zip.CreateZip($deploymentPath + "\\VS2008Templates\\VS2008CalciumCSWeb.zip", $projectDirPath + "\\Templates\\VS2008\\CSWeb\\", $true, "")
$zip.CreateZip($deploymentPath + "\\VS2008Templates\\VS2008CalciumCSWinView.zip", $projectDirPath + "\\Templates\\VS2008\\CSWinView\\", $true, "")
# VS2008 VB.NET
$zip.CreateZip($deploymentPath + "\\VS2008Templates\\VS2008CalciumVBWinModule.zip", $projectDirPath + "\\Templates\\VS2008\\VBWinModule\\", $true, "")
$zip.CreateZip($deploymentPath + "\\VS2008Templates\\VS2008CalciumVBWinLauncher.zip", $projectDirPath + "\\Templates\\VS2008\\VBWinLauncher\\", $true, "")
$zip.CreateZip($deploymentPath + "\\VS2008Templates\\VS2008CalciumVBWeb.zip", $projectDirPath + "\\Templates\\VS2008\\VBWeb\\", $true, "")
# VS2010 C#
$zip.CreateZip($deploymentPath + "\\VS2010Templates\\VS2010CalciumCSWinModule.zip", $projectDirPath + "\\Templates\\VS2010\\CSWinModule\\", $true, "")
$zip.CreateZip($deploymentPath + "\\VS2010Templates\\VS2010CalciumCSWinLauncher.zip", $projectDirPath + "\\Templates\\VS2010\\CSWinLauncher\\", $true, "")
$zip.CreateZip($deploymentPath + "\\VS2010Templates\\VS2010CalciumCSWeb.zip", $projectDirPath + "\\Templates\\VS2010\\CSWeb\\", $true, "")
$zip.CreateZip($deploymentPath + "\\VS2010Templates\\VS2010CalciumCSWinView.zip", $projectDirPath + "\\Templates\\VS2010\\CSWinView\\", $true, "")
# VS2010 VB.NET
$zip.CreateZip($deploymentPath + "\\VS2010Templates\\VS2010CalciumVBWinModule.zip", $projectDirPath + "\\Templates\\VS2010\\VBWinModule\\", $true, "")
$zip.CreateZip($deploymentPath + "\\VS2010Templates\\VS2010CalciumVBWinLauncher.zip", $projectDirPath + "\\Templates\\VS2010\\VBWinLauncher\\", $true, "")
$zip.CreateZip($deploymentPath + "\\VS2010Templates\\VS2010CalciumVBWeb.zip", $projectDirPath + "\\Templates\\VS2010\\VBWeb\\", $true, "")

