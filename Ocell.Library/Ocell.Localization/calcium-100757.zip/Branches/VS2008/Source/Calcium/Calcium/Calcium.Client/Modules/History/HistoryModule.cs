﻿using System;

using DanielVaughan.Calcium.Services;

using Microsoft.Practices.Composite.Modularity;

namespace DanielVaughan.Calcium.Modules.History
{
	//[Module(ModuleName = "History")]
	public class HistoryModule //: ModuleBase
	{
		/* The location where the view will be placed. */
		const string defaultRegion = RegionNames.Properties;
		/* The default view for this module. */
		HistoryView view;

		public HistoryModule()
		{
			//Initialized += OnInitialized;
		}

		void OnInitialized(object sender, EventArgs e)
		{
			view = new HistoryView();
			/* The view is registered with the view service so that it appears in the 'view' menu. */
			var viewService = ServiceLocatorSingleton.Instance.GetInstance<IViewService>();
			//viewService.RegisterView("History", obj => ShowView(defaultRegion, view, true), null, null, null);

			/* Populate the defaultRegion with the view. */
			//ShowView(defaultRegion, view, false);
		}
	}
}
