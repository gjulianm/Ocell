﻿#region File and License Information
/*
<File>
	<Copyright>Copyright © 2010, Daniel Vaughan. All rights reserved.</Copyright>
	<License>
		Redistribution and use in source and binary forms, with or without
		modification, are permitted provided that the following conditions are met:
			* Redistributions of source code must retain the above copyright
			  notice, this list of conditions and the following disclaimer.
			* Redistributions in binary form must reproduce the above copyright
			  notice, this list of conditions and the following disclaimer in the
			  documentation and/or other materials provided with the distribution.
			* Neither the name of the <organization> nor the
			  names of its contributors may be used to endorse or promote products
			  derived from this software without specific prior written permission.

		THIS SOFTWARE IS PROVIDED BY <copyright holder> ''AS IS'' AND ANY
		EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
		WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
		DISCLAIMED. IN NO EVENT SHALL <copyright holder> BE LIABLE FOR ANY
		DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
		(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
		LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
		ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
		(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
		SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
	</License>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2010-02-07 16:45:16Z</CreationDate>
</File>
*/
#endregion

using System;
using System.ComponentModel;
using System.Runtime.Serialization;
using System.Windows.Input;

using DanielVaughan.ComponentModel;

using Microsoft.Practices.Composite.Presentation.Commands;

namespace DanielVaughan.Calcium.CommandModel
{
	/* TODO: [DV] Comment. */
	public class CompositeUICommand : CompositeCommand, INotifyPropertyChanged
	{
		public CompositeUICommand(string text, bool monitorCommandActivity) : this(monitorCommandActivity)
		{
			this.text = text;
		}

		public CompositeUICommand(string text) : this()
		{
			this.text = text;
		}

		public CompositeUICommand()
		{
			Initialize();
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="CompositeUICommand"/> class.
		/// </summary>
		/// <param name="monitorCommandActivity">Indicates when the command activity 
		/// is going to be monitored.</param>
		public CompositeUICommand(bool monitorCommandActivity) : base(monitorCommandActivity)
		{
			Initialize();
		}

		[OnDeserializing]
		internal void OnDeserializing(StreamingContext context)
		{
			Initialize();
		}

		/// <summary>
		/// When deserialization occurs fields are not instantiated,
		/// therefore we must instanciate the notifier.
		/// </summary>
		void Initialize()
		{
			notifier = new PropertyChangeNotifier(this);
			CommandManager.RequerySuggested += CommandManager_RequerySuggested;
		}

		void CommandManager_RequerySuggested(object sender, EventArgs e)
		{
			OnCanExecuteChanged();
		}

		#region Property Change Notification
		[field: NonSerialized]
		PropertyChangeNotifier notifier;

		protected PropertyChangeNotifier Notifier
		{
			get
			{
				return notifier;
			}
		}

		public event PropertyChangedEventHandler PropertyChanged
		{
			add
			{
				notifier.PropertyChanged += value;
			}
			remove
			{
				notifier.PropertyChanged -= value;
			}
		}

		protected AssignmentResult Assign<TProperty>(
			string propertyName, ref TProperty property, TProperty newValue)
		{
			return notifier.Assign(propertyName, ref property, newValue);
		}

		#endregion

		string text;

		public string Text
		{
			get
			{
				return text;
			}
			set
			{
				notifier.Assign("Text", ref text, value);
			}
		}
	}
}
