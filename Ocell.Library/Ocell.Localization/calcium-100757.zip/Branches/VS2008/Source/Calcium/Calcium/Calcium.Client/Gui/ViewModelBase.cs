#region File and License Information
/*
<File>
	<Copyright>Copyright � 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License>
		Redistribution and use in source and binary forms, with or without
		modification, are permitted provided that the following conditions are met:
			* Redistributions of source code must retain the above copyright
			  notice, this list of conditions and the following disclaimer.
			* Redistributions in binary form must reproduce the above copyright
			  notice, this list of conditions and the following disclaimer in the
			  documentation and/or other materials provided with the distribution.
			* Neither the name of the <organization> nor the
			  names of its contributors may be used to endorse or promote products
			  derived from this software without specific prior written permission.

		THIS SOFTWARE IS PROVIDED BY <copyright holder> ''AS IS'' AND ANY
		EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
		WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
		DISCLAIMED. IN NO EVENT SHALL <copyright holder> BE LIABLE FOR ANY
		DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
		(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
		LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
		ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
		(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
		SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
	</License>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2009-05-17 19:05:04Z</CreationDate>
</File>
*/
#endregion

using System;
using System.ComponentModel;
using System.Runtime.Serialization;

using DanielVaughan.ComponentModel;

using Microsoft.Practices.Composite;

namespace DanielVaughan.Calcium.Gui
{
	/// <summary>
	/// A base implementation of the <see cref="IViewModel"/> interface.
	/// </summary>
	public abstract class ViewModelBase : NotifyPropertyChangeBase, IViewModel, INotifyPropertyChanged, IViewAware
	{
		IActiveAware activeAwareInstance;

		protected ViewModelBase()
		{
			Initialize();
		}

#if !SILVERLIGHT
		[OnDeserializing]
		internal void OnDeserializing(StreamingContext context)
		{
			Initialize();
		}
#endif
		/// <summary>
		/// When deserialization occurs fields are not instantiated,
		/// therefore we must instanciate the notifier.
		/// </summary>
		void Initialize()
		{
		}

		readonly Guid id = Guid.NewGuid();
		public Guid Id
		{
			get
			{
				return id;
			}
		}

		#region Title Property

		object title;

		[Description("The text to display on a tab.")]
#if !SILVERLIGHT
		[Browsable(true)]
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
#endif		
		public object Title
		{
			get
			{
				return title;
			}
			set
			{
				Assign("Title", ref title, value);
			}
		}

		#endregion

		#region Active Aware

		void IViewAware.Attach(IActiveAware activeAware)
		{
			ReplaceActiveAware(activeAware);
		}

		void IViewAware.DetachActiveAware()
		{
			ReplaceActiveAware(null);
		}

		void ReplaceActiveAware(IActiveAware activeAwareInstance)
		{
			if (this.activeAwareInstance != null)
			{
				this.activeAwareInstance.IsActiveChanged -= OnIsActiveChanged;
			}
			this.activeAwareInstance = activeAwareInstance;
			if (activeAwareInstance != null)
			{
				activeAwareInstance.IsActiveChanged += OnIsActiveChanged;
			}
		}

		bool lastActiveState;

		void OnIsActiveChanged(object sender, EventArgs e)
		{
			Notifier.NotifyChanged("Active", lastActiveState, Active);
			lastActiveState = Active;
			OnActiveChanged(e);
		}

		#region event ActiveChanged

		event EventHandler activeChanged;

		protected event EventHandler ActiveChanged
		{
			add
			{
				activeChanged += value;
			}
			remove
			{
				activeChanged -= value;
			}
		}

		protected void OnActiveChanged(EventArgs e)
		{
			if (activeChanged != null)
			{
				activeChanged(this, e);
			}
		}

		#endregion

		/// <summary>
		/// Gets a value indicating whether this instance is being notified 
		/// of when it becomes active or inactive, 
		/// this may occur for example when its view gains focus or loses focus.
		/// </summary>
		/// <value><c>true</c> if monitoring the active state 
		/// of its view; otherwise, <c>false</c>.</value>
		public bool ActiveAware
		{
			get
			{
				return activeAwareInstance != null;
			}
		}

		/// <summary>
		/// Gets a value indicating whether this <see cref="ViewModelBase"/> 
		/// is active within the user interface.
		/// </summary>
		/// <value><c>true</c> if active; otherwise, <c>false</c>.</value>
		public bool Active
		{
			get
			{
				return activeAwareInstance != null ? activeAwareInstance.IsActive : false;
			}
		}

		#endregion

		#region Dimensions
		double width = 300;

		public double Width
		{
			get
			{
				return width;
			}
			set
			{
				Assign("Width", ref width, value);
			}
		}

		double height = 300;

		public double Height
		{
			get
			{
				return height;
			}
			set
			{
				Assign("Height", ref height, value);
			}
		}
		#endregion

		internal static T FindType<T>(object view) where T : class
		{
			var result = view as T;
			if (result != null)
			{
				return result;
			}
			var temp = view as IView;
			if (temp != null)
			{
				return temp.ViewModel as T;
			}
			return null;
		}

		public override string ToString()
		{
			return title != null ? title.ToString() : base.ToString();
		}
	}
}
