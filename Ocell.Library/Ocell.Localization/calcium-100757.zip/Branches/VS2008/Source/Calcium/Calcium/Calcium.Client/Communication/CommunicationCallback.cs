#region File and License Information
/*
<File>
	<Copyright>Copyright � 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License>
		Redistribution and use in source and binary forms, with or without
		modification, are permitted provided that the following conditions are met:
			* Redistributions of source code must retain the above copyright
			  notice, this list of conditions and the following disclaimer.
			* Redistributions in binary form must reproduce the above copyright
			  notice, this list of conditions and the following disclaimer in the
			  documentation and/or other materials provided with the distribution.
			* Neither the name of the <organization> nor the
			  names of its contributors may be used to endorse or promote products
			  derived from this software without specific prior written permission.

		THIS SOFTWARE IS PROVIDED BY <copyright holder> ''AS IS'' AND ANY
		EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
		WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
		DISCLAIMED. IN NO EVENT SHALL <copyright holder> BE LIABLE FOR ANY
		DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
		(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
		LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
		ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
		(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
		SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
	</License>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2009-05-17 18:57:26Z</CreationDate>
</File>
*/
#endregion

using System;
using System.Collections.Generic;

using DanielVaughan.Calcium.ClientServices;
using DanielVaughan.Services;

using Microsoft.Practices.Composite.Events;

namespace DanielVaughan.Calcium.Communication
{
	public class CommunicationCallback : ICommunicationCallback
	{
		#region IMessageService related
		static IMessageService MessageService
		{
			get
			{
				var messageService = ServiceLocatorSingleton.Instance.GetInstance<IMessageService>();
				return messageService;
			}
		}

		public void OnConnectedUserJoined(ConnectedUser connectedUser)
		{
			if (connectedUser == null)
			{
				Log.Warn("Unable to notify on user joined. Suppressing");
				return;
			}

			var eventAggregator = ServiceLocatorSingleton.Instance.GetInstance<IEventAggregator>();
			var changedEvent = eventAggregator.GetEvent<UserJoinedEvent>();
			changedEvent.Publish(connectedUser);
		}

		public void OnConnectedUserDeparted(ConnectedUser connectedUser)
		{
			if (connectedUser == null)
			{
				Log.Warn("Unable to notify on user departed. Suppressing");
				return;
			}

			var eventAggregator = ServiceLocatorSingleton.Instance.GetInstance<IEventAggregator>();
			var changedEvent = eventAggregator.GetEvent<UserDepartedEvent>();
			changedEvent.Publish(connectedUser);
		}

		public void OnConnectedUsersUpdate(IEnumerable<ConnectedUser> connectedUsers)
		{
			if (connectedUsers == null)
			{
				Log.Warn("Unable to notify on users update. Suppressing");
				return;
			}

			var eventAggregator = ServiceLocatorSingleton.Instance.GetInstance<IEventAggregator>();
			var changedEvent = eventAggregator.GetEvent<UsersUpdateEvent>();
			changedEvent.Publish(connectedUsers);
		}

		public void ShowMessage(string message, MessageImportance importanceThreshold)
		{
			MessageService.ShowMessage(message, importanceThreshold);
		}

		public void ShowMessage(string message, string caption, MessageImportance importanceThreshold)
		{
			MessageService.ShowMessage(message, caption, importanceThreshold);
		}

		public void ShowWarning(string message)
		{
			MessageService.ShowWarning(message);
		}

		public void ShowWarning(string message, string caption)
		{
			MessageService.ShowWarning(message, caption);
		}

		public void ShowError(string message)
		{
			MessageService.ShowError(message);
		}

		public void ShowError(string message, string caption)
		{
			MessageService.ShowError(message, caption);
		}

		public bool AskYesNoQuestion(string question)
		{
			return MessageService.AskYesNoQuestion(question);
		}

		public bool AskYesNoQuestion(string question, string caption)
		{
			return MessageService.AskYesNoQuestion(question, caption);
		}

		public YesNoCancelQuestionResult AskYesNoCancelQuestion(string question)
		{
			return MessageService.AskYesNoCancelQuestion(question);
		}

		public YesNoCancelQuestionResult AskYesNoCancelQuestion(string question, string caption)
		{
			return MessageService.AskYesNoCancelQuestion(question, caption);
		}

		public bool AskOkCancelQuestion(string question)
		{
			return MessageService.AskOkCancelQuestion(question);
		}

		public bool AskOkCancelQuestion(string question, string caption)
		{
			return MessageService.AskOkCancelQuestion(question, caption);
		}
		#endregion
	}
}
