﻿#region File and License Information
/*
<File>
	<Copyright>Copyright © 2010, Daniel Vaughan. All rights reserved.</Copyright>
	<License>
		Redistribution and use in source and binary forms, with or without
		modification, are permitted provided that the following conditions are met:
			* Redistributions of source code must retain the above copyright
			  notice, this list of conditions and the following disclaimer.
			* Redistributions in binary form must reproduce the above copyright
			  notice, this list of conditions and the following disclaimer in the
			  documentation and/or other materials provided with the distribution.
			* Neither the name of the <organization> nor the
			  names of its contributors may be used to endorse or promote products
			  derived from this software without specific prior written permission.

		THIS SOFTWARE IS PROVIDED BY <copyright holder> ''AS IS'' AND ANY
		EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
		WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
		DISCLAIMED. IN NO EVENT SHALL <copyright holder> BE LIABLE FOR ANY
		DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
		(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
		LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
		ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
		(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
		SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
	</License>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2010-03-06 17:31:10Z</CreationDate>
</File>
*/
#endregion

using System;
using System.Collections.Generic;

namespace DanielVaughan.Calcium.Services
{
	/// <summary>
	/// Provides for registering application <see cref="LastAppliedTheme"/>s,
	/// which can be applied to change the look and feel of the application.
	/// </summary>
	public interface IThemeService
	{
		/// <summary>
		/// Registers the theme with the unique name.
		/// </summary>
		/// <param name="theme">The theme.</param>
		/// <exception cref="ArgumentNullException">Occurs if theme is null.</exception>
		/// <exception cref="ArgumentException">Occurs if a theme with the same name 
		/// has already been registered.</exception>
		void RegisterTheme(Theme theme);

		/// <summary>
		/// Removes the theme with the specified name 
		/// from the list of registered themes.
		/// </summary>
		/// <returns><c>true</c> if a theme with the specified id was located, 
		/// <c>false</c> otherwise.</returns>
		/// <param name="themeId">The theme id.</param>
		/// <exception cref="ArgumentNullException">
		/// Occurs if themeId is <c>null</c>.</exception>
		bool UnregisterTheme(string themeId);

		/// <summary>
		/// Applies the theme with the specified name.
		/// </summary>
		/// <param name="themeId">The theme id.</param>
		/// <exception cref="KeyNotFoundException">Occurs if a theme 
		/// with the specified id has not been registered.</exception>
		void ApplyTheme(string themeId);

		/// <summary>
		/// Gets the application themes that have been registered.
		/// </summary>
		/// <value>The registered themes.</value>
		IEnumerable<Theme> Themes { get; }

		/// <summary>
		/// Gets the last applied theme. 
		/// May be <c>null</c> if no theme has been applied.
		/// </summary>
		/// <value>The last applied theme.</value>
		Theme LastAppliedTheme { get; }

		/// <summary>
		/// Occurs when a theme has been registered.
		/// </summary>
		event EventHandler<ThemeServiceEventArgs> ThemeRegistered;

		/// <summary>
		/// Occurs when a theme was unregistered.
		/// </summary>
		event EventHandler<ThemeServiceEventArgs> ThemeUnregistered;

		/// <summary>
		/// Occurs when a theme was applied.
		/// </summary>
		event EventHandler<ThemeServiceEventArgs> ThemeApplied;
	}

	/// <summary>
	/// Used for various <see cref="IThemeService"/> args.
	/// </summary>
	public class ThemeServiceEventArgs : EventArgs
	{
		/// <summary>
		/// Gets or sets the theme relevant to the event.
		/// </summary>
		/// <value>The theme.</value>
		public Theme Theme { get; private set; }

		/// <summary>
		/// Initializes a new instance of the <see cref="ThemeServiceEventArgs"/> class.
		/// </summary>
		/// <param name="theme">The theme.</param>
		public ThemeServiceEventArgs(Theme theme)
		{
			Theme = theme;
		}
	}

}
