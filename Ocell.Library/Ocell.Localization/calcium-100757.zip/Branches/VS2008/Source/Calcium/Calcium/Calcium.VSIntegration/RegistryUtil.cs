﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Win32;

namespace DanielVaughan.Calcium.VSIntegration
{
	class RegistryUtil
	{
		public static string GetCalciumInstallDirectory(string vsVersion, string calciumVersion)
		{
			RegistryKey regKey = null;
			try
			{
				regKey = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Daniel Vaughan\Calcium SDK VS" + vsVersion + @"\" + calciumVersion + @"\Setup");

				string result = regKey.GetValue("InstallDir").ToString();
				return result;
			}
			finally
			{
				if (regKey != null)
				{
					regKey.Close();
				}
			}
		}
	}
}
