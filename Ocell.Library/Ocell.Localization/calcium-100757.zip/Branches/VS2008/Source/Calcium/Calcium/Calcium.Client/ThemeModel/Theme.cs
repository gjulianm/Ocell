#region File and License Information
/*
<File>
	<Copyright>Copyright � 2010, Daniel Vaughan. All rights reserved.</Copyright>
	<License>
		Redistribution and use in source and binary forms, with or without
		modification, are permitted provided that the following conditions are met:
			* Redistributions of source code must retain the above copyright
			  notice, this list of conditions and the following disclaimer.
			* Redistributions in binary form must reproduce the above copyright
			  notice, this list of conditions and the following disclaimer in the
			  documentation and/or other materials provided with the distribution.
			* Neither the name of the <organization> nor the
			  names of its contributors may be used to endorse or promote products
			  derived from this software without specific prior written permission.

		THIS SOFTWARE IS PROVIDED BY <copyright holder> ''AS IS'' AND ANY
		EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
		WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
		DISCLAIMED. IN NO EVENT SHALL <copyright holder> BE LIABLE FOR ANY
		DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
		(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
		LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
		ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
		(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
		SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
	</License>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2010-03-06 17:58:41Z</CreationDate>
</File>
*/
#endregion

using System;

namespace DanielVaughan.Calcium.Services
{
	/// <summary>
	/// Represents an application theme, which can be 
	/// loaded and unloaded at runtime.
	/// </summary>
	public class Theme
	{
		readonly Func<string> getDisplayNameFunc;

		/// <summary>
		/// Gets the name of the theme. This is unique.
		/// </summary>
		/// <value>The name of the theme.</value>
		public string DisplayName
		{
			get
			{
				return getDisplayNameFunc();
			}
		}

		readonly string id;

		/// <summary>
		/// Gets the id of the theme.
		/// </summary>
		/// <value>The id.</value>
		public string Id
		{
			get
			{
				return id;
			}
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="Theme"/> class.
		/// </summary>
		/// <param name="getDisplayNameFunc">The func to get the name of the theme.</param>
		/// <param name="loadThemeAction">The action to perform when to load 
		/// the theme into the application.</param>
		/// <param name="unloadThemeAction">The action to perform to unload 
		/// the theme from the application.</param>
		public Theme(string id, Func<string> getDisplayNameFunc, Action loadThemeAction, Action unloadThemeAction)
		{
			this.id = ArgumentValidator.AssertNotNull(id, "id");
			this.getDisplayNameFunc = ArgumentValidator.AssertNotNull(getDisplayNameFunc, "getNameFunc"); 
			this.loadThemeAction = ArgumentValidator.AssertNotNull(loadThemeAction, "loadThemeAction");;
			this.unloadThemeAction = ArgumentValidator.AssertNotNull(unloadThemeAction, "unloadThemeAction");;
		}  

		readonly Action loadThemeAction;

		/// <summary>
		/// Loads the theme into the application.
		/// This means applying loading all ResourceDictionaries etc.
		/// </summary>
		internal void ApplyTheme()
		{
			loadThemeAction();
		}

		readonly Action unloadThemeAction;

		/// <summary>
		/// Unloads the theme from the application.
		/// This means unloading all ResourceDictionaries etc.
		/// </summary>
		internal void UnloadTheme()
		{
			unloadThemeAction();
		}

		public override string ToString()
		{
			string name = DisplayName;
			return string.IsNullOrEmpty(name) ? base.ToString() : name;
		}
	}
}