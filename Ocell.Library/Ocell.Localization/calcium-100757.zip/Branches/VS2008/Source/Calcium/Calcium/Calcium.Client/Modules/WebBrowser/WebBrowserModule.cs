#region File and License Information
/*
<File>
	<Copyright>Copyright � 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License>
		Redistribution and use in source and binary forms, with or without
		modification, are permitted provided that the following conditions are met:
			* Redistributions of source code must retain the above copyright
			  notice, this list of conditions and the following disclaimer.
			* Redistributions in binary form must reproduce the above copyright
			  notice, this list of conditions and the following disclaimer in the
			  documentation and/or other materials provided with the distribution.
			* Neither the name of the <organization> nor the
			  names of its contributors may be used to endorse or promote products
			  derived from this software without specific prior written permission.

		THIS SOFTWARE IS PROVIDED BY <copyright holder> ''AS IS'' AND ANY
		EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
		WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
		DISCLAIMED. IN NO EVENT SHALL <copyright holder> BE LIABLE FOR ANY
		DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
		(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
		LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
		ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
		(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
		SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
	</License>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2009-05-17 19:12:17Z</CreationDate>
</File>
*/
#endregion

using System;
using System.Configuration;
using System.Windows;

using DanielVaughan.Calcium.Services;
using DanielVaughan.Gui.Adaptation;

using Microsoft.Practices.Composite.Modularity;

namespace DanielVaughan.Calcium.Modules.WebBrowser
{
	[Module(ModuleName = ModuleNames.WebBrowser)]
	public class WebBrowserModule : ModuleBase
	{
		IWebBrowserView view;
		const string defaultRegion = RegionNames.Workspace;

		public WebBrowserModule()
		{
			Initialized += OnInitialized;
		}

		void OnInitialized(object sender, EventArgs e)
		{
			if (!ServiceLocatorSingleton.Instance.TryGetInstance<IWebBrowserView>(out view))
			{
				view = new WebBrowserView();
				ServiceLocatorSingleton.Instance.RegisterInstance<IWebBrowserView>(view);
			}
			var viewService = ServiceLocatorSingleton.Instance.GetInstance<IViewService>();

			/* TODO: Make localizable resource. 
			 Don't use view.Name as it may change at runtime. */
			viewService.RegisterView("Web Browser", obj => ShowView(defaultRegion, view, true), null, null, null);

			ShowView(defaultRegion, view, false);
			string startUrl = ConfigurationManager.AppSettings["WebBrowserStartUrl"];
			if (startUrl == null)
			{
				startUrl = "http://wpfdisciples.wordpress.com/bios/";
			}

			var viewModel = (WebBrowserViewModel)view.ViewModel;
			viewModel.Url = startUrl;

			/* Add web browser toolbar. */
			var toolBarProvider = new WebBrowserToolBar(viewModel) { Url = startUrl };
			var toolBar = toolBarProvider.ToolBar;
			ShowView(RegionNames.StandardToolBarTray, toolBar, false);

			viewService.AssociateVisibility(typeof(IWebBrowserView),
				new UIElementAdapter(toolBar), Visibility.Collapsed);

			var commandService = ServiceLocatorSingleton.Instance.GetInstance<ICommandService>();

			/* When a WebBrowserViewModel is the ViewModel of the active item in the shell,
			 * the NavigateCommand becomes active. */
			commandService.AddCommandBindingForContentType<WebBrowserViewModel>(
				WebBrowserViewModel.NavigateCommand,
				(arg, commandParameter) => arg.Navigate(commandParameter),
				(arg, commandParameter) => arg.CanNavigate(commandParameter));
		}
	}
}
