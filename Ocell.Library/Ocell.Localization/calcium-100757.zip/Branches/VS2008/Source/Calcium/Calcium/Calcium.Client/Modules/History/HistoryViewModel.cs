﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;

using DanielVaughan;
using DanielVaughan.Calcium;
using DanielVaughan.Calcium.Gui;
using DanielVaughan.Calcium.TaskModel;
using DanielVaughan.Services;
using DanielVaughan.TaskModel;

using Microsoft.Practices.Composite.Events;
using Microsoft.Practices.Composite.Presentation.Commands;
using Microsoft.Practices.Composite.Presentation.Events;

namespace DanielVaughan.Calcium.Modules.History
{
	public class HistoryViewModel : ViewModelBase
	{
		public HistoryViewModel()
		{
			Title = "History";

			var task = new Task<string>(OnTask, "Move designer item");
			tasks.Add(new TaskDetails(task, false));
			var eventAggregator = ServiceLocatorSingleton.Instance.GetInstance<IEventAggregator>();
			var blah = eventAggregator.GetEvent<TaskExecutedEvent>();
			blah.Subscribe(OnTaskExecuted);
		}

		void OnTask(TaskEventArgs<string> e)
		{

		}

		void OnTaskExecuted(ITask task)
		{

		}

		readonly ObservableCollection<TaskDetails> tasks = new ObservableCollection<TaskDetails>();

		public ObservableCollection<TaskDetails> Tasks
		{
			get
			{
				return tasks;
			}
		}

		public void RollBackToTask(TaskDetails taskDetails)
		{
			var index = tasks.IndexOf(taskDetails);
			var taskService = ServiceLocatorSingleton.Instance.GetInstance<ITaskService>();
//			taskService.Undo()
		}
	}

	public class TaskDetails
	{
		public TaskDetails(ITask task, bool undone)
		{
			DescriptionForUser = task.DescriptionForUser;
			OccuredAt = DateTime.Now;
			if (!undone)
			{
				Repeatable = task.Repeatable;
				Undoable = task.Undoable;
			}
			else
			{
				Redoable = true;
			}
		}

		public string DescriptionForUser { get; set; }
		public DateTime OccuredAt { get; set; }
		public bool Repeatable { get; set; }
		public bool Undoable { get; set; }
		public bool Redoable { get; set; }
	}
}
