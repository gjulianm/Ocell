﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using DanielVaughan;
using DanielVaughan.Calcium;
using DanielVaughan.Calcium.Services;

using Microsoft.Practices.Composite.Modularity;

namespace $safeprojectname$
{
	[Module(ModuleName = "$CustomModule$")]
	public class $CustomModule$Module : ModuleBase
	{
		/* The location where the view will be placed. */
		const string defaultRegion = RegionNames.Tools;
		/* The default view for this module. */
		$CustomModule$View view;

		public $CustomModule$Module()
		{
			Initialized += OnInitialized;
		}

		void OnInitialized(object sender, EventArgs e)
		{
			view = new $CustomModule$View();
			/* The view is registered with the view service so that it appears in the 'view' menu. */
			var viewService = ServiceLocatorSingleton.Instance.GetInstance<IViewService>();
			viewService.RegisterView("$CustomModule$", obj => ShowView(defaultRegion, view, true), null, null, null);

			/* Populate the defaultRegion with the view. */
			ShowView(defaultRegion, view, false);
		}
	}
}
