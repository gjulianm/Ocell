﻿Imports Microsoft.Practices.Composite.Events
Imports Microsoft.Practices.Composite.Presentation.Commands
Imports Microsoft.Practices.Composite.Presentation.Events

Imports DanielVaughan
Imports DanielVaughan.Calcium
Imports DanielVaughan.Calcium.Client
Imports DanielVaughan.Calcium.Gui

Public Class $CustomModule$ViewModel
	Inherits ViewModelBase

	Public Sub New()
		MyBase.Title = "$CustomModule$"
	End Sub

End Class
