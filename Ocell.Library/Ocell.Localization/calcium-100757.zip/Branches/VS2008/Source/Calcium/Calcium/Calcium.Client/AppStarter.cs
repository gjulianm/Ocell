#region File and License Information
/*
<File>
	<Copyright>Copyright � 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License>
		Redistribution and use in source and binary forms, with or without
		modification, are permitted provided that the following conditions are met:
			* Redistributions of source code must retain the above copyright
			  notice, this list of conditions and the following disclaimer.
			* Redistributions in binary form must reproduce the above copyright
			  notice, this list of conditions and the following disclaimer in the
			  documentation and/or other materials provided with the distribution.
			* Neither the name of the <organization> nor the
			  names of its contributors may be used to endorse or promote products
			  derived from this software without specific prior written permission.

		THIS SOFTWARE IS PROVIDED BY <copyright holder> ''AS IS'' AND ANY
		EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
		WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
		DISCLAIMED. IN NO EVENT SHALL <copyright holder> BE LIABLE FOR ANY
		DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
		(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
		LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
		ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
		(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
		SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
	</License>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2009-05-17 19:13:48Z</CreationDate>
</File>
*/
#endregion

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using System.Windows;
using System.Windows.Threading;

using Calcium.Client.FileMetadata.Gui.Controls.Metadata;
using Calcium.Client.FileMetadata.Gui.Controls.SplashScreen.Metadata;
using Calcium.Client.FileMetadata.Gui.Controls.TitleBanner.Metadata;
using Calcium.Client.FileMetadata.Themes.Default.Metadata;

using DanielVaughan.Calcium.Gui;
using DanielVaughan.Calcium.Gui.Controls;
using DanielVaughan.Calcium.Gui.SplashScreen;
using DanielVaughan.Calcium.Modularity;
using DanielVaughan.Calcium.TaskModel;
using DanielVaughan.Calcium.Tasks;
using DanielVaughan.Gui;
using DanielVaughan.TaskModel;
using DanielVaughan.Windows;
using DanielVaughan.ServiceLocation.Unity;

namespace DanielVaughan.Calcium
{
	/// <summary>
	/// This class is used to launch the Calcium application.
	/// </summary>
	public class AppStarter
	{
		StartupOptions startupOptions;

		/// <summary>
		/// Gets or sets the startup options that are used for configuring 
		/// the e.g., the splash screen image.
		/// </summary>
		/// <value>The startup options.</value>
		public StartupOptions StartupOptions
		{
			get
			{
				if (startupOptions == null)
				{
					startupOptions = new StartupOptions();
				}
				return startupOptions;
			}
			set
			{
				startupOptions = value;
			}
		}

		public virtual void Start()
		{
			Application.Current.DispatcherUnhandledException += OnDispatcherUnhandledException;
			ISplashScreen splashScreen = null;
			try
			{
				var dictionaries = Application.Current.Resources.MergedDictionaries;

				if (!(ServiceLocatorSingleton.Instance.IsInitialized()
					&& ServiceLocatorSingleton.Instance.TryGetInstance<ISplashScreen>(out splashScreen)))
				{
					/* Add default splash screen style. */
					dictionaries.AddRelativeDictionary(SplashScreenStyleXaml.RelativePackUri);

					SplashWindow splashWindow = new SplashWindow(
						StartupOptions.SplashImagePackUri, StartupOptions.SplashBlurbVisible);

					splashScreen = splashWindow;
				}

				splashScreen.Show();
				ApplicationUtil.DoEvents();

				/* Load the resource dictionaries into the application. */
				dictionaries.AddRelativeDictionaries(new[]
				                                     	{
				                                     		WindowDictionaryXaml.RelativePackUri,
															ShellBannerStyleXaml.RelativePackUri,
															StandardMenuStyleXaml.RelativePackUri,
															StandardToolBarTrayStyleXaml.RelativePackUri
				                                     	});

				IBootstrapper bootstrapper;
				if (!(ServiceLocatorSingleton.Instance.IsInitialized()
						&& ServiceLocatorSingleton.Instance.TryGetInstance<IBootstrapper>(out bootstrapper)))
				{
					bootstrapper = new Bootstrapper
					               	{
					               		ModuleCatalogOptions = startupOptions.ModuleCatalogOptions
					               	};
					bootstrapper.Run();
				}

				/* The ServiceLocatorSingleton must be initialized before this call. 
				 * If not performed in user code, then the default Bootstrapper will initialize it. */
				var shell = ServiceLocatorSingleton.Instance.GetInstance<IMainWindow>();
				var window = shell as Window;
				if (window != null)
				{
					window.Show();
				}
			}
			catch (Exception ex)
			{
				HandleApplicationException(ex, false);
			}
			finally
			{
				if (splashScreen != null)
				{
					try
					{
						splashScreen.Close();
					}
					catch (Exception ex)
					{
						Debug.Fail("Problem closing splash screen. " + ex, ex.StackTrace);
						/* Suppress. */
					}
				}
			}
		}

		/// <summary>
		/// Called when an unhandled exception occurs on the main thread.
		/// </summary>
		/// <param name="sender">The sender.</param>
		/// <param name="e">The <see cref="System.Windows.Threading.DispatcherUnhandledExceptionEventArgs"/> 
		/// instance containing the event data.</param>
		static void OnDispatcherUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
		{
			e.Handled = true;
			HandleApplicationException(e.Exception, true);
		}

		static void HandleApplicationException(Exception exception, bool allowContinue)
		{
			try
			{
				Log.Error("Error processed by HandleApplicationException", exception);

//				var action = new HandleApplicationExceptionAction();
//				TaskServiceSingleton.Instance.PerformTask(action, new HandleExceptionArgument { AllowIgnore = allowContinue, Exception = exception });
			}
			catch (Exception ex)
			{
				Log.Error("Unable to perform action HandleApplicationExceptionAction", ex);
				/* Suppress. */
			}
		}

		//static void LoadResourceDictionary(string path, string assemblyFullName)
		//{
		//    string dictionaryName = string.Format("/{0};component/{1}", assemblyFullName, path);
		//    var uri = new Uri(dictionaryName, UriKind.Relative);
		//    var dictionary = (ResourceDictionary)Application.LoadComponent(uri);
		//    Application.Current.Resources.MergedDictionaries.Add(dictionary);
		//}

		//static void LoadResourceDictionary(string relativeUrl)
		//{
		//    var uri = new Uri(relativeUrl, UriKind.Relative);
		//    var dictionary = (ResourceDictionary)Application.LoadComponent(uri);
		//    Application.Current.Resources.MergedDictionaries.Add(dictionary);
		//}
	}

	public class StartupOptions
	{
		Uri splashImagePackUri;

		/// <summary>
		/// Gets or sets the splash image path.
		/// </summary>
		/// <value>The splash image path.</value>
		public Uri SplashImagePackUri
		{
			get
			{
				return splashImagePackUri;
			}
			set
			{
				ArgumentValidator.AssertNotNull(value, "value");
				splashImagePackUri = value;
			}
		}

		bool splashBlurbVisible = true;
		readonly ModuleCatalogOptions moduleCatalogOptions = new ModuleCatalogOptions();

		/// <summary>
		/// Gets or sets a value indicating whether the Fortified with Calcium text 
		/// is shown on the splash screen.
		/// </summary>
		/// <value>
		/// 	If <c>true</c> then the calcium text will be shown on the splash screen; 
		///		otherwise it will be hidden. Default is <c>true</c>.
		/// </value>
		public bool SplashBlurbVisible
		{
			get
			{
				return splashBlurbVisible;
			}
			set
			{
				splashBlurbVisible = value;
			}
		}

		/// <summary>
		/// Gets the module catalog parameters, which allows 
		/// a list of modules to be prevented from loading.
		/// </summary>
		/// <value>The module catalog parameters.</value>
		public ModuleCatalogOptions ModuleCatalogOptions
		{
			get
			{
				return moduleCatalogOptions;
			}
		}
	}
}
