﻿#region File and License Information
/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License>
		Redistribution and use in source and binary forms, with or without
		modification, are permitted provided that the following conditions are met:
			* Redistributions of source code must retain the above copyright
			  notice, this list of conditions and the following disclaimer.
			* Redistributions in binary form must reproduce the above copyright
			  notice, this list of conditions and the following disclaimer in the
			  documentation and/or other materials provided with the distribution.
			* Neither the name of the <organization> nor the
			  names of its contributors may be used to endorse or promote products
			  derived from this software without specific prior written permission.

		THIS SOFTWARE IS PROVIDED BY <copyright holder> ''AS IS'' AND ANY
		EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
		WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
		DISCLAIMED. IN NO EVENT SHALL <copyright holder> BE LIABLE FOR ANY
		DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
		(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
		LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
		ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
		(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
		SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
	</License>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2009-11-09 19:49:52Z</CreationDate>
</File>
*/
#endregion

using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;

using Calcium.Client.FileMetadata.Resources.Images.Metadata;

using DanielVaughan.Calcium.Modules.Output;
using DanielVaughan.ServiceLocation.Unity;
using DanielVaughan.Windows;

using Microsoft.Practices.Composite.Events;

using DanielVaughan;

namespace DanielVaughan.Calcium.Gui.Controls
{
	/// <summary>
	/// Interaction logic for SplashScreenView
	/// </summary>
	[TemplatePart(Name = PART_TextBlock_Feedback, Type = typeof(TextBlock))]
	public partial class SplashScreenView : UserControl
	{
		public const string PART_TextBlock_Feedback = "PART_TextBlock_Feedback";
		public const string PART_Label_Blurb = "PART_Label_Blurb";
		TextBlock feedbackTextBlock;
		Label blurbLabel;

		#region ImagePackUri Dependency Property

		public static DependencyProperty ImagePackUriProperty
			= DependencyProperty.Register("ImagePackUri", typeof (Uri), typeof(SplashScreenView));

		[Description("PropertyDescription")]
		[Browsable(true)]
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
		public Uri ImagePackUri
		{
			get
			{
				return (Uri) GetValue(ImagePackUriProperty);
			}
			set
			{
				SetValue(ImagePackUriProperty, value);
			}
		}

		#endregion
              
		static SplashScreenView()
		{
			DefaultStyleKeyProperty.OverrideMetadata(
				typeof(SplashScreenView), new FrameworkPropertyMetadata(typeof(SplashScreenView)));
		}

		public override void OnApplyTemplate()
		{
			base.OnApplyTemplate();

			feedbackTextBlock = Template.FindNamedElement<TextBlock>(PART_TextBlock_Feedback, this);
			blurbLabel = Template.FindNamedElement<Label>(PART_Label_Blurb, this);
			/* We detect whether a custom template is being used 
			 * by looking for the presence of the blurb PART,
			 * if it is present, then assume it has not been customized. */
			if (blurbLabel != null)
			{
				SetImage();
			}
		}

		SplashScreenViewModel ViewModel
		{
			get
			{
				return (SplashScreenViewModel)DataContext;
			}
		}

		bool loaded;

		public SplashScreenView()
		{
			DataContext = new SplashScreenViewModel();
			Loaded += OnLoaded;
		}

		void OnLoaded(object sender, RoutedEventArgs e)
		{
			if (loaded)
			{
				return;
			}
			loaded = true;
		}

		void SetImage()
		{
			BitmapImage image = new BitmapImage();

			try
			{
				image.BeginInit();
				image.UriSource = ImagePackUri ?? SplashPng.PackUri;
				image.CacheOption = BitmapCacheOption.OnLoad;
				image.EndInit();
				Background = new ImageBrush(image);
			}
			catch (Exception ex)
			{
				Debug.WriteLine(string.Format("Unable to load splash image: {0} Exception: {1}", ImagePackUri, ex));
				image = new BitmapImage();
				image.BeginInit();

				image.UriSource = SplashPng.PackUri;
				image.CacheOption = BitmapCacheOption.OnLoad;
				image.EndInit();
				Background = new ImageBrush(image);
			}

			Width = image.PixelWidth;
			Height = image.PixelHeight;
		}
	}
}
