#region File and License Information
/*
<File>
	<Copyright>Copyright � 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License>
		Redistribution and use in source and binary forms, with or without
		modification, are permitted provided that the following conditions are met:
			* Redistributions of source code must retain the above copyright
			  notice, this list of conditions and the following disclaimer.
			* Redistributions in binary form must reproduce the above copyright
			  notice, this list of conditions and the following disclaimer in the
			  documentation and/or other materials provided with the distribution.
			* Neither the name of the <organization> nor the
			  names of its contributors may be used to endorse or promote products
			  derived from this software without specific prior written permission.

		THIS SOFTWARE IS PROVIDED BY <copyright holder> ''AS IS'' AND ANY
		EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
		WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
		DISCLAIMED. IN NO EVENT SHALL <copyright holder> BE LIABLE FOR ANY
		DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
		(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
		LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
		ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
		(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
		SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
	</License>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2009-05-17 19:13:54Z</CreationDate>
</File>
*/
#endregion

using System;
using System.Configuration;
using System.IO;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;

using DanielVaughan.Calcium.ThemeModel;

using Microsoft.Practices.Composite.Logging;
using Microsoft.Practices.Composite.Modularity;
using Microsoft.Practices.Composite.Presentation.Regions;
using Microsoft.Practices.Composite.Presentation.Regions.Behaviors;
using Microsoft.Practices.Composite.UnityExtensions;
using Microsoft.Practices.Unity;
using Microsoft.Practices.Unity.Configuration;
using Microsoft.Practices.Unity.StaticFactory;

using DanielVaughan.Calcium.Gui;
using DanielVaughan.Calcium.Modularity;
using DanielVaughan.Calcium.Modularity.RegionAdapters;
using DanielVaughan.Calcium.Services;
using DanielVaughan.Calcium.Services.ViewService;
using DanielVaughan.Calcium.TaskModel;
using DanielVaughan.Calcium.Tasks;
using DanielVaughan.Gui;
using DanielVaughan.ServiceLocation.Unity;
using DanielVaughan.Services;
using DanielVaughan.Services.Implementation;
using DanielVaughan.ServiceModel;
using DanielVaughan.TaskModel;

namespace DanielVaughan.Calcium
{
	public class Bootstrapper : UnityBootstrapper, IBootstrapper	
	{

		protected override DependencyObject CreateShell()
		{
			var themeRegisterationTask = new DefaultThemeRegistrationTask();
			var taskService = Container.Resolve<ITaskService>();
			taskService.PerformTask(themeRegisterationTask, null, null);
			
			var commandService = Container.TryResolve<ICommandService>();
			var shell = Container.TryResolve<IShell>();
			if (shell == null)
			{
				ShellView shellView = new ShellView();
				/* Hack to cause ControlTemplate to be applied. */
				shellView.BeginInit();
				shellView.EndInit();
				shellView.ApplyTemplate();

				/* Retrieve viewmodel from view and register it. */
				shell = (IShell)shellView.ViewModel;
				Container.RegisterInstance<IShell>(shell);
				Container.RegisterInstance<IMainWindow>(shellView);
		
				if (commandService == null)
				{
					/* The shell implementation acts as the Command Service. */
					Container.RegisterInstance<ICommandService>((ICommandService)shellView);
				}
				return shellView;
			}

			var mainWindow = Container.TryResolve<IMainWindow>();
			if (mainWindow == null)
			{
				mainWindow = shell as IMainWindow;
				if (mainWindow != null)
				{
					if (commandService == null)
					{
						/* The shell implementation acts as the Command Service. */
						Container.RegisterInstance<ICommandService>((ICommandService)shell);
					}
					/* Required by independent services. E.g. FileService. */
					Container.RegisterInstance<IMainWindow>(mainWindow);
					return (DependencyObject)mainWindow;
				}
			}
			throw new Exception("IMainWindow is not registered with the IOC container.");
		}

		readonly CompositeLogAdapter compositeLogAdapter = new CompositeLogAdapter();

		protected override ILoggerFacade LoggerFacade
		{
			get
			{
				return compositeLogAdapter;
			}
		}

		/// <summary>
		/// Gets or sets the module catalog parameters, 
		/// which are placed in the IOC Container for use 
		/// by the <see cref="IModuleCatalog"/> implementation.
		/// </summary>
		/// <value>The module catalog parameters.</value>
		public ModuleCatalogOptions ModuleCatalogOptions { get; set; }

		protected override IUnityContainer CreateContainer()
		{
			IUnityContainer result;
			if (!ServiceLocatorSingleton.Instance.IsInitialized())
			{
				result = base.CreateContainer();
				/* In order to allow instance registration using the IServiceLocator implementation 
				 * we must allow the ServiceLocatorSingleton to set 
				 * the Unity implementation of the IServiceRegistrar. */
				ServiceLocatorSingleton.Instance.InitializeServiceLocator(result);
			}
			else
			{
				result = ServiceLocatorSingleton.Instance.GetInstance<IUnityContainer>();
			}

			return result;
		}

		/// <summary>
		/// We configure the unity container using the config file as well as imperatavely.
		/// </summary>
		protected override void ConfigureContainer()
		{
			var section = (UnityConfigurationSection)ConfigurationManager.GetSection("unity");
			section.Containers.Default.Configure(Container);
			/* For resolving types with delegates. */
			Container.AddNewExtension<StaticFactoryExtension>();
            
            /* Composite logging is sent to Clog. */
			RegisterTypeIfMissing(typeof(ILoggerFacade), typeof(CompositeLogAdapter), true);
			/* IChannelManager is used to create simplex and duplex WCF channels. */
			RegisterInstanceIfMissing<IChannelManager>(ChannelManagerSingleton.Instance);
			/* By registering the UI thread dispatcher 
			 * we are able to invoke controls from anywhere. */
			RegisterInstanceIfMissing<Dispatcher>(Dispatcher.CurrentDispatcher);

			RegisterInstanceIfMissing<ITaskService>(TaskServiceSingleton.Instance);

			/* Register the module load error strategy 
			 * so that if a module doesn't load properly it will be excluded. */
			RegisterTypeIfMissing<IModuleLoadErrorStrategy, ModuleLoadErrorStrategy>(false);
			/* We use a custom initializer so that we can handle load errors. */
			RegisterTypeIfMissing<IModuleInitializer, CustomModuleInitializer>(false);
			/* IViewService will hide and show visual elements 
			 * depending on workspace content. */
			RegisterTypeIfMissing<IViewService, ViewService>(true);
			/* Message Service */
			RegisterTypeIfMissing<IMessageService, MessageService>(true);
			/* File Service */
			RegisterTypeIfMissing<IFileService, FileService>(true);

			base.ConfigureContainer();

			var regionBehaviorFactory = Container.TryResolve<IRegionBehaviorFactory>();
			if (regionBehaviorFactory != null)
			{
				regionBehaviorFactory.AddIfMissing(RegionManagerRegistrationBehavior.BehaviorKey, 
					typeof(CustomRegionManagerRegistrationBehavior));
			}

			/* The module catalog parameters are used to determine 
			 * those modules that should be ignored. */
			if (ModuleCatalogOptions != null)
			{
				RegisterInstanceIfMissing<ModuleCatalogOptions>(ModuleCatalogOptions);
			}

			RegisterTypeIfMissing<IThemeService, ThemeService>(true);
		}

		void RegisterInstanceIfMissing<TFrom>(TFrom instance)
		{
			if (!Container.IsTypeRegistered(typeof(TFrom)))
			{
				Container.RegisterInstance<TFrom>(instance);
			}
		}

		void RegisterTypeIfMissing<TFrom, TTo>(bool registerAsSingleton) where TTo : TFrom
		{
			if (!Container.IsTypeRegistered(typeof(TFrom)))
			{
				if (registerAsSingleton)
				{
					Container.RegisterType<TFrom, TTo>(new ContainerControlledLifetimeManager());
				}
				else
				{
					Container.RegisterType<TFrom, TTo>();
				}
			}
		}

		protected override IModuleCatalog GetModuleCatalog()
		{
			IModuleCatalog catalog = Container.TryResolve<IModuleCatalog>();
			if (catalog == null)
			{
				var temp = new CustomModuleCatalog
				           	{
				           		ModulePath = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location)
				           	};
				catalog = temp;
			}
			
			return catalog;
		}

		protected override RegionAdapterMappings ConfigureRegionAdapterMappings()
		{
			var mappings = base.ConfigureRegionAdapterMappings() ?? Container.Resolve<RegionAdapterMappings>();
			mappings.RegisterMapping(typeof(ToolBarTray), Container.Resolve<ToolBarTrayRegionAdapter>());
			mappings.RegisterMapping(typeof(Menu), Container.Resolve<CustomItemsControlRegionAdapter>());
			mappings.RegisterMapping(typeof(MenuItem), Container.Resolve<CustomItemsControlRegionAdapter>());
			mappings.RegisterMapping(typeof(Panel), Container.Resolve<PanelRegionAdapter>());
			var windowRegionAdapter = Container.Resolve<WindowRegionAdapter>();
			windowRegionAdapter.WindowStyle = (Style)Application.Current.FindResource("ChildWindowView");
			mappings.RegisterMapping(typeof(Window), windowRegionAdapter);
			return mappings;
		}

		void IBootstrapper.Run()
		{
			base.Run();
			PerformPostStartupTask();
		}

		static void PerformPostStartupTask()
		{
			var commandLineArgs = Environment.GetCommandLineArgs();
			var startupTask = ServiceLocatorSingleton.Instance.GetInstance<IAppStartupTask, PostAppStartupTask>();
			var startupArgs = ServiceLocatorSingleton.Instance.GetInstance<AppStartupTaskArgs>();
			startupArgs.CommandLineArgs = commandLineArgs;
			TaskServiceSingleton.Instance.PerformTask((TaskBase<AppStartupTaskArgs>)startupTask, startupArgs, null);
		}
	}
}
