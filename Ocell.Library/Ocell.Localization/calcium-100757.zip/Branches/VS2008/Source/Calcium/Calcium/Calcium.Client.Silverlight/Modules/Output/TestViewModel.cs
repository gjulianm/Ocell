﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using DanielVaughan.Calcium.Gui;
using DanielVaughan.ComponentModel;

namespace DanielVaughan.Calcium.Modules.Output
{
	public class OutputViewModel2 : ViewModelBase
	{
		public OutputViewModel2()
		{
		}

		public string Property1 { get; set; }

		readonly ObservableCollection<OutputMessage> outputMessages = new ObservableCollection<OutputMessage>();

		public ObservableCollection<OutputMessage> OutputMessages
		{
			get
			{
				return outputMessages;
			}
		}

		void OnOutputPosted(OutputMessage message)
		{
			OutputMessages.Add(message);
		}
	}
}
