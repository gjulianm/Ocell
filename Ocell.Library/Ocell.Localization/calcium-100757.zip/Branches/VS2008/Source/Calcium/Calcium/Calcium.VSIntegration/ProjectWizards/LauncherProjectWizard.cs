﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;

using EnvDTE;

using Microsoft.VisualStudio.TemplateWizard;

namespace DanielVaughan.Calcium.VSIntegration
{
	/// <summary>
	/// This wizard provides population for the population of the replacements dictionary
	/// for a Calcium enabled Windows Application template.
	/// </summary>
	public class LauncherProjectWizard : IWizard
	{
//		public string VSVersion
//		{
//			get
//			{
//				replacementsDictionary["$CustomModule$"]
//			}
//		}

		public void RunStarted(object automationObject, Dictionary<string, string> replacementsDictionary,
			WizardRunKind runKind, object[] customParams)
		{
			string vsVersion;
			if (!replacementsDictionary.TryGetValue("$VSVersion$", out vsVersion))
			{
				MessageBox.Show("Problem determining Visual Studio Version. Please reinstall Calcium SDK.");
				return;
			}

			if (runKind == WizardRunKind.AsNewItem)
			{

			}
			else if (runKind == WizardRunKind.AsNewProject
				|| runKind == WizardRunKind.AsMultiProject)
			{
				/* Here we derive a module name using the last part of the project name. 
				 * For example, if the user has entered MyNamespace.TextEditor 
				 * in the new project dialog, then we elect TextEditor as the module name. */
				string projectName = replacementsDictionary["$projectname$"];
				string lastWord = null;
				int lastIndex = projectName.LastIndexOf('.');
				if (lastIndex != -1 && lastIndex < projectName.Length - 1)
				{
					lastWord = projectName.Substring(lastIndex + 1);
				}

				if (string.IsNullOrEmpty(lastWord))
				{
					lastWord = "Custom";
				}

				replacementsDictionary["$CustomModule$"] = lastWord;
				try
				{
					string installDir = RegistryUtil.GetCalciumInstallDirectory(vsVersion, "1.0");
					replacementsDictionary["$InstallDir$"] = installDir;
				}
				catch (Exception ex)
				{
					MessageBox.Show("Problem finding install directory. Please reinstall Calcium SDK. " + ex.ToString());
				}
				
			}
		}

		public bool ShouldAddProjectItem(string filePath)
		{
			return true;
		}

		public void RunFinished()
		{

		}

		public void BeforeOpeningFile(ProjectItem projectItem)
		{

		}

		public void ProjectItemFinishedGenerating(ProjectItem projectItem)
		{

		}

		public void ProjectFinishedGenerating(Project project)
		{

		}
	}
}
