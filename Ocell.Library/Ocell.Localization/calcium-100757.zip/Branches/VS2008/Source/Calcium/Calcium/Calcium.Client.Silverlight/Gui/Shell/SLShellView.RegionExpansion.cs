﻿#region File and License Information
/*
<File>
	<Copyright>Copyright © 2010, Daniel Vaughan. All rights reserved.</Copyright>
	<License>
		Redistribution and use in source and binary forms, with or without
		modification, are permitted provided that the following conditions are met:
			* Redistributions of source code must retain the above copyright
			  notice, this list of conditions and the following disclaimer.
			* Redistributions in binary form must reproduce the above copyright
			  notice, this list of conditions and the following disclaimer in the
			  documentation and/or other materials provided with the distribution.
			* Neither the name of the <organization> nor the
			  names of its contributors may be used to endorse or promote products
			  derived from this software without specific prior written permission.

		THIS SOFTWARE IS PROVIDED BY <copyright holder> ''AS IS'' AND ANY
		EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
		WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
		DISCLAIMED. IN NO EVENT SHALL <copyright holder> BE LIABLE FOR ANY
		DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
		(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
		LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
		ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
		(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
		SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
	</License>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2010-01-31 18:38:29Z</CreationDate>
</File>
*/
#endregion

using System;
using System.Windows;
using System.Windows.Controls;

namespace DanielVaughan.Calcium.Gui
{
	public partial class SLShellView
	{
		static readonly DependencyProperty LeftColumnWidthProperty = DependencyProperty.Register(
			"LeftColumnWidth", typeof(double), typeof(Page),
			new PropertyMetadata(new PropertyChangedCallback(LeftColumnWidthChanged)));

		double LeftColumnWidth
		{
			get
			{
				return (double)GetValue(LeftColumnWidthProperty);
			}
			set
			{
				SetValue(LeftColumnWidthProperty, value);
			}
		}

		static void LeftColumnWidthChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			((SLShellView)d).columnDefinition_Left.Width = new GridLength((double)e.NewValue);
		}

		static readonly DependencyProperty RightColumnWidthProperty = DependencyProperty.Register(
			"RightColumnWidth", typeof(double), typeof(Page),
			new PropertyMetadata(new PropertyChangedCallback(RightColumnWidthChanged)));

		double RightColumnWidth
		{
			get
			{
				return (double)GetValue(RightColumnWidthProperty);
			}
			set
			{
				SetValue(RightColumnWidthProperty, value);
			}
		}

		static void RightColumnWidthChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			((SLShellView)d).columnDefinition_Right.Width = new GridLength((double)e.NewValue);
		}

		static readonly DependencyProperty RowHeightProperty = DependencyProperty.Register(
			"RowHeight", typeof(double), typeof(Page), new PropertyMetadata(new PropertyChangedCallback(RowHeightChanged)));

		double RowHeight
		{
			get
			{
				return (double)GetValue(RowHeightProperty);
			}
			set
			{
				SetValue(RowHeightProperty, value);
			}
		}

		static void RowHeightChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			((SLShellView)d).rowDefinition_Bottom.Height = new GridLength((double)e.NewValue);
		}

		void gridSplitter_Left_ButtonClick(object sender)
		{
			if (columnDefinition_Left.Width.Value == 0)
			{
				OpenLeft.Begin();
			}
			else if (sender != this)
			{
				animCloseCol.From = columnDefinition_Left.Width.Value;
				CloseLeft.Begin();
			}
		}

		void gridSplitter_Right_ButtonClick(object sender)
		{
			if (columnDefinition_Right.Width.Value == 0)
			{
				OpenRight.Begin();
			}
			else if (sender != this)
			{
				animCloseCol2.From = columnDefinition_Right.Width.Value;
				CloseRight.Begin();
			}
		}

		void GridSplitter_Center_ButtonClick(object sender)
		{
			if (rowDefinition_Bottom.Height.Value == 0)
			{
				OpenBottom.Begin();
			}
			else if (sender != this)
			{
				animCloseRow.From = rowDefinition_Bottom.Height.Value;
				CloseBottom.Begin();
			}
		}

		void Grid_Left_SizeChanged(object sender, SizeChangedEventArgs e)
		{
			UpdateGridSplitterLeftState();
		}

		void UpdateGridSplitterLeftState()
		{
			gridSplitter_Left.CollapseButtonString = columnDefinition_Left.Width.Value == 0 ? "4" : "3";
		}

		void Grid_Right_SizeChanged(object sender, SizeChangedEventArgs e)
		{
			UpdateGridSplitterRightState();
		}

		void UpdateGridSplitterRightState()
		{
			gridSplitter_Right.CollapseButtonString = columnDefinition_Right.Width.Value == 0 ? "3" : "4";
		}

		void Grid_Bottom_SizeChanged(object sender, SizeChangedEventArgs e)
		{
			UpdateGridSplitterBottomState();
		}

		void UpdateGridSplitterBottomState()
		{
			gridSplitter_Bottom.CollapseButtonString = rowDefinition_Bottom.Height.Value == 0 ? "5" : "6";
		}

		#region Hide and show grids depending on TabControl item count

		void UpdateRegionExpansion()
		{
			UpdateLeftRegionDimensions();
			UpdateRightRegionDimensions();
			UpdateBottomRegionDimensions();
		}

		void UpdateLeftRegionDimensions()
		{
			UpdateRegionDimensions(tabControl_Left, columnDefinition_Left, gridSplitter_Left);
		}

		void UpdateRightRegionDimensions()
		{
			UpdateRegionDimensions(tabControl_Right, columnDefinition_Right, gridSplitter_Right);
		}

		void UpdateBottomRegionDimensions()
		{
			UpdateRegionDimensions(tabControl_Bottom, rowDefinition_Bottom, gridSplitter_Bottom);
		}

		void UpdateRegionDimensions(ItemsControl itemsControl, ColumnDefinition columnDefinition, UIElement gridSplitter)
		{
			int itemCount = itemsControl.Items.Count;
			if (itemCount > 0)
			{
				columnDefinition.MaxWidth = double.MaxValue;
				gridSplitter.Visibility = Visibility.Visible;
			}
			else
			{
				columnDefinition.MaxWidth = 0;
				gridSplitter.Visibility = Visibility.Collapsed;
			}
		}

		void UpdateRegionDimensions(ItemsControl itemsControl, RowDefinition rowDefinition, UIElement gridSplitter)
		{
			int itemCount = itemsControl.Items.Count;
			if (itemCount > 0)
			{
				rowDefinition.MaxHeight = double.MaxValue;
				gridSplitter.Visibility = Visibility.Visible;
			}
			else
			{
				rowDefinition.MaxHeight = 0;
				gridSplitter.Visibility = Visibility.Collapsed;
			}
		}

		double gridBottomHeightLast;

		void OnTabControl_Bottom_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			UpdateBottomRegionDimensions();
//			int itemCount = tabControl_Bottom.Items.Count;
//			if (itemCount < 1)
//			{
//				if (grid_Bottom.Width > 0)
//				{
//					gridBottomHeightLast = grid_Bottom.Width;
//				}
//			}
//			else if (itemCount == 1 && gridBottomHeightLast > 0)
//			{
//				grid_Bottom.Width = gridBottomHeightLast;
//			}
//			HideOrShowElementDependingOnItemCount(grid_Bottom, tabControl_Bottom, false, ref gridBottomHeightLast);
		}

		double gridRightWidthLast;

		void OnTabControl_Right_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			UpdateRightRegionDimensions();
//			int itemCount = tabControl_Right.Items.Count;
//			if (itemCount < 1)
//			{
//				if (grid_Right.Width > 0)
//				{
//					gridRightWidthLast = grid_Right.Width;
//				}
//			}
//			else if (itemCount == 1 && gridRightWidthLast > 0)
//			{
//				grid_Right.Width = gridRightWidthLast;
//			}
//			HideOrShowElementDependingOnItemCount(grid_Right, tabControl_Right, true, ref gridRightWidthLast);
		}

		double gridLeftWidthLast;

		void OnTabControl_Left_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			UpdateLeftRegionDimensions();
//			int itemCount = tabControl_Left.Items.Count;
//			if (itemCount < 1)
//			{
//				if (grid_Left.Width > 0)
//				{
//					gridLeftWidthLast = grid_Left.Width;
//				}
//			}
//			else if (itemCount == 1 && gridLeftWidthLast > 0)
//			{
//				grid_Left.Width = gridLeftWidthLast;
//			}
//			HideOrShowElementDependingOnItemCount(grid_Left, tabControl_Left, true, ref gridLeftWidthLast);
		}

		void HideOrShowElementDependingOnItemCount(FrameworkElement element, ItemsControl tabControl, 
			bool width, ref double historyValue)
		{
			int itemCount = tabControl.Items.Count;
			if (itemCount < 1)
			{
				if (width)
				{
					if (element.Width > 0)
					{
						historyValue = element.Width;
					}
				}
				else
				{
					if (element.Height > 0)
					{
						historyValue = element.Height;
					}
				}
			}
			else if (itemCount == 1 && historyValue > 0)
			{
				if (width)
				{
					grid_Right.Width = historyValue;
				}
				else
				{
					grid_Right.Height = historyValue;
				}
			}

			element.Visibility = tabControl.Items.Count < 1 ? Visibility.Collapsed : Visibility.Visible;
		}

//		void HideOrShowElementDependingOnItemCount(ColumnDefinition element, ItemsControl tabControl, 
//			ColumnDefinition columnDefinition, bool width, ref double historyValue)
//		{
//			int itemCount = tabControl.Items.Count;
//			if (itemCount < 1)
//			{
//				if (element.Width.Value > 0)
//				{
//					element.Width.
//					historyValue = element.Width.Value;
//				}
//			}
//			else if (itemCount == 1 && element.Width.Value < 1)
//			{
//				element.Width.Value = historyValue;
//			}
//
//			element.Visibility = tabControl.Items.Count < 1 ? Visibility.Collapsed : Visibility.Visible;
//		}
		#endregion

		public IView ActiveView
		{
			get
			{
				return null;
			}
		}

		public IView MainView
		{
			get
			{
				return null;
			}
		}
	}
}
