

http://appconfigverifier.codeplex.com/
